#' @keywords internal
#' @noRd
build_Wk<-function(coord){
  W1s<-W1<-kernel_matW(H=1,kernels='rectangle',coords=coord,NN=1,adaptive=TRUE,diagnull=TRUE)
  W2s<-W2<-kernel_matW(H=2,kernels='rectangle',coords=coord,NN=2,adaptive=TRUE,diagnull=TRUE)
  W3s<-W3<-kernel_matW(H=3,kernels='rectangle',coords=coord,NN=3,adaptive=TRUE,diagnull=TRUE)
  W4s<-W4<-kernel_matW(H=4,kernels='rectangle',coords=coord,NN=4,adaptive=TRUE,diagnull=TRUE)
  W5s<-W5<-kernel_matW(H=6,kernels='rectangle',coords=coord,NN=6,adaptive=TRUE,diagnull=TRUE)
  W6s<-W6<-kernel_matW(H=8,kernels='rectangle',coords=coord,NN=8,adaptive=TRUE,diagnull=TRUE)
  W7s<-W7<-kernel_matW(H=10,kernels='rectangle',coords=coord,NN=10,adaptive=TRUE,diagnull=TRUE)
  W8s<-W8<-kernel_matW(H=15,kernels='rectangle',coords=coord,NN=15,adaptive=TRUE,diagnull=TRUE)
  W9s<-W9<-kernel_matW(H=20,kernels='rectangle',coords=coord,NN=20,adaptive=TRUE,diagnull=TRUE)
  W10s<-W10<-kernel_matW(H=60,kernels='rectangle',coords=coord,NN=60,adaptive=TRUE,diagnull=TRUE)
  W11s<-W11<-kernel_matW(H=100,kernels='rectangle',coords=coord,NN=100,adaptive=TRUE,diagnull=TRUE)

  W11s[which(W10>0)]<-0
  W10s[which(W9>0)]<-0
  W9s[which(W8>0)]<-0
  W8s[which(W7>0)]<-0
  W7s[which(W6>0)]<-0
  W6s[which(W5>0)]<-0
  W5s[which(W4>0)]<-0
  W4s[which(W3>0)]<-0
  W3s[which(W2>0)]<-0
  W2s[which(W1>0)]<-0
  W2s<-normW(W2s)
  W3s<-normW(W3s)
  W4s<-normW(W4s)
  W5s<-normW(W5s)
  W6s<-normW(W6s)
  W7s<-normW(W7s)
  W8s<-normW(W8s)
  W9s<-normW(W9s)
  W10s<-normW(W10s)
  W11s<-normW(W11s)
  WW<-list(W1s=W1s,W2s=W2s,W3s=W3s,W4s=W4s,W5s=W5s,W6s=W6s,W7s=W7s,W8s=W8s,W9s=W9s,W10s=W10s,W11s=W11s,W4=W4,W7=W7,W10=W10)
}
