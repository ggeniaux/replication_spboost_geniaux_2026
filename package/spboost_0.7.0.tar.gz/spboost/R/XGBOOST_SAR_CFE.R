#' XGBOOST_SAR_CFE
#' XGBOOST_SAR_CFE allows the estimation of SAR models using the gradient boosting method with linear base learner or btree while the estimation
#' of the spatial parameter is based on the determinant-free Closed-Form Estimator of Smirnov (2020, doi:10.1111/gean.12268). This function makes
#' it possible to estimate a SAR linear or non linear model while automatically selecting the explanatory variables.
#' @usage XGBOOST_SAR_CFE(formula,data,W,mstop0=NULL,mstop_init=500,
#' myparams=list(booster="gblinear",eta=0.3,gamma = 1, max_depth = 4,
#' min_child_weight = 5,subsample = 0.9,colsample_bytree = 0.9,
#' nthread=7,nfold=5,folds = NULL,early_stopping_rounds=3,
#' verbose = 0),verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param mstop_init max number of iterations for cross validation of mstop0. mstop_init is used only if mstop0 is NULL, default 500.
#' @param mstop0 an integer giving the number of iterations
#' @param myparams 	the list of parameters:
#' * booster which booster to use, can be gbtree or gblinear. Default: gbtree.
#' * eta control the learning rate: scale the contribution of each tree by a factor of 0 < eta < 1 when it is added to the current approximation. Used to prevent overfitting by making the boosting process more conservative. Lower value for eta implies larger value for nrounds: low eta value means model more robust to overfitting but slower to compute. Default: 0.3
#' * gamma minimum loss reduction required to make a further partition on a leaf node of the tree. the larger, the more conservative the algorithm will be.
#' * max_depth maximum depth of a tree. Default: 6
#' * min_child_weight minimum sum of instance weight (hessian) needed in a child. If the tree partition step results in a leaf node with the sum of instance weight less than min_child_weight, then the building process will give up further partitioning. In linear regression mode, this simply corresponds to minimum number of instances needed to be in each node. The larger, the more conservative the algorithm will be. Default: 1
#' * subsample subsample ratio of the training instance. Setting it to 0.5 means that xgboost randomly collected half of the data instances to grow trees and this will prevent overfitting. It makes computation shorter (because less data to analyse). It is advised to use this parameter with eta and increase nrounds. Default: 1
#' * colsample_bytree colsample_bytree subsample ratio of columns when constructing each tree. Default: 1
#' * nthread number of parallel threads
#' * nfold	during cross-validation the original dataset is randomly partitioned into nfold equal size subsamples. Default: 5
#' * folds list provides a possibility to use a list of pre-defined CV folds (each element must be a vector of test fold's indices). When folds are supplied, the nfold and stratified parameters are ignored.
#' * early_stopping_rounds if NULL, the early stopping function is not triggered. If set to an integer k, training with a validation set will stop if the performance doesn't improve for k rounds.
#' * verbose if verbose>0 Give verbose output for xgboost and xgb.cv function.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
XGBOOST_SAR_CFE=function(formula,data,W,mstop0=NULL,mstop_init=500,myparams=list(booster="gblinear",eta=0.3,gamma = 1, max_depth = 4,min_child_weight = 5,subsample = 0.9,colsample_bytree = 0.9,nthread=7,nfold=5,folds = NULL,early_stopping_rounds=3,verbose = 0),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  xtrain=model.matrix(formula,data)
  y_name <- as.character(attr(terms(formula),'variables')[[2]])
  Y <- data[[y_name]]
  if (is.data.frame(Y)) Y <- Y[[1]]
  Y <- suppressWarnings(as.numeric(Y))
  if (length(Y) != n) {
    Y <- suppressWarnings(as.numeric(get_all_vars(formula, data)[, 1]))
  }
  if (length(Y) != n || any(!is.finite(Y))) {
    stop("Invalid response vector `Y` extracted from `data`.")
  }
  n=length(Y)
  make_xgb_data <- function(label = NULL) {
    info <- if (is.null(label)) list() else list(label = label)
    xgboost::xgb.DMatrix(data = xtrain, info = info)
  }
  get_cv_nrounds <- function(cv, fallback) {
    fallback <- suppressWarnings(as.integer(fallback[1]))
    if (length(fallback) == 0L || is.na(fallback) || !is.finite(fallback) || fallback < 1L) fallback <- 1L

    best <- suppressWarnings(as.integer(cv$best_iteration[1]))
    if (length(best) > 0L && !is.na(best) && is.finite(best) && best >= 1L) return(best)

    best <- suppressWarnings(as.integer(cv$early_stop$best_iteration[1]))
    if (length(best) > 0L && !is.na(best) && is.finite(best) && best >= 1L) return(best)

    elog <- cv$evaluation_log
    if (!is.null(elog) && NROW(elog) > 0L) {
      metric_names <- names(elog)
      metric_names <- metric_names[grepl("^(test|validation|eval)_.*_mean$", metric_names)]
      if (length(metric_names) == 0L) {
        is_num <- vapply(elog, is.numeric, logical(1))
        metric_names <- setdiff(names(elog)[is_num], c("iter", "iteration"))
        metric_names <- metric_names[!grepl("_std$", metric_names)]
      }
      for (nm in metric_names) {
        vals <- suppressWarnings(as.numeric(elog[[nm]]))
        if (any(is.finite(vals))) return(as.integer(which.min(vals)))
      }
      return(as.integer(NROW(elog)))
    }
    fallback
  }
  get_cv_min <- function(cv) {
    elog <- cv$evaluation_log
    if (is.null(elog) || NROW(elog) == 0L) return(NA_real_)
    metric_names <- names(elog)
    metric_names <- metric_names[grepl("^(test|validation|eval)_.*_mean$", metric_names)]
    if (length(metric_names) == 0L) return(NA_real_)
    vals <- suppressWarnings(as.numeric(elog[[metric_names[1]]]))
    if (!any(is.finite(vals))) return(NA_real_)
    min(vals, na.rm = TRUE)
  }
  make_spboost_xgb_model <- function(booster) {
    estimator_class <- ifelse(myparams$booster == "gblinear", "XGBOOST_LINEAR_SAR_CFE", "XGBOOST_SAR_CFE")
    model <- list(booster = booster)
    class(model) <- c("spboost", estimator_class, "spboost_xgb_model")
    model
  }

  ### step 1 findind mstop0 with given rho

  myparams$objective = 'reg:squarederror'
  myparams$eval_metric = 'rmse'
  nrounds=mstop0
  search_mstop=is.null(mstop0)


  ## step 1: Estimation of rho with CFE
  if(myparams$booster=='gblinear') nrounds=500
  if(verbose>0) cat('nrounds=', nrounds,'\n')

  if(verbose>0) cat('Start Cmputation of rho using CFE\n')
  myparams_train<-myparams
  j<-c('early_stopping_rounds', 'folds', 'nfold', 'nrounds', 'verbose')
  for(i in j) myparams_train[[i]]<-NULL
  WY=as.numeric(W%*%Y)
  W2Y=as.numeric(W%*%WY)
  if(search_mstop & myparams$booster!='gblinear'){
    if(is.null(myparams$folds)) cvFoldsList<-createFolds(Y, k=myparams$nfold, list=TRUE, returnTrain=FALSE) else cvFoldsList<-myparams$folds
    if(verbose>0) cat('Approximation mstop0 for m0 \n')
      cv <- xgb.cv(params=myparams,data = make_xgb_data(Y), nrounds = mstop_init, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
      nrounds=get_cv_nrounds(cv, mstop_init)
  }
  m0= xgboost::xgb.train(params=myparams_train,data = make_xgb_data(Y),nrounds=nrounds,verbose =FALSE)
  if(search_mstop & myparams$booster!='gblinear'){
    if(verbose>0) cat('Approximation mstop0 for m1 \n')
    cv <- xgb.cv(params=myparams,data = make_xgb_data(WY), nrounds = mstop_init, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
    nrounds=get_cv_nrounds(cv, mstop_init)
  }
  m1= xgboost::xgb.train(params=myparams_train,data = make_xgb_data(WY),nrounds=nrounds,verbose =FALSE)
  if(search_mstop & myparams$booster!='gblinear'){
    if(verbose>0) cat('Approximation mstop0 for m1 \n')
    cv <- xgb.cv(params=myparams,data = make_xgb_data(W2Y), nrounds = mstop_init, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
    nrounds=get_cv_nrounds(cv, mstop_init)
  }
  m2= xgboost::xgb.train(params=myparams_train,data = make_xgb_data(W2Y),nrounds=nrounds,verbose =FALSE)
  e0=predict(m0, newdata = make_xgb_data())-Y
  e1=predict(m1, newdata = make_xgb_data())-WY
  e2=predict(m2, newdata = make_xgb_data())-W2Y
  a=t(e1) %*% e2
  b=t(e0)%*% e2+t(e1) %*% e1
  c=t(e0)%*% e1
  D=b^2-4*a*c
  if(D>=0){
    rho=as.numeric((b-sqrt(D))/(2*a))
    YS=as.numeric(Y-rho*W%*%Y)
    ## optimize nrounds
    if(verbose>0) cat('Finding nrouds using cvxgboosts (5 kfolds) with rho=',rho,' \n')
    if(is.null(myparams$folds)) cvFoldsList<-createFolds(Y, k=myparams$nfold, list=TRUE, returnTrain=FALSE) else cvFoldsList<-myparams$folds
      cv <- xgb.cv(params=myparams,data = make_xgb_data(YS), nrounds = mstop_init, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
    nrounds<-get_cv_nrounds(cv, mstop_init)
    cv_min=get_cv_min(cv)
    booster= xgboost::xgb.train(params=myparams_train,data = make_xgb_data(YS),nrounds=nrounds,verbose =FALSE)
    fittedYS=predict(object=booster, newdata=make_xgb_data())
    fitted=as.numeric(rho*W %*%Y+fittedYS)
    model=make_spboost_xgb_model(booster)
    model$residuals=Y-fitted
    model$rho=rho
    model$Y=Y
    model$fitted=fitted
    model$fittedYS=fittedYS
    model$cv<-cv_min
    model$rmse=sqrt(mean(model$residuals^2))
    model$formula=formula
    } else {
      model='D is negative, need complex solution'
      class(model)<-'error'
    }
  return(model)
}
