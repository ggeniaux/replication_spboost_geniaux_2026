#' ApproxiW
#' Approximate \eqn{(I - \lambda W)^{-1}} with a truncated Neumann series.
#'
#' The historical implementation returned the approximate inverse matrix itself.
#' This file keeps that behavior for backward compatibility and also provides
#' helper utilities to apply the approximation directly to one or several right
#' hand sides without forming the dense inverse explicitly.
#'
#' @usage ApproxiW(W, lambda, order = NULL, tol = 1e-6, max_order = 50L)
#' @param W sparse or dense square matrix.
#' @param lambda scalar spatial parameter.
#' @param order optional truncation order. If `NULL`, an adaptive order is
#'   chosen from `tol` and a row-sum bound of `|lambda W|`.
#' @param tol target truncation tolerance when `order = NULL`.
#' @param max_order maximum order allowed when using the adaptive rule.
#' @return A matrix approximating \eqn{(I - \lambda W)^{-1}}.
#' @noRd

spb_neumann_radius_bound <- function(W, lambda = 1) {
  if (!is.matrix(W) && !inherits(W, "Matrix")) {
    W <- as.matrix(W)
  }
  rs_abs <- if (inherits(W, "Matrix")) {
    as.numeric(Matrix::rowSums(abs(W)))
  } else {
    rowSums(abs(W))
  }
  abs(lambda) * max(rs_abs, na.rm = TRUE)
}

choose_approxiw_order <- function(W, lambda, tol = 1e-6, max_order = 50L, min_order = 1L) {
  tol <- suppressWarnings(as.numeric(tol)[1])
  if (!is.finite(tol) || tol <= 0) tol <- 1e-6
  max_order <- suppressWarnings(as.integer(max_order)[1])
  min_order <- suppressWarnings(as.integer(min_order)[1])
  if (!is.finite(max_order) || max_order < 1L) max_order <- 50L
  if (!is.finite(min_order) || min_order < 1L) min_order <- 1L
  if (min_order > max_order) min_order <- max_order

  theta <- spb_neumann_radius_bound(W, lambda = lambda)
  if (!is.finite(theta) || theta <= 0) return(min_order)
  if (theta >= 1) return(max_order)

  k <- min_order
  repeat {
    remainder_bound <- theta^(k + 1) / (1 - theta)
    if (!is.finite(remainder_bound) || remainder_bound <= tol || k >= max_order) break
    k <- k + 1L
  }
  k
}

ApproxiW_apply <- function(W, lambda, rhs, order = NULL, tol = 1e-6, max_order = 50L) {
  if (missing(rhs) || is.null(rhs)) stop("`rhs` is required.")

  rhs_is_vector <- is.null(dim(rhs))
  rhs_mat <- if (rhs_is_vector) matrix(as.numeric(rhs), ncol = 1L) else as.matrix(rhs)

  if (!is.matrix(W) && !inherits(W, "Matrix")) {
    W <- as.matrix(W)
  }

  if (is.null(order)) {
    order <- choose_approxiw_order(W = W, lambda = lambda, tol = tol, max_order = max_order)
  } else {
    order <- suppressWarnings(as.integer(order)[1])
    if (!is.finite(order) || order < 1L) order <- 1L
  }

  x <- rhs_mat
  if (order <= 0L) {
    return(if (rhs_is_vector) as.numeric(x[, 1L]) else x)
  }

  term <- rhs_mat
  if (order >= 1L) {
    for (i in seq_len(order)) {
      term <- lambda * (W %*% term)
      x <- x + term

      # Early stop when the newly added term becomes negligible.
      term_scale <- sqrt(mean(as.numeric(term)^2))
      if (is.finite(term_scale) && term_scale <= tol) break
    }
  }

  if (rhs_is_vector) as.numeric(x[, 1L]) else x
}

spb_solve_spatial_rhs <- function(W, lambda, rhs,
                                  direct_max_n = 25000L,
                                  order = NULL,
                                  tol = 1e-6,
                                  max_order = 50L) {
  n <- nrow(W)
  direct_max_n <- suppressWarnings(as.integer(direct_max_n)[1])
  if (!is.finite(direct_max_n) || direct_max_n < 1L) direct_max_n <- 25000L

  if (n <= direct_max_n) {
    A <- Matrix::Diagonal(n) - lambda * W
    return(Matrix::solve(A, as.matrix(rhs)))
  }

  ApproxiW_apply(W, lambda, rhs, order = order, tol = tol, max_order = max_order)
}

spb_inverse_spatial_matrix <- function(W, lambda,
                                       direct_max_n = 25000L,
                                       order = NULL,
                                       tol = 1e-6,
                                       max_order = 50L) {
  n <- nrow(W)
  direct_max_n <- suppressWarnings(as.integer(direct_max_n)[1])
  if (!is.finite(direct_max_n) || direct_max_n < 1L) direct_max_n <- 25000L

  if (n <= direct_max_n) {
    A <- Matrix::Diagonal(n) - lambda * W
    return(Matrix::solve(A))
  }

  ApproxiW(W, lambda, order = order, tol = tol, max_order = max_order)
}

spb_solve_linear_system <- function(A, rhs,
                                    direct_max_n = 25000L,
                                    order = NULL,
                                    tol = 1e-6,
                                    max_order = 50L) {
  n <- nrow(A)
  if (n != ncol(A)) stop("`A` must be square.")
  direct_max_n <- suppressWarnings(as.integer(direct_max_n)[1])
  if (!is.finite(direct_max_n) || direct_max_n < 1L) direct_max_n <- 25000L

  if (n <= direct_max_n) {
    return(Matrix::solve(A, as.matrix(rhs)))
  }

  delta <- Matrix::Diagonal(n) - A
  ApproxiW_apply(delta, 1, rhs, order = order, tol = tol, max_order = max_order)
}

spb_solve_nested_spatial_rhs <- function(W, rho, W2, lambda, rhs,
                                         direct_max_n = 25000L,
                                         order = NULL,
                                         tol = 1e-6,
                                         max_order = 50L) {
  n <- nrow(W)
  direct_max_n <- suppressWarnings(as.integer(direct_max_n)[1])
  if (!is.finite(direct_max_n) || direct_max_n < 1L) direct_max_n <- 25000L

  if (n <= direct_max_n) {
    A1 <- Matrix::Diagonal(n) - rho * W
    A2 <- Matrix::Diagonal(n) - lambda * W2
    return(Matrix::solve(A1, Matrix::solve(A2, as.matrix(rhs))))
  }

  tmp <- ApproxiW_apply(W2, lambda, rhs, order = order, tol = tol, max_order = max_order)
  ApproxiW_apply(W, rho, tmp, order = order, tol = tol, max_order = max_order)
}

#' ApproxiW
#'
#' Approximate \eqn{(I - \lambda W)^{-1}} with a truncated Neumann series.
#'
#' @param W Sparse or dense square matrix.
#' @param lambda Scalar spatial parameter.
#' @param order Optional truncation order. If `NULL`, an adaptive order is
#' chosen from `tol` and a row-sum bound of `|lambda W|`.
#' @param tol Target truncation tolerance when `order = NULL`.
#' @param max_order Maximum order allowed when using the adaptive rule.
#' @return A matrix approximating \eqn{(I - \lambda W)^{-1}}.
#' @examples
#' W <- Matrix::Matrix(c(0, 1, 1, 0), nrow = 2, sparse = TRUE)
#' ApproxiW(W, lambda = 0.2, order = 3)
#' @export
ApproxiW <- function(W, lambda, order = NULL, tol = 1e-6, max_order = 50L) {
  if (!is.matrix(W) && !inherits(W, "Matrix")) {
    W <- as.matrix(W)
  }
  n <- nrow(W)
  if (n != ncol(W)) stop("`W` must be square.")

  if (is.null(order)) {
    order <- choose_approxiw_order(W = W, lambda = lambda, tol = tol, max_order = max_order)
  } else {
    order <- suppressWarnings(as.integer(order)[1])
    if (!is.finite(order) || order < 1L) order <- 1L
  }

  iW <- Matrix::Diagonal(n) + lambda * W
  if (order <= 1L) return(iW)

  A <- W
  b <- lambda
  for (i in 2:order) {
    A <- A %*% W
    b <- lambda * b
    iW <- iW + b * A
  }
  iW
}
