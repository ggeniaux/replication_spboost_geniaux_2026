#' BSPA_SEM_ML
#' BSPA_SEM_ML allows the estimation of additive non linear SAR models using the gradient
#' boosting method for estimating the non linear part while the estimation of the spatial parameter is based on a concentrated
#' likelihood function. This function makes it possible to estimate an additive non linear
#' SAR model while automatically selecting the explanatory variables.
#' @usage BSPA_SEM_ML(formula,data,W,control=boost_control(),verbose=0)
#' @param formula a gambboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param control boost_control() see mboost help.
#' @param verbose verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = TRUE, myseed = 12
#' )
#' fit <- BSPA_SEM_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' fit$rho
#' summary(fit)
BSPA_SEM_ML=function(formula,data,W,control=boost_control(),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  stage_cfg <- spb_make_stage1_boost_control(control)
  control_stage1 <- stage_cfg$control_stage1
  control_final <- stage_cfg$control_final
  env=environment()
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef, env, which = 1)
  {
    I <- get("I", envir = env)
    if (which == 1) {
      W <- get("W", envir = env)
    }
    else {
      W <- get("W2", envir = env)
    }
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## sar.error.f from spatialreg package
  sar.error.f<-function (SSE,lambda, env)
  {
    s2 <- SSE/n
    ldet <- LU_ldet(lambda, env, which = 1)
    ret <- (ldet + (1/2) * get("sum_lw", envir = env) - ((n/2) *    #### sum_lw=0 si pas de poids
                                                           log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  ## custom family (loss & gradient) adapted for SEM model
  cust_loss_sem = function(I_rhoW){
    Family(ngradient = function(y, f,w=1) as.numeric(I_rhoW%*%(y - f)),
           loss = function(y, f) as.numeric((I_rhoW%*%(y - f))^2),
           name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W")
  }
  ## custom loglig using gamboost instead of lm for finding Beta coefficients
  loglig.gamboost_SEM<-function(rho,formula,data,control_fit,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    I_rhoW=Diagonal(nrow(W))-rho*W
    glmboostC=gamboost(formula, data=data,control=control_fit,family =cust_loss_sem(I_rhoW))

    SSE=sum(((I-rho*W)%*%(data[,as.character(attr(terms(formula),'variables')[[2]])]-as.numeric(fitted(glmboostC))))^2)

    sar.error.f(SSE,rho, env)
  }

  ## step 1: if mstop0 is not provided by the user, finding an appropriate mstop0 for a given set of rho using cross-validation
  # min_cv=NULL
  # search_mstop=is.null(mstop0)
  # if(search_mstop){
  #   if(verbose>0) cat('Approximation mstop0 using cvrisk (25 kfolds) with rho=',rho0,' \n')
  #   mstop0=c()
  #   for(rho_temp in rho0){
  #     I_rhoW=Diagonal(nrow(W))-rho_temp*W
  #     gamboost_sem=gamboost(formula, data=data,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sem(I_rhoW))
  #     cv5f <- cv(model.weights(gamboost_sem), type = "kfold",B=5)
  #     cvm <- cvrisk(gamboost_sem, folds = cv5f, mc.cores = ncores)
  #     mstop0=c(mstop0,mstop(cvm))
  #   }
  #   if(verbose>0) cat('mstop0 mean of ', mstop0,'\n')
  #   mstop0=ceiling(mean(mstop0))
  #   if(verbose>0) cat('mstop0=', mstop0,'\n')
  # }

  ## step 2: optiming loglig.gamboost_SEM for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  if(verbose>0 && isTRUE(stage_cfg$two_stage)) cat('Two-stage ML objective with stage1 mstop=', stage_cfg$stage1_mstop, ' / final mstop=', stage_cfg$final_mstop, '\n')
  res=optimize(loglig.gamboost_SEM,lower=-0.99,upper=0.99,control_fit=control_stage1,formula=formula,data=data, W=W,maximum =TRUE)
  rho=res$maximum
  I_rhoW=Diagonal(nrow(W))-rho*W
  if(verbose>0) cat('rho=', rho)

  # ## step 3: if mstop0 is not provided by the user, finding  mstop0 for rho using cross-validation
  # if(search_mstop){
  #   if(verbose>0)  cat(' with mstop=mstop0 \n Start final optimization of mstop \n')
  #   gamboost_sem=gamboost(formula, data=data,control=control,family =cust_loss_sem(I_rhoW))
  #   cv5f <- cv(model.weights(gamboost_sem), type = "kfold",B=5)
  #   cvm <- cvrisk(gamboost_sem, folds = cv5f, mc.cores = ncores)
  #   min_cv<-sqrt(mean(cvm[,which.min(colMeans(cvm))]))
  #   mstop0=mstop(cvm)
  #   if(verbose>0) cat('mstop=', mstop0,'\n')
  #   if(verbose>0) cat('min(cv) =',min_cv)
  # }
  #
  # ## step 4:  estimation of final model using gamboost with optimal rho & mstop.
  gamboost_sem=gamboost(formula, data=data,control=control_final,family =cust_loss_sem(I_rhoW))
  gamboost_sem$rho=rho
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  Y_pred= fitted(gamboost_sem)
  gamboost_sem$residuals=(Y-Y_pred)
  gamboost_sem$Y=Y
  gamboost_sem$fitted=Y_pred
  gamboost_sem$fittedYS=Y_pred
  gamboost_sem$rmse=sqrt(mean(gamboost_sem$residuals^2))
  gamboost_sem$formula=formula
  gamboost_sem$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  gamboost_sem$ml_stage1_mstop <- stage_cfg$stage1_mstop
  gamboost_sem$ml_final_mstop <- stage_cfg$final_mstop
  class(gamboost_sem)<-c('spboost','BSPA_SEM_ML',class(gamboost_sem))
  return(gamboost_sem)
}
