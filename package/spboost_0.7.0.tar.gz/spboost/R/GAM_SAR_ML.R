#' GAM_SAR_ML
#' GAM_SAR_ML allows the estimation of additive non linear SAR models
#' using GAM/IPRLS  with thin plate regression spline (mgcv package)
#' for non linear part while the estimation of the spatial parameter
#' is based on a concentrated likelihood function.
#' @usage GAM_SAR_ML(formula,data,W,verbose=0)
#' @param formula a gam formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Autocorrelation.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @return An object of class "gam" (see mgcv package), augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 19
#' )
#' fit <- GAM_SAR_ML(Y ~ X1 + X2 + X3, data = sim$data, W = sim$W)
#' fit$rho
#' summary(fit)
GAM_SAR_ML=function(formula,data,W,verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  data$Endogenous_spboost<-Y<-data[,as.character(attr(terms(formula),'variables')[[2]])]
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef, env, which = 1)
  {
    I <- get("I", envir = env)
    if (which == 1) {
      W <- get("W", envir = env)
    }
    else {
      W <- get("W2", envir = env)
    }
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## lagsar.error.f from spatialreg package
  lagsar.error.f<-function (Y,fit,W,rho, env)
  {
    e=Y-fit-rho*W%*%Y
    SSE=sum(e^2)
    s2 <- SSE/n
    ldet <- LU_ldet(rho, env, which = 1)
    ret <- (ldet-((n/2) *log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  ## custom family (loss & gradient) adapted for SAR model
  cust_loss_sar = function(W,rho){
    I_rhoW=Diagonal(nrow(W))-rho*W
    Family(ngradient = function(y, f,w=1) as.numeric(I_rhoW%*%y - f),
           loss = function(y, f) as.numeric((I_rhoW%*%y - f)^2),
           name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W")
  }
  ## custom loglig using gam instead of lm for finding Beta coefficients
  loglig.gam_SAR<-function(rho,formula,data,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    data$Endogenous_spboost_spfiltered=data$Endogenous_spboost-as.numeric(rho*W%*%data$Endogenous_spboost)
    formulaYS=update(formula,'Endogenous_spboost_spfiltered~.')
    gambC=gam(formulaYS, data=data)
    #gambC=gamboost(formulaYS, data=data,control=boost_control(mstop=250, nu=0.3))
    #gambC=gamboost(formulaY, data=data,control=boost_control(mstop=360, nu=0.3),family =cust_loss_sar(W,rho))
    lagsar.error.f(Y=data[,as.character(attr(terms(formula),'variables')[[2]])],fit=fitted(gambC),W=W,rho=rho, env)
  }
  ## step 1: optiming loglig.gam_SAR for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  res=optimize(loglig.gam_SAR,lower=-0.99,upper=0.99,formula=formula,data=data,W=W,maximum =TRUE)
  rho=res$maximum

  ## step 2:  estimation of final model using glmboost with optimal rho & mstop.
  data$Endogenous_spboost_spfiltered=data$Endogenous_spboost-as.numeric(rho*W%*%data$Endogenous_spboost)
  formulaYS=update(formula,'Endogenous_spboost_spfiltered~.')
  gambC=gam(formulaYS, data=data)
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  fittedYS=fitted(gambC)
  gambC$fitted= as.numeric(rho*W %*%Y)+fittedYS
  gambC$fittedYS=fittedYS
  gambC$rho<-rho
  gambC$rmse<-sqrt(mean(gambC$residuals^2))
  gambC$Y<-Y
  class(gambC)<-c('spboost','GAM_SAR_ML',class(gambC)[-3])
  return(gambC)
}
