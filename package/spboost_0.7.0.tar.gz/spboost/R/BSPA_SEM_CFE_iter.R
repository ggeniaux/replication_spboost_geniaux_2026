#' BSPA_SEM_CFE_iter
#' Iterative CFE estimator for additive nonlinear SEM with joint updates of
#' spatial parameter and boosting fit.
#' @usage BSPA_SEM_CFE_iter(formula,data,W,control=boost_control(),
#'                          iter_max=1L,tol_lambda=1e-4,
#'                          doMC=FALSE,cfe_aux_cv=FALSE,
#'                          cfe_cv_nfold=5L,cfe_cv_ncore=1L,cfe_cv_seed=NULL,
#'                          fallback=c('auto','none'),
#'                          rho_bounds=c(-0.99,0.99),tol=1e-10,verbose=0)
#' @param formula a gamboost formula.
#' @param data a data.frame.
#' @param W a row-standardized spatial weight matrix.
#' @param control boost_control() object used in each boosting step.
#' @param iter_max maximum number of fixed-point iterations for (\eqn{\lambda}, \eqn{f}).
#' @param tol_lambda convergence tolerance on successive \eqn{\lambda}.
#' @param doMC logical; if TRUE and `cfe_aux_cv=FALSE`, auxiliary CFE fits can run in parallel.
#' @param cfe_aux_cv logical; if TRUE, tune `mstop` by standard k-fold CV in each auxiliary CFE regression.
#' @param cfe_cv_nfold number of CV folds for auxiliary CFE regressions.
#' @param cfe_cv_ncore number of workers for auxiliary CFE CV (`mboost::cvrisk`).
#' @param cfe_cv_seed optional seed for auxiliary CFE CV.
#' @param fallback fallback strategy when the quadratic CFE step has no real root.
#' @param rho_bounds lower/upper admissible bounds for \eqn{\lambda}.
#' @param tol numerical tolerance used for near-singular cases.
#' @param verbose verbosity level (0/1).
#' @return An object of class mboost augmented with SEM spatial outputs.
BSPA_SEM_CFE_iter <- function(formula,data,W,control=boost_control(),
                              iter_max=1L,tol_lambda=1e-4,
                              doMC=FALSE,cfe_aux_cv=FALSE,
                              cfe_cv_nfold=5L,cfe_cv_ncore=1L,cfe_cv_seed=NULL,
                              fallback=c('auto','none'),
                              rho_bounds=c(-0.99,0.99),tol=1e-10,verbose=0){
  fallback <- match.arg(fallback)
  iter_max <- suppressWarnings(as.integer(iter_max[[1]]))
  if (!is.finite(iter_max) || iter_max < 1L) iter_max <- 1L
  tol_lambda <- suppressWarnings(as.numeric(tol_lambda[[1]]))
  if (!is.finite(tol_lambda) || tol_lambda <= 0) tol_lambda <- 1e-4
  tol <- suppressWarnings(as.numeric(tol[[1]]))
  if (!is.finite(tol) || tol <= 0) tol <- 1e-10
  cfe_aux_cv <- isTRUE(cfe_aux_cv)
  cfe_cv_nfold <- suppressWarnings(tryCatch(as.integer(cfe_cv_nfold[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_nfold) == 0L || !is.finite(cfe_cv_nfold[1]) || cfe_cv_nfold[1] < 2L) {
    cfe_cv_nfold <- 5L
  } else {
    cfe_cv_nfold <- as.integer(cfe_cv_nfold[1])
  }
  cfe_cv_ncore <- suppressWarnings(tryCatch(as.integer(cfe_cv_ncore[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_ncore) == 0L || !is.finite(cfe_cv_ncore[1]) || cfe_cv_ncore[1] < 1L) {
    cfe_cv_ncore <- 1L
  } else {
    cfe_cv_ncore <- as.integer(cfe_cv_ncore[1])
  }
  cfe_cv_seed <- suppressWarnings(tryCatch(as.integer(cfe_cv_seed[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_seed) == 0L || !is.finite(cfe_cv_seed[1])) {
    cfe_cv_seed <- NA_integer_
  } else {
    cfe_cv_seed <- as.integer(cfe_cv_seed[1])
  }

  ptm1 <- proc.time()
  YX <- get_all_vars(formula, data)
  Y <- as.numeric(YX[, 1])
  X <- as.matrix(YX[, -1])
  namesX <- colnames(X)
  n <- length(Y)

  # Build auxiliary CFE data/formulas exactly as in BSPA_SEM_CFE
  data_aux <- data
  data_aux$Y <- Y
  data_aux$WY <- as.numeric(W %*% Y)
  WX <- data.frame(as.matrix(W %*% X))
  colnames(WX) <- paste0("WX.", namesX)
  data_aux <- cbind(data_aux, WX)
  f0 <- f1 <- formula
  td_form <- td_form2 <- formula[3]
  for (i in namesX) {
    td_form2 <- gsub(i, paste0("WX.", i), td_form2)
  }
  td_form0 <- paste0("Y~.+", as.name(td_form2))
  td_form1 <- paste0("WY~.+", as.name(td_form2))
  f0 <- update.formula(f0, td_form0)
  f1 <- update.formula(f1, td_form1)

  fit_aux_sem_cv <- function(ff, seed_shift = 0L) {
    mstop_max <- suppressWarnings(as.integer(control$mstop[[1]]))
    if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L
    control_max <- control
    control_max$mstop <- as.integer(mstop_max)
    fit_max <- gamboost(ff, data = data_aux, control = control_max)
    if (mstop_max <= 1L || cfe_cv_nfold < 2L) {
      return(list(model = fit_max, best_mstop = as.integer(mboost::mstop(fit_max)), cv_rmse = NA_real_))
    }
    if (is.finite(cfe_cv_seed)) set.seed(as.integer(cfe_cv_seed + seed_shift))
    folds <- mboost::cv(model.weights(fit_max), type = "kfold", B = cfe_cv_nfold)
    if (.Platform$OS.type != "windows" && cfe_cv_ncore > 1L) {
      cv_obj <- mboost::cvrisk(
        fit_max, folds = folds, grid = seq_len(mstop_max),
        papply = parallel::mclapply, mc.cores = cfe_cv_ncore, mc.preschedule = FALSE
      )
    } else {
      cv_obj <- mboost::cvrisk(
        fit_max, folds = folds, grid = seq_len(mstop_max),
        papply = lapply
      )
    }
    best_mstop <- suppressWarnings(as.integer(mboost::mstop(cv_obj)))
    if (!is.finite(best_mstop) || best_mstop < 1L) best_mstop <- as.integer(mstop_max)
    fit_use <- fit_max
    suppressWarnings(try(mboost::mstop(fit_use) <- best_mstop, silent = TRUE))
    cv_rmse <- NA_real_
    cv_mat <- tryCatch(unclass(cv_obj), error = function(e) NULL)
    if (is.matrix(cv_mat) && ncol(cv_mat) >= best_mstop) {
      cv_mse <- mean(cv_mat[, best_mstop], na.rm = TRUE)
      if (is.finite(cv_mse) && cv_mse >= 0) cv_rmse <- sqrt(cv_mse)
    }
    list(model = fit_use, best_mstop = best_mstop, cv_rmse = cv_rmse)
  }

  fit_aux_pair <- function() {
    if (cfe_aux_cv) {
      if (isTRUE(doMC)) {
        warning("BSPA_SEM_CFE_iter: `doMC=TRUE` ignored when `cfe_aux_cv=TRUE`; running auxiliary CV fits sequentially.")
      }
      fit0 <- fit_aux_sem_cv(f0, seed_shift = 0L)
      fit1 <- fit_aux_sem_cv(f1, seed_shift = 1L)
      return(list(
        m0 = fit0$model,
        m1 = fit1$model,
        mstop_y = fit0$best_mstop,
        mstop_wy = fit1$best_mstop,
        cv_rmse_y = fit0$cv_rmse,
        cv_rmse_wy = fit1$cv_rmse
      ))
    }

    if (isTRUE(doMC)) {
      registerDoParallel(cores = 2)
      MM <- foreach::foreach(myrep = 1:2, .combine = "cbind") %dopar% {
        ff <- if (myrep == 1L) f0 else f1
        list(gamboost(ff, data = data_aux, control = control))
      }
      return(list(
        m0 = MM[[1]], m1 = MM[[2]],
        mstop_y = as.integer(mboost::mstop(MM[[1]])),
        mstop_wy = as.integer(mboost::mstop(MM[[2]])),
        cv_rmse_y = NA_real_, cv_rmse_wy = NA_real_
      ))
    }

    m0 <- gamboost(f0, data = data_aux, control = control)
    m1 <- gamboost(f1, data = data_aux, control = control)
    list(
      m0 = m0, m1 = m1,
      mstop_y = as.integer(mboost::mstop(m0)),
      mstop_wy = as.integer(mboost::mstop(m1)),
      cv_rmse_y = NA_real_, cv_rmse_wy = NA_real_
    )
  }

  cust_loss_sem <- function(I_lW) {
    mboost::Family(
      ngradient = function(y, f, w = 1) as.numeric(I_lW %*% (y - f)),
      loss = function(y, f) as.numeric((I_lW %*% (y - f))^2),
      name = "SEM with I_lW=Diagonal(nrow(W))-lambda*W"
    )
  }

  lambda_old <- 0
  lambda_new <- NA_real_
  rho_method <- NA_character_
  rho_exact_root <- NA_integer_
  lambda_path <- numeric(iter_max + 1L)
  lambda_path[1] <- lambda_old
  model_iter <- NULL
  mstop_aux_y <- NA_integer_
  mstop_aux_wy <- NA_integer_
  cv_rmse_aux_y <- NA_real_
  cv_rmse_aux_wy <- NA_real_
  a_last <- NA_real_
  b_last <- NA_real_
  e0_last <- NULL
  e1_last <- NULL
  iter_done <- 0L

  for (iter in seq_len(iter_max)) {
    aux <- fit_aux_pair()
    m0 <- aux$m0
    m1 <- aux$m1
    mstop_aux_y <- aux$mstop_y
    mstop_aux_wy <- aux$mstop_wy
    cv_rmse_aux_y <- aux$cv_rmse_y
    cv_rmse_aux_wy <- aux$cv_rmse_wy

    e0 <- as.numeric(residuals(m0))
    e1 <- as.numeric(residuals(m1))
    e0_last <- e0
    e1_last <- e1

    a <- as.numeric(t(e1) %*% W %*% e1)
    b <- as.numeric(t(e0) %*% W %*% e1 + t(e1) %*% W %*% e0)
    cc <- as.numeric(t(e0) %*% W %*% e0)
    a_last <- a
    b_last <- b
    D <- b^2 - 4 * a * cc

    if (D < 0 && abs(D) <= tol) D <- 0
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      cand_all <- c((b - sqrtD) / (2 * a), (b + sqrtD) / (2 * a))
      ok <- is.finite(cand_all)
      if (any(ok)) {
        cand <- cand_all[ok]
        root_idx <- which(ok)
        in_bounds <- cand >= rho_bounds[1] & cand <= rho_bounds[2]
        if (any(in_bounds)) {
          cand_eval <- cand[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          cand_eval <- pmin(pmax(cand, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(cand_eval, function(lam) {
          r <- e0 - lam * e1
          sum(r^2)
        }, numeric(1))
        best <- which.min(score)
        lambda_new <- as.numeric(cand_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method <- "cfe_exact"
      } else {
        lambda_new <- NA_real_
      }
    } else if (fallback == "auto") {
      den_w <- as.numeric(t(e1) %*% W %*% e1)
      num_w <- as.numeric(t(e1) %*% W %*% e0)
      if (abs(den_w) > tol) {
        lambda_new <- num_w / den_w
        rho_method <- "cfe_weighted_projection"
      }
    }

    if (!is.finite(lambda_new)) {
      err <- paste0("CFE_iter failed at iteration ", iter, ": no admissible lambda.")
      class(err) <- "error"
      return(err)
    }

    lambda_new <- max(rho_bounds[1], min(rho_bounds[2], lambda_new))
    lambda_path[iter + 1L] <- lambda_new
    iter_done <- iter

    I_lW <- Matrix::Diagonal(n) - lambda_new * W
    model_iter <- gamboost(formula, data = data, control = control, family = cust_loss_sem(I_lW))

    if (isTRUE(verbose > 0)) {
      cat(sprintf("Iter %d: lambda=%.6f -> %.6f (delta=%.3e)\n",
                  iter, lambda_old, lambda_new, abs(lambda_new - lambda_old)))
    }

    if (abs(lambda_new - lambda_old) < tol_lambda) break
    lambda_old <- lambda_new
  }

  if (!is.finite(lambda_new)) lambda_new <- lambda_old
  lambda_path <- lambda_path[seq_len(iter_done + 1L)]
  if (is.null(model_iter)) {
    I_lW <- Matrix::Diagonal(n) - lambda_new * W
    model_iter <- gamboost(formula, data = data, control = control, family = cust_loss_sem(I_lW))
  }
  model_final <- model_iter
  e <- as.numeric(Y - fitted(model_final))
  yhat_final <- as.numeric(fitted(model_final))

  den_var <- as.numeric(b_last - 2 * lambda_new * a_last)
  if (is.finite(den_var) && abs(den_var) > tol && !is.null(e0_last) && !is.null(e1_last)) {
    var_rho <- as.numeric((t(e0_last - lambda_new * e1_last) %*% (e0_last - lambda_new * e1_last) / n) / den_var)
  } else {
    var_rho <- NA_real_
  }

  model_final$rho <- as.numeric(lambda_new)
  model_final$rho_method <- rho_method
  model_final$rho_exact_root <- rho_exact_root
  model_final$var_rho <- var_rho
  model_final$residuals <- e
  model_final$Y <- Y
  model_final$fitted <- yhat_final
  model_final$fittedYS <- yhat_final
  model_final$rmse <- sqrt(mean(e^2))
  model_final$cfe_aux <- list(
    aux_cv_enabled = cfe_aux_cv,
    aux_cv_nfold = as.integer(cfe_cv_nfold),
    aux_cv_ncore = as.integer(cfe_cv_ncore),
    aux_cv_seed = if (is.finite(cfe_cv_seed)) as.integer(cfe_cv_seed) else NA_integer_,
    mstop_y = mstop_aux_y,
    mstop_wy = mstop_aux_wy,
    cv_rmse_y = cv_rmse_aux_y,
    cv_rmse_wy = cv_rmse_aux_wy
  )
  model_final$n_iter <- as.integer(iter_done)
  model_final$lambda_trajectory <- as.numeric(lambda_path)
  model_final$tol_lambda <- tol_lambda
  model_final$iter_max <- as.integer(iter_max)
  model_final$elapsed <- as.numeric((proc.time() - ptm1)[3])
  class(model_final) <- c("spboost", "BSPA_SEM_CFE_iter", class(model_final))
  model_final
}
