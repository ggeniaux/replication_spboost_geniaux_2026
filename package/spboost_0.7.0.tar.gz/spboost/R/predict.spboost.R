#' Predict Method For `spboost` Objects
#' @method predict spboost
#' @usage \method{predict}{spboost}(
#'   object, newdata = NULL, data = NULL, W = NULL, W2 = NULL,
#'   type = "BPN", maxobs = 25000, chunksize = 4000, ...
#' )
#' @param object a fitted object returned by `spbgam` (class `spboost`).
#' @param newdata optional data frame for prediction.
#' @param data optional in-sample data (required with `W` for BLUP-style out-of-sample prediction).
#' @param W optional full-sample row-normalized matrix (required with `data` for BLUP-style out-of-sample prediction).
#' @param W2 optional second full-sample row-normalized matrix (SARAR only). If missing, defaults to `W`.
#' @param type prediction type for spatial correction, default `"BPN"`.
#' @param maxobs integer, beyond maxobs an approximation of solve(I -rho*W) is used (ApproxiW functions).
#' @param chunksize predict.mboost are done by chunk of size equal to chunksize to avoid memory problem.
#' @param ... additional arguments passed to the underlying estimator `predict()`.
#' @return A numeric vector of predictions.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 5
#' )
#' train_id <- 1:400
#' test_id <- 401:500
#' W_train <- sim$W[train_id, train_id, drop = FALSE]
#' row_sum_train <- Matrix::rowSums(W_train)
#' W_train <- Matrix::Diagonal(
#'   x = ifelse(row_sum_train > 0, 1 / row_sum_train, 0)
#' ) %*% W_train
#' fit <- spbgam(
#'   Y ~ X1 + X2 + X3, data = sim$data[train_id, ], W = W_train,
#'   DGP = "SAR", method = "BSPA_SAR_CFE",
#'   control = list(control_gamboost = mboost::boost_control(mstop = 5, nu = 0.2))
#' )
#' fit$rho
#' summary(fit)
#' pred_new<-predict(
#'   fit,
#'   newdata = sim$data[test_id, ],
#'   data = sim$data[train_id, ],
#'   W = sim$W
#' )
#' head(pred_new)
#' head(sim$data[test_id,'Y'])
#' # diff RMSE train - test
#' fit$rmse
#' rmse_test<-sqrt(mean((pred_new-sim$data[test_id, 'Y'])^2))
#' rmse_test
#' @export
predict.spboost <- function(object, newdata = NULL, data = NULL, W = NULL, W2 = NULL, type = "BPN", maxobs = 25000, chunksize = 4000, ...) {
  use_spatial_blup <- !is.null(newdata) && !is.null(data) && !is.null(W)
  if (isTRUE(use_spatial_blup)) {
    return(predict_spboost(
      model = object,
      newdata = newdata,
      data = data,
      W = W,
      W2 = W2,
      type = type,
      maxobs = maxobs,
      chunksize = chunksize
    ))
  }

  # Fall back to native estimator prediction when no (data,W) is supplied.
  if (!is.null(object$booster) && inherits(object$booster, "xgb.Booster")) {
    if (is.null(newdata)) {
      return(stats::predict(object$booster, ...))
    }
    formulaXGB <- as.formula(paste0('~', as.character(object$formula)[3]))
    return(stats::predict(object$booster, xgboost::xgb.DMatrix(model.matrix(formulaXGB, newdata)), ...))
  }
  base_obj <- object
  class(base_obj) <- setdiff(class(base_obj), c("spboost", "spbbost"))
  if (is.null(newdata)) {
    return(stats::predict(base_obj, ...))
  }
  stats::predict(base_obj, newdata = newdata, ...)
}

#' @export
predict.spbbost <- function(object, ...) {
  predict.spboost(object, ...)
}

#' predict.spboost
#' A prediction function for object of class GAM_SAR_FIVA, GAM_SAR_ML, BSPA_SAR_ML, MARS_SAR_ML,
#' BLA_SAR_2SLS, BLA_SAR_ML, BLA_SAR_2SLS, XGBOOST_LINEAR_SAR_ML, XGBOOST_SAR_ML,
#' XGBOOST_LINEAR_SAR_CFE, XGBOOST_SAR_CFE.
#' and glmboost_sar.
#' @usage predict_spboost(model,newdata,data,W,W2=NULL,type = "BPN",maxobs=25000,chunksize=4000)
#' @param model a model of class spboost
#' @param newdata a dataframe with out-sample data.
#' @param data a dataframe with in-sample data.
#' @param W a row-normalized weight matrix for the full sample (in-sample + out-sample) using same spatial weighting scheme as that used for model estimation.
#' @param W2 optional second row-normalized matrix (SARAR only). If NULL, `W2=W`.
#' @param type for BLUP estimator, default "BPN". If NULL use predictions without spatial bias correction.
#' @param maxobs integer, beyond maxobs an approximation of solve(I -rho*W) is used (ApproxiW functions).
#' @param chunksize predict.mboost are done by chunk of size equal to chunksize to avoid memory problem.
#' @return A vector of prediction.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 6
#' )
#' train_id <- 1:400
#' test_id <- 401:500
#' W_train <- sim$W[train_id, train_id, drop = FALSE]
#' row_sum_train <- Matrix::rowSums(W_train)
#' W_train <- Matrix::Diagonal(
#'   x = ifelse(row_sum_train > 0, 1 / row_sum_train, 0)
#' ) %*% W_train
#' fit <- spbgam(
#'   Y ~ X1 + X2 + X3, data = sim$data[train_id, ], W = W_train,
#'   DGP = "SAR", method = "BSPA_SAR_CFE",
#'   control = list(control_gamboost = mboost::boost_control(mstop = 5, nu = 0.2))
#' )
#' fit$rho
#' summary(fit)
#' predict_spboost(
#'   fit,
#'   newdata = sim$data[test_id, ],
#'   data = sim$data[train_id, ],
#'   W = sim$W
#' )
predict_spboost <- function(model,newdata,data,W,W2=NULL,type = "BPN",maxobs=25000,chunksize=4000){

  data_SO=data.frame(data.table::rbindlist(list(data,newdata), fill = TRUE))
  model_classes <- class(model)
  has_model_class <- function(x) any(model_classes %in% x)
  is_sarar_model <- any(grepl("_SARAR_", model_classes, fixed = TRUE))
  if (is.null(W2)) W2 <- W
  allowed_classes <- c(
    'BSPA_SAR_CFE','BLA_SAR_CFE','MARS_SAR_CFE','GAM_SAR_CFE','GAM_SAR_FIVA','GAM_SAR_ML','BSPA_SAR_ML','MARS_SAR_ML','LM_SAR_ML','glmboost_sarIV','BLA_SAR_ML','BLA_SAR_2SLS','XGBOOST_LINEAR_SAR_ML','XGBOOST_SAR_ML','XGBOOST_LINEAR_SAR_CFE','XGBOOST_SAR_CFE',
    'BSPA_SEM_ML','BSPA_SEM_CFE','BSPA_SEM_CFE_iter','BSPA_SEM_CFE_BRUT','MARS_SEM_ML','MARS_SEM_CFE','GAM_SEM_CFE','glmboost_sem','BLA_SEM_ML',
    'BSPA_SARAR_ML','BSPA_SARAR_CFE','BLA_SARAR_ML'
  )
  if(!has_model_class(allowed_classes)) stop('Wrong class: an object of class SAR/SEM/SARAR spboost estimator is required')

  is_sem_model <- any(grepl("_SEM_", model_classes, fixed = TRUE)) || has_model_class(c("glmboost_sem"))
  if (isTRUE(is_sarar_model)) {
    Y <- model$Y
    S <- seq_len(length(model$residuals))
    O <- (length(model$residuals) + 1):(length(model$residuals) + nrow(newdata))
    n <- length(c(S, O))
    if (length(W) != n^2) stop(" W should be a row normalized matrix of dim (S+0,S+O)")
    if (length(W2) != n^2) stop(" W2 should be a row normalized matrix of dim (S+0,S+O)")

    rho <- as.numeric(model$rho)[1]
    lambda <- as.numeric(model$lambda)[1]
    if (!is.finite(rho) || !is.finite(lambda)) {
      stop("SARAR prediction requires finite `rho` and `lambda` in `model`.")
    }

    XB <- rep(NA_real_, n)
    XB[S] <- as.numeric(model$fittedYS)

    av <- all.vars(model$formula)[-1]
    if (has_model_class(c('XGBOOST_LINEAR_SAR_ML','XGBOOST_SAR_ML','XGBOOST_LINEAR_SAR_CFE','XGBOOST_SAR_CFE'))) {
      formulaXGB <- as.formula(paste0('~', as.character(model$formula)[3]))
      xgb_model <- if (!is.null(model$booster)) model$booster else model
      XB[O] <- as.numeric(predict(xgb_model, xgboost::xgb.DMatrix(model.matrix(formulaXGB, newdata))))
    } else {
      XB[O] <- as.numeric(predict(model, newdata[, av, drop = FALSE]))
    }

    I_n <- Diagonal(n, 1)
    A1 <- I_n - rho * W
    A2 <- I_n - lambda * W2
    # A * Y = XB, with A = (I-lambda W2)(I-rho W)
    YTC <- tryCatch(
      as.numeric(spb_solve_nested_spatial_rhs(W, rho, W2, lambda, XB, direct_max_n = maxobs, tol = 1e-6, max_order = 50L)),
      error = function(e) {
        as.numeric(ApproxiW_apply(W, rho, ApproxiW_apply(W2, lambda, XB, tol = 1e-6, max_order = 50L), tol = 1e-6, max_order = 50L))
      }
    )

    if (identical(type, "BPN")) {
      nS <- length(S)
      I_s <- Diagonal(nS, 1)
      WS <- W[S, S, drop = FALSE]
      W2S <- W2[S, S, drop = FALSE]
      A1S <- I_s - rho * WS
      A2S <- I_s - lambda * W2S

      if (!is.null(model$fittedYS) && length(model$fittedYS) == nS) {
        e_filt <- as.numeric(A2S %*% ((A1S %*% Y[S]) - as.numeric(model$fittedYS)))
      } else if (!is.null(model$residuals) && length(model$residuals) == nS) {
        e_filt <- as.numeric(model$residuals)
      } else {
        e_filt <- as.numeric(Y[S] - as.numeric(model$fitted[S]))
      }
      sigma2 <- mean(e_filt^2)
      if (!is.finite(sigma2) || sigma2 <= 0) sigma2 <- 1e-8

      A <- A2 %*% A1
      Q <- as.matrix((Matrix::t(A) %*% A) / sigma2)
      res <- YTC[O] - solve(Q[O, O, drop = FALSE]) %*% Q[O, S, drop = FALSE] %*% (Y[S] - YTC[S])
      return(as.numeric(res))
    }
    return(as.numeric(YTC[O]))
  }

  if (is_sem_model) {
    base_model <- model
    class(base_model) <- setdiff(class(base_model), c("spboost", "spbbost"))
    av <- if (!is.null(model$formula)) {
      setdiff(all.vars(model$formula), all.vars(model$formula)[1])
    } else {
      character(0)
    }
    newdata_use <- if (length(av) > 0L && all(av %in% names(newdata))) newdata[, av, drop = FALSE] else newdata
    pred_sem <- tryCatch(
      as.numeric(stats::predict(base_model, newdata = newdata_use)),
      error = function(e) as.numeric(stats::predict(base_model, newdata = newdata))
    )
    return(pred_sem)
  }
  #if(class(model)[1]=='gam')
  Y=model$Y
  e=model$residuals
  S=1:length(model$residuals)
  O=(length(model$residuals)+1):(length(model$residuals)+nrow(newdata))
  n=length(c(S,O))

  ####
  if(length(W)!=n^2) stop(' W should be a row normalized matrix of dim (S+0,S+O)')
  lambda_hat=model$rho
  sigma2 = mean(e^2)
  ###
  XB<-rep(NA,n)
  XB[S]=model$fittedYS

  if(has_model_class(c('XGBOOST_LINEAR_SAR_ML','XGBOOST_SAR_ML','XGBOOST_LINEAR_SAR_CFE','XGBOOST_SAR_CFE')))
  {
    formulaXGB<-as.formula(paste0('~', as.character(model$formula)[3]))
    xgb_model <- if (!is.null(model$booster)) model$booster else model
    XB[O]=as.numeric(predict(xgb_model,xgboost::xgb.DMatrix(model.matrix(formulaXGB,newdata))))
  } else if (!is.null(model$signal_model)) {
      av <- all.vars(model$formula)[-1]
      XB[O]=as.numeric(predict(model$signal_model,newdata[,av,drop=FALSE]))
  } else {
      av<-all.vars(model$formula)[-1]
      XB[O]=as.numeric(predict(model,newdata[,av]))
    }
  YTC = spb_solve_spatial_rhs(W, lambda_hat, XB, direct_max_n = maxobs, tol = 1e-6, max_order = 50L)
  if (type == "BPN") {
    Q = (Diagonal(n, 1) - lambda_hat * (W + Matrix::t(W)) + lambda_hat^2 * (Matrix::t(W) %*%W))/sigma2
    res = YTC[O] - solve(Q[O, O]) %*% Q[O, S] %*% (Y[S] -YTC[S])
    } else res = YTC[O]
  as.numeric(res)
}

if(FALSE){
  J = S[which(Matrix::rowSums(W[S, O]) > 0)]  ### J inSample avec poids non null
  JO = unique(c(sort(J), sort(O)))
  WJ <- W[JO, JO]   #### WJ = W inSample avec poids non null + outsample
  rs <- Matrix::rowSums(WJ)
  sup0 <- rs > 0
  WJ[sup0, ] <- WJ[sup0, ]/rs[sup0]
  m = length(JO)
  J2 = 1:length(J)
  O2 = (length(J) + 1):m
  if(length(lambda_hat)>1) lambda_hat<-lambda_hat[JO]


  Q = (Diagonal(m, 1) - lambda_hat * (WJ + Matrix::t(WJ)) + lambda_hat^2 * (Matrix::t(WJ) %*%WJ))/sigma2
  if(m < maxobs) iWJ = solve(as.matrix(Diagonal(m, 1) - lambda_hat *WJ)) else iWJ = ApproxiW(WJ, lambda_hat, 8)
  if(class(model)[length(class(model))] %in% c('BSPA_SAR_ML','BLA_SAR_ML')) {
    av<-all.vars(model$formula)
    XB=as.numeric(predict(model,data_SO[JO,av]))
    if(any(is.na(XB))) stop('memory problem fo predict.mboost')
  } else if(class(model)[length(class(model))] %in% c('GAM_SAR_ML','GAM_SAR_FIVA')) {
    XB=as.numeric(predict(model,data_SO[JO,]))
  } else if(class(model)[length(class(model))] %in% c('XGBOOST_LINEAR_SAR_ML','XGBOOST_SAR_ML')) {
    formulaXGB<-as.formula(paste0('~', as.character(model$formula)[3]))
    XB=as.numeric(predict(model,model.matrix(formulaXGB,data_SO[JO,])))
  } else if(class(model)[length(class(model))] %in% c('BLA_SAR_2SLS')) {
    stop('predict not yet implemented for BLA_SAR_2SLS model')
  }
  YTC = iWJ %*% XB
  if (type == "BPN") res = YTC[O2] - solve(Q[O2, O2]) %*% Q[O2, J2] %*% (Y[J] -YTC[J2]) else res = YTC[O2]
  as.numeric(res)
}
#test=predict_spboost(model,data_out,data_in,W)
