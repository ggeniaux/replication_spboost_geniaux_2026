#' BSPA_SAR_ML
#' BSPA_SAR_ML allows the estimation of additive non linear SAR models using gradient boosting for the non linear part while the spatial parameter is estimated with a concentrated likelihood function. This function makes it possible to estimate an additive non linear SAR model while automatically selecting the explanatory variables.
#' @usage BSPA_SAR_ML(formula,data,W,RHO=NULL,WW=NULL,control=boost_control(),verbose=0)
#' @param formula a gamboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation
#' @param RHO a vector of rho values
#' @param WW a list of row-standardized spatial weight matrix for Spatial Aurocorrelation, default NULL
#' @param control boost_control() see mboost help.
#' @param verbose verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 11
#' )
#' fit <- BSPA_SAR_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' fit$rho
#' summary(fit)
BSPA_SAR_ML=function(formula,data,W,RHO=NULL,WW=NULL,control=boost_control(),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  stage_cfg <- spb_make_stage1_boost_control(control)
  control_stage1 <- stage_cfg$control_stage1
  control_final <- stage_cfg$control_final
  if(is.null(WW) | is.null(RHO)) {
    if(!is.list(W)) W<-list(W)
  } else if(!is.null(WW)) W<-WW
  env=environment()
  data$Endogenous_spboost<-Y<-data[,as.character(attr(terms(formula),'variables')[[2]])]
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef,W,env,which=1)
  {
    I <- get("I", envir = env)
    # if (which == 1) {
    #   W <- get("W", envir = env)
    # }
    # else {
    #   W <- get("W2", envir = env)
    # }
    #ICI
    n=get("n", envir = env)
    if(length(coef)>1) iW=(I - coef[2] *W[[2]]) %*% (I - coef[1] *W[[1]]) else  iW=(I - coef *W[[1]])
    LU <- lu(iW)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## lagsar.error.f from spatialreg package
  lagsar.error.f<-function (Y,e,W,RHO,env)
  {
    #e=Y-rho*W%*%Y-fit
    SSE=sum(e^2)
    s2 <- SSE/n
    ldet <- LU_ldet(RHO, W, env, which = 1)
    ret <- (ldet-((n/2) *log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  ## custom family (loss & gradient) adapted for SAR model
  cust_loss_sar = function(I_rhoW){
    Family(ngradient = function(y, f,w=1) as.numeric(I_rhoW%*%y - f),
           loss = function(y, f) as.numeric((I_rhoW%*%y - f)^2),
           name = "SAR with I_rhoW=Diagonal(nrow(W))-rho*W")
  }
  ## custom loglig using gamboost instead of lm for finding Beta coefficients
  loglig.gamboost_SAR<-function(rho,RHO=NULL,formula,data,control_fit,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    if(is.null(WW)) {
      RHO=rho
      iW=(I - rho *W[[1]])
    } else {
      RHO=c(rho,RHO)
      iW=(I - RHO[2] *W[[2]] - RHO[1] *W[[1]])
    }
    data$Endogenous_spboost_spfiltered=as.numeric(iW %*%data$Endogenous_spboost)
    formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
    #I_rhoW=Diagonal(nrow(W))-rho*W
    gamboostC=gamboost(formula2, data=data,control=control_fit)#,family =cust_loss_sar(I_rhoW)
    lagsar.error.f(Y=data[,as.character(attr(terms(formula),'variables')[[2]])],e=residuals(gamboostC),W=W,RHO=RHO, env) #
  }

  ## step 1: if mstop0 is not provided by the user, finding an appropriate mstop0 for a given set of rho using cross-validation
  #
  # search_mstop=is.null(mstop0)
  # if(search_mstop){
  #   if(verbose>0) cat('Approximation mstop0 using cvrisk (',nfold,'  kfolds) with rho=',rho0,' \n')
  #   mstop0=c()
  #   for(rho_temp in rho0){
  #     data$Endogenous_spboost_spfiltered=as.numeric(data$Endogenous_spboost-rho_temp*W%*%data$Endogenous_spboost)
  #     gamboost_sar=gamboost(formula2, data=data,control=boost_control(mstop=mstop_init, nu=nu)) #,family =cust_loss_sar(W,rho)
  #       cv5f <- cv(model.weights(gamboost_sar), type = "kfold",B=5)
  #       cvm <- cvrisk(gamboost_sar, folds = cv5f, mc.cores = ncores)
  #     mstop0=c(mstop0,mstop(cvm))
  #   }
  #   if(verbose>0) cat('mstop0 mean of ', mstop0,'\n')
  #   mstop0=ceiling(mean(mstop0))
  #   if(verbose>0) cat('mstop0=', mstop0,'\n')
  # }

  ## step 2: optiming loglig.gamboost_SAR for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  if(verbose>0 && isTRUE(stage_cfg$two_stage)) cat('Two-stage ML objective with stage1 mstop=', stage_cfg$stage1_mstop, ' / final mstop=', stage_cfg$final_mstop, '\n')
  res=optimize(loglig.gamboost_SAR,lower=-0.99,upper=0.99,control_fit=control_stage1,formula=formula,data=data,W=W,RHO=RHO,maximum =TRUE)
    rho=res$maximum
  if(verbose>0)  cat('rho=', rho, 'with final mstop=', stage_cfg$final_mstop,' \n')

  ## step 3: if mstop0 is not provided by the user, finding  mstop0 for rho using cross-validation
  # min_cv<-NULL
  # data$Endogenous_spboost_spfiltered=as.numeric(data$Endogenous_spboost-rho*W%*%data$Endogenous_spboost)
  # if(search_mstop){
  #   gamboost_sar=gamboost(formula2, data=data,control=boost_control(mstop=mstop_init, nu=nu))# family =cust_loss_sar(W,rho)
  #   if(verbose>0) cat('Start final optimization of mstop \n')
  #   cv5f <- cv(model.weights(gamboost_sar), type = "kfold",B=5)
  #   cvm <- cvrisk(gamboost_sar, folds = cv5f, mc.cores = ncores)
  #   min_cv<-sqrt(mean(cvm[,which.min(colMeans(cvm))]))
  #   mstop0=mstop(cvm)
  #   if(verbose>0) cat('mstop=', mstop0,'\n')
  #   if(verbose>0) cat('Out_sample cv =',min_cv,'\n')
  # }

  ## step 4:  estimation of final model using glmboost with optimal rho & mstop.
  if(!is.null(WW)) iW=(I - rho*W[[2]] - RHO *W[[1]]) else iW=(I - rho*W[[1]])
  data$Endogenous_spboost_spfiltered=as.numeric(iW %*% data$Endogenous_spboost)
  formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
  gamboost_sar=gamboost(formula2, data=data,control=control_final) # ,family =cust_loss_sar(W,rho)
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  fittedYS=fitted(gamboost_sar)
  # Keep the same fitted definition as other SAR estimators:
  #Y_hat = rho*W*Y + fittedYS #(generalized as (I - iW)%*%Y + fittedYS)
  Y_pred=as.numeric(rho*W[[1]] %*%Y)+fittedYS
  residuals_pred <- as.numeric(Y - Y_pred)
  residuals_filtered <- as.numeric((I - rho * W[[1]]) %*% Y - fittedYS)
  if(is.null(WW)) gamboost_sar$rho=rho else gamboost_sar$rho=c(RHO,rho)
  gamboost_sar$residuals<-residuals_pred
  gamboost_sar$residuals_pred <- residuals_pred
  gamboost_sar$residuals_filtered <- residuals_filtered
  gamboost_sar$Y=Y
  gamboost_sar$fitted=Y_pred
  gamboost_sar$fittedYS=fittedYS
  gamboost_sar$logl=res$objective
  gamboost_sar$rmse=sqrt(mean((gamboost_sar$residuals)^2))
  gamboost_sar$formula=formula
  gamboost_sar$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  gamboost_sar$ml_stage1_mstop <- stage_cfg$stage1_mstop
  gamboost_sar$ml_final_mstop <- stage_cfg$final_mstop
  class(gamboost_sar)<-c('spboost','BSPA_SAR_ML',class(gamboost_sar))
  if(verbose>0) cat('RMSE =',gamboost_sar$rmse,'\n')
  return(gamboost_sar)
}
