globalVariables(c('mstop0',"gamC","X" ,"mvrnorm", "n",'myrep','W','data','normW','i'))
