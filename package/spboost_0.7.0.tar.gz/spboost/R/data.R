#' datatest is a simulated data for spatial autoregressive non linear model
#'
#' @name datatest
#' @author Ghislain Geniaux \email{ghislain.geniaux@inrae.fr}
NULL

