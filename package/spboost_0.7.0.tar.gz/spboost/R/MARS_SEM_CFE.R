#' MARS_SEM_CFE
#' MARS_SEM_CFE estimates nonlinear SEM models using a MARS backend
#' (`earth::earth`) and the CFE approach for the spatial error parameter.
#' @usage MARS_SEM_CFE(formula,data,W,control=boost_control(),control_earth=list(),
#' doMC=FALSE,ncores=3,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10)
#' @param formula a model formula. mboost-style terms are converted to an earth-compatible formula.
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial autocorrelation.
#' @param control \code{boost_control()} object (used for compatibility and optional defaults for \code{control_earth}).
#' @param control_earth list of control parameters passed to \code{earth::earth}
#' (e.g. \code{degree}, \code{nprune}, \code{nk}, \code{penalty}, \code{thresh}, \code{trace}).
#' Optional CV tuning of \code{nprune} is available with
#' \code{use_cv_nprune=TRUE} and controls
#' \code{cv_nfold}, \code{cv_ncore}, \code{cv_mode},
#' \code{cv_nprune_grid} (or \code{cv_nprune_min/max/length}).
#' @param doMC deprecated, ignored. CFE pre-fits are now sequential.
#' @param ncores deprecated, ignored. CFE pre-fits are now sequential.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses projection fallback, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @return An object of class \code{earth}, augmented with \code{spboost} fields
#' including \code{rho}, \code{rmse}, fitted values and residuals.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = TRUE, myseed = 24
#' )
#' fit <- MARS_SEM_CFE(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   control_earth = list(degree = 1, nk = 10, nprune = 5)
#' )
#' fit$rho
#' summary(fit)
#' @export
MARS_SEM_CFE <- function(formula, data, W, control = boost_control(), control_earth = list(),
                         doMC = FALSE, ncores = 3, fallback = c("auto", "none"),
                         rho_bounds = c(-0.99, 0.99), tol = 1e-10) {
  fallback <- match.arg(fallback)
  rho_bounds <- as.numeric(rho_bounds)
  if (length(rho_bounds) != 2L || any(!is.finite(rho_bounds))) rho_bounds <- c(-0.99, 0.99)
  rho_bounds <- sort(rho_bounds)
  if (isTRUE(doMC)) {
    warning("doMC is deprecated and ignored in MARS_SEM_CFE(); CFE pre-fits are sequential.")
  }

  ptm_global <- proc.time()
  lambda_switch <- suppressWarnings(as.numeric(getOption("spboost.sem_cfe.lambda_switch", 0.9))[1])
  if (!is.finite(lambda_switch)) lambda_switch <- 0.9
  lambda_switch <- max(rho_bounds[1], min(rho_bounds[2], lambda_switch))

  YX <- get_all_vars(formula, data)
  Y <- as.numeric(YX[, 1])
  X <- as.matrix(YX[, -1, drop = FALSE])
  namesX <- colnames(X)
  response_name <- as.character(attr(terms(formula), "variables")[[2]])
  n <- nrow(data)

  data_aug <- data
  data_aug$Y <- Y
  data_aug$WY <- as.numeric(W %*% Y)
  WX <- data.frame(as.matrix(W %*% X))
  colnames(WX) <- paste0("WX.", namesX)
  data_aug <- cbind(data_aug, WX)

  f0 <- f1 <- formula
  td_form2 <- formula[3]
  for (i in namesX) {
    td_form2 <- gsub(i, paste0("WX.", i), td_form2)
  }
  td_form0 <- paste0("Y~.+", as.name(td_form2))
  td_form1 <- paste0("WY~.+", as.name(td_form2))
  f0 <- update.formula(f0, td_form0)
  f1 <- update.formula(f1, td_form1)

  control_earth_use <- control_earth
  earth_nprune_selection <- tryCatch(
    spb_tune_earth_nprune(
      formula = f0,
      data = data_aug,
      control_earth = control_earth_use,
      control_gamboost = control
    ),
    error = function(e) list(status = "error", message = conditionMessage(e))
  )
  if (!is.null(earth_nprune_selection$best_nprune) &&
      is.finite(as.numeric(earth_nprune_selection$best_nprune[[1]]))) {
    control_earth_use$nprune <- as.integer(earth_nprune_selection$best_nprune[[1]])
  }

  fit_earth <- function(ff, d) {
    spb_fit_earth_model(
      formula = ff,
      data = d,
      control_earth = control_earth_use,
      control_gamboost = control
    )
  }

  make_sem_transformed_data <- function(rho) {
    y_tf <- as.numeric(Y - rho * data_aug$WY)
    x_tf <- as.matrix(X - rho * as.matrix(WX))
    d_tf <- as.data.frame(x_tf)
    colnames(d_tf) <- namesX
    d_tf[[response_name]] <- y_tf
    d_tf
  }

  fit_filtered <- function() {
    ptm <- proc.time()
    m0 <- fit_earth(f0, data_aug)
    m1 <- fit_earth(f1, data_aug)
    e0 <- residuals(m0)
    e1 <- residuals(m1)
    a <- as.numeric(t(e1) %*% W %*% e1)
    b <- as.numeric(t(e0) %*% W %*% e1 + t(e1) %*% W %*% e0)
    cc <- as.numeric(t(e0) %*% W %*% e0)
    D <- b^2 - 4 * a * cc

    rho <- NA_real_
    rho_method <- NA_character_
    rho_exact_root <- NA_integer_
    if (D < 0 && abs(D) <= tol) D <- 0
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      rho_candidates <- c(
        as.numeric((b - sqrtD) / (2 * a)),
        as.numeric((b + sqrtD) / (2 * a))
      )
      ok <- is.finite(rho_candidates)
      if (any(ok)) {
        rho_candidates <- rho_candidates[ok]
        root_idx <- which(ok)
        in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
        if (any(in_bounds)) {
          rho_eval <- rho_candidates[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(
          rho_eval,
          function(rh) sum((e0 - rh * e1)^2),
          numeric(1)
        )
        best <- which.min(score)
        rho <- as.numeric(rho_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method <- "cfe_exact"
      }
    } else if (fallback == "auto") {
      den_w <- as.numeric(t(e1) %*% W %*% e1)
      num_w <- as.numeric(t(e1) %*% W %*% e0)
      if (abs(den_w) > tol) {
        rho <- num_w / den_w
        rho_method <- "cfe_weighted_projection"
      }
    }

    if (is.na(rho) || !is.finite(rho)) {
      model <- paste0("CFE failed: no admissible SEM lambda (D=", signif(D, 6), ", a=", signif(a, 6), ").")
      class(model) <- "error"
      return(model)
    }

    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    data_tf <- make_sem_transformed_data(rho)
    model <- fit_earth(formula, data_tf)
    Y_pred <- as.numeric(fitted(model))
    e <- (Y - Y_pred)
    den_var <- (b - 2 * rho * a)
    if (abs(den_var) > tol) {
      model$var_rho <- as.numeric((t(e0 - rho * e1) %*% (e0 - rho * e1) / n) / den_var)
    } else {
      model$var_rho <- NA_real_
    }
    model$residuals <- e
    model$rmse <- sqrt(mean(model$residuals^2))
    model$fittedYS <- fitted(model)
    model$fitted <- Y - model$residuals
    model$rho <- rho
    model$rho_method <- rho_method
    model$rho_exact_root <- rho_exact_root
    model$D <- D
    model$elapsed <- as.numeric((proc.time() - ptm)[3])
    class(model) <- c("spboost", "MARS_SEM_CFE", class(model))
    model
  }

  fit_brut <- function() {
    ptm <- proc.time()
    model_ols <- fit_earth(formula, data)
    e_brut <- as.numeric(Y - fitted(model_ols))
    We <- as.numeric(W %*% e_brut)
    WWe <- as.numeric(W %*% We)

    a <- sum(We * WWe)
    b <- sum(e_brut * WWe) + sum(We * We)
    cc <- sum(e_brut * We)
    D <- b^2 - 4 * a * cc
    if (D < 0 && abs(D) <= tol) D <- 0

    rho <- NA_real_
    rho_exact_root <- NA_integer_
    rho_method_raw <- NA_character_
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      rho_candidates <- c(
        as.numeric((b - sqrtD) / (2 * a)),
        as.numeric((b + sqrtD) / (2 * a))
      )
      ok <- is.finite(rho_candidates)
      if (any(ok)) {
        rho_candidates <- rho_candidates[ok]
        root_idx <- which(ok)
        in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
        if (any(in_bounds)) {
          rho_eval <- rho_candidates[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(
          rho_eval,
          function(rh) sum((e_brut - rh * We)^2),
          numeric(1)
        )
        best <- which.min(score)
        rho <- as.numeric(rho_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method_raw <- "cfe_brut_residuals"
      }
    }
    if (!is.finite(rho)) {
      den1 <- sum(We^2)
      if (is.finite(den1) && abs(den1) > tol) {
        rho <- cc / den1
        rho_method_raw <- "cfe_brut_projection"
      } else {
        rho <- 0
        rho_method_raw <- "cfe_brut_init_fallback"
      }
    }

    if (identical(fallback, "none") &&
        !(is.character(rho_method_raw) && length(rho_method_raw) == 1L &&
          !is.na(rho_method_raw) &&
          rho_method_raw %in% c("cfe_brut_residuals", "cfe_brut_iter_exact"))) {
      if (is.na(rho_method_raw) || !nzchar(rho_method_raw)) rho_method_raw <- "unknown"
      model <- paste0(
        "CFE failed: no admissible exact SEM lambda in BRUT backend (rho_method=",
        rho_method_raw, ")."
      )
      class(model) <- "error"
      return(model)
    }

    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    data_tf <- make_sem_transformed_data(rho)
    model <- fit_earth(formula, data_tf)
    Y_pred <- as.numeric(fitted(model))
    e <- (Y - Y_pred)
    den_var <- (b - 2 * rho * a)
    if (abs(den_var) > tol) {
      model$var_rho <- as.numeric((sum((e_brut - rho * We)^2) / n) / den_var)
    } else {
      model$var_rho <- NA_real_
    }

    rho_method <- if (is.character(rho_method_raw) && length(rho_method_raw) == 1L && !is.na(rho_method_raw)) {
      switch(
        rho_method_raw,
        cfe_brut_residuals = "cfe_exact",
        cfe_brut_iter_exact = "cfe_exact",
        cfe_brut_projection = "cfe_weighted_projection",
        cfe_brut_init_fallback = "cfe_weighted_projection",
        rho_method_raw
      )
    } else {
      rho_method_raw
    }

    model$residuals <- e
    model$rmse <- sqrt(mean(model$residuals^2))
    model$fittedYS <- fitted(model)
    model$fitted <- Y - model$residuals
    model$rho <- rho
    model$rho_method_raw <- rho_method_raw
    model$rho_method <- rho_method
    model$rho_exact_root <- rho_exact_root
    model$D <- D
    model$elapsed <- as.numeric((proc.time() - ptm)[3])
    class(model) <- c("spboost", "MARS_SEM_CFE", class(model))
    model
  }

  model_brut <- fit_brut()
  if (inherits(model_brut, "error")) return(model_brut)

  rho_brut <- suppressWarnings(as.numeric(model_brut$rho)[1])
  switched_to_filtered <- is.finite(rho_brut) && (rho_brut > lambda_switch)

  model <- model_brut
  backend_used <- "brut"
  if (switched_to_filtered) {
    model_filtered <- fit_filtered()
    if (inherits(model_filtered, "error")) {
      if (identical(fallback, "none")) {
        return(model_filtered)
      }
      warning("MARS_SEM_CFE: filtered switch failed after high BRUT rho; keeping BRUT estimate.")
      backend_used <- "brut_after_filtered_error"
    } else {
      model <- model_filtered
      backend_used <- "filtered"
    }
  }

  if (identical(backend_used, "filtered")) {
    rho_method_raw <- if (!is.null(model$rho_method)) as.character(model$rho_method[[1]]) else NA_character_
    model$rho_method_raw <- rho_method_raw
  }

  model$cfe_switch <- list(
    threshold = lambda_switch,
    rho_brut = if (is.finite(rho_brut)) rho_brut else NA_real_,
    switched_to_filtered = identical(backend_used, "filtered"),
    backend_used = backend_used
  )
  model$cfe_backend <- if (identical(backend_used, "filtered")) {
    "MARS_SEM_CFE_filtered"
  } else {
    "MARS_SEM_CFE_BRUT"
  }
  model$control_earth <- spb_make_earth_control(control_earth = control_earth_use, control_gamboost = control)
  model$earth_nprune_selection <- earth_nprune_selection
  model$elapsed <- as.numeric((proc.time() - ptm_global)[3])
  class(model) <- unique(c("spboost", "MARS_SEM_CFE", setdiff(class(model), c("spboost", "MARS_SEM_CFE"))))
  model
}
