#' SNR_SAR
#' Compute the theoretical signal-to-noise ratio for a SAR model.
#' @usage SNR_SAR(xb, W, rho, sigma_carre,
#'                 method = c("hutch", "exact"),
#'                 m = 64L, seed = NULL,
#'                 tau_B = NULL)
#' @param xb deterministic linear predictor (signal part before spatial filtering).
#' @param W row-standardized spatial weights matrix.
#' @param rho spatial autoregressive parameter.
#' @param sigma_carre noise variance.
#' @param method method used to compute \code{tau_B}: \code{"exact"} or \code{"hutch"}.
#' @param m number of Rademacher vectors for Hutchinson estimator.
#' @param seed optional random seed used only when \code{method="hutch"}.
#' @param tau_B optional precomputed \code{tr(B'B)} with \code{B=(I-rho W)^{-1}}.
#' @return A scalar SNR value in \code{[0,1]}.
#' @examples
#' W <- Matrix::Matrix(c(0, 1, 1, 0), nrow = 2, sparse = TRUE)
#' SNR_SAR(xb = c(1, -1), W = W, rho = 0.2, sigma_carre = 1)
#' @export
SNR_SAR <- function(xb, W, rho, sigma_carre,
                    method = c("hutch", "exact"),
                    m = 64L, seed = NULL,
                    tau_B = NULL) {
  method <- match.arg(method)
  n <- nrow(W)

  M <- Matrix::Diagonal(n) - rho * W
  A <- as.numeric(Matrix::solve(M, xb))
  signal <- sum(A * A)

  if (is.null(tau_B)) {
    if (method == "exact") {
      I <- Matrix::Diagonal(n)
      B <- Matrix::solve(M, I)
      tau_B <- sum(B * B)
    } else {
      if (!is.null(seed)) set.seed(seed)
      Z <- matrix(sample(c(-1, 1), n * m, replace = TRUE), n, m)
      Y <- as.matrix(Matrix::solve(M, Z))
      tau_B <- mean(colSums(Y * Y))
    }
  }

  signal / (signal + sigma_carre * tau_B)
}

#' SNR_SEM
#' Compute the theoretical signal-to-noise ratio for a SEM model.
#' @usage SNR_SEM(xb, W, rho, sigma_carre,
#'                 method = c("hutch", "exact"),
#'                 m = 64L, seed = NULL,
#'                 tau_B = NULL)
#' @param xb deterministic linear predictor (signal part).
#' @param W row-standardized spatial weights matrix.
#' @param rho spatial error parameter.
#' @param sigma_carre noise variance.
#' @param method method used to compute \code{tau_B}: \code{"exact"} or \code{"hutch"}.
#' @param m number of Rademacher vectors for Hutchinson estimator.
#' @param seed optional random seed used only when \code{method="hutch"}.
#' @param tau_B optional precomputed \code{tr(B'B)} with \code{B=(I-rho W)^{-1}}.
#' @return A scalar SNR value in \code{[0,1]}.
#' @examples
#' W <- Matrix::Matrix(c(0, 1, 1, 0), nrow = 2, sparse = TRUE)
#' SNR_SEM(xb = c(1, -1), W = W, rho = 0.2, sigma_carre = 1)
#' @export
SNR_SEM <- function(xb, W, rho, sigma_carre,
                    method = c("hutch", "exact"),
                    m = 64L, seed = NULL,
                    tau_B = NULL) {
  method <- match.arg(method)
  n <- nrow(W)

  M <- Matrix::Diagonal(n) - rho * W
  A <- as.numeric(xb)
  signal <- sum(A * A)

  if (is.null(tau_B)) {
    if (method == "exact") {
      I <- Matrix::Diagonal(n)
      B <- Matrix::solve(M, I)
      tau_B <- sum(B * B)
    } else {
      if (!is.null(seed)) set.seed(seed)
      Z <- matrix(sample(c(-1, 1), n * m, replace = TRUE), n, m)
      Y <- as.matrix(Matrix::solve(M, Z))
      tau_B <- mean(colSums(Y * Y))
    }
  }

  signal / (signal + sigma_carre * tau_B)
}
