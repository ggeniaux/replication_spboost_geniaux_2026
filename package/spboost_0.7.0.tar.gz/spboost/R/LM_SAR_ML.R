#' LM_SAR_ML
#' LM_SAR_ML allows the estimation of linear SAR model
#' @usage LM_SAR_ML(formula,data,W,RHO=NULL,WW=NULL,verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation
#' @param RHO a set of rho values (between -1 and 1)
#' @param WW a named list of candidate row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = FALSE, myseed = 21
#' )
#' fit <- LM_SAR_ML(Y ~ X1 + X2 + X3, data = sim$data, W = sim$W)
#' fit$rho
#' summary(fit)
LM_SAR_ML=function(formula,data,W,RHO=NULL,WW=NULL,verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  if(is.null(RHO)) {
    if(!is.list(W)) W<-list(W)
  }
  namesW=names(W)
  data$Endogenous_spboost<-Y<-data[,as.character(attr(terms(formula),'variables')[[2]])]
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef,W,env,which=1)
  {
    I <- get("I", envir = env)
    n=get("n", envir = env)
    if(length(coef)>1) {
      iW=I
      for(i in 1:length(coef))  iW=iW-coef[i] *W[[i]]
      #iW=(I - coef[2] *W[[2]] - coef[1] *W[[1]])
    } else  iW=(I - coef *W[[1]])
    LU <- lu(iW)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## lagsar.error.f from spatialreg package
  lagsar.error.f<-function (Y,e,W,RHO,env)
  {
    #e=Y-rho*W%*%Y-fit
    SSE=sum(e^2)
    s2 <- SSE/n
    ldet <- LU_ldet(RHO, W, env, which = 1)
    ret <- (ldet-((n/2) *log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  loglig.lm_SAR<-function(rho,RHO=NULL,formula,data,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    if(is.null(RHO)) {
      RHO=rho
      iW=(I - RHO *W[[1]])
    } else {
      RHO<-c(RHO,rho)
      iW=I
      for(i in 1:length(RHO))  iW=iW-RHO[i] *W[[i]]
    }
    data$Endogenous_spboost_spfiltered=as.numeric(iW %*%data$Endogenous_spboost)
    formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
    lm_sar=lm(formula2, data=data)
    lagsar.error.f(Y=data[,as.character(attr(terms(formula),'variables')[[2]])],e=residuals(lm_sar),W=W,RHO=RHO, env)
  }
  ## step 1: optiming loglig.glmboost_SAR for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  res=optimize(loglig.lm_SAR,lower=-0.99,upper=0.99,formula=formula,data=data,W=W,RHO=RHO,maximum =TRUE)
  rho=res$maximum
  if(verbose>0) cat('rho=', rho, '\n')

  ## step 2:  estimation of final model using glmboost with optimal rho & mstop.
  if(!is.null(RHO)){
    RHO<-c(RHO,rho)
    iW=I
    for(i in 1:length(RHO))  iW=iW-RHO[i] *W[[i]]
  } else iW=(I - rho*W[[1]])
  data$Endogenous_spboost_spfiltered=as.numeric(iW %*% data$Endogenous_spboost)
  formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
  lm_sar=lm(formula2, data=data)
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  fittedYS=fitted(lm_sar)
  Y_pred = as.numeric(
    spb_solve_linear_system(
      iW, fittedYS,
      direct_max_n = 25000L,
      tol = 1e-6,
      max_order = 50L
    )
  )
  lm_sar$residuals=Y-Y_pred

  if(is.null(RHO)) {
    names(rho)=namesW
    lm_sar$rho=rho
  } else {
    names(RHO)=namesW
    lm_sar$rho=RHO
  }
  lm_sar$Y=Y
  lm_sar$logl=res$objective
  lm_sar$AIC=-2* lm_sar$logl+ 2*(length(lm_sar$rho)+length(coefficients(lm_sar)))
  lm_sar$fitted=Y_pred
  lm_sar$fittedYS=fittedYS
  lm_sar$rmse=sqrt(mean(lm_sar$residuals^2))
  lm_sar$formula=formula
  class(lm_sar)<-c('spboost','LM_SAR_ML',class(lm_sar))
  return(lm_sar)
}
