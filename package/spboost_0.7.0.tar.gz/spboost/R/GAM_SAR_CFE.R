#' GAM_SAR_CFE
#' GAM_SAR_CFE allows the estimation of additive non linear SAR models using generalized additive models for the non linear part while the spatial parameter is estimated with the determinant-free Closed-Form Estimator of Smirnov (2020, doi:10.1111/gean.12268). This function makes it possible to estimate an additive non linear SAR model while automatically selecting the explanatory variables.
#' @usage GAM_SAR_CFE(formula,data,W,doMC=FALSE,ncores=3,
#' engine=c('auto','gam','bam'),bam_threshold=12000L,bam_discrete=TRUE,bam_nthreads=NULL,
#' fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10,
#' crossfit=FALSE,cf_nfold=5L,cf_folds=NULL,cf_coord_vars=c('x','y'),
#' cf_ncell=NULL,cf_seed=1L)
#' @param formula a gambboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param doMC deprecated, ignored. CFE pre-fits are now sequential.
#' @param ncores maximum number of threads used by \code{bam} defaults; capped at 3.
#' @param engine fitting backend for the non-spatial regressions:
#' \code{"gam"}, \code{"bam"} or \code{"auto"}.
#' @param bam_threshold threshold on sample size used when \code{engine="auto"}.
#' @param bam_discrete logical passed to \code{mgcv::bam(discrete=...)}.
#' @param bam_nthreads number of threads used by \code{bam}; platform-aware defaults apply.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses ratio/IV approximations, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @param crossfit logical; if \code{TRUE}, the residuals of the three
#' auxiliary regressions (of \code{Y}, \code{WY} and \code{W2Y} on the
#' additive dictionary) entering the closed-form quadratic are computed
#' out-of-fold (cross-fitting). The partialling-out score of the CFE is the
#' Neyman-orthogonal moment of the partially linear SAR; cross-fitting
#' removes the own-observation correlation between smoother estimation
#' error and residuals, the estimation-error channel of spatial
#' confounding. The final interpretable fit on \code{YS = Y - rho*WY}
#' remains full-sample.
#' @param cf_nfold number of folds (default 5).
#' @param cf_folds optional user-supplied integer fold vector of length n.
#' @param cf_coord_vars names of the coordinate columns used to build
#' scattered-block spatial folds (small kmeans cells assigned round-robin
#' to folds); random folds with a warning when absent.
#' @param cf_ncell number of kmeans cells (default about 10 per fold).
#' @param cf_seed seed for fold construction.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 4
#' )
#' fit <- GAM_SAR_CFE(Y ~ X1 + X2 + X3, data = sim$data, W = sim$W)
#' fit$rho
#' summary(fit)
GAM_SAR_CFE<-function(formula,data,W,doMC=FALSE,ncores=3,engine=c('auto','gam','bam'),bam_threshold=12000L,bam_discrete=TRUE,bam_nthreads=NULL,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10,crossfit=FALSE,cf_nfold=5L,cf_folds=NULL,cf_coord_vars=c('x','y'),cf_ncell=NULL,cf_seed=1L){
  fallback <- match.arg(fallback)
  engine <- match.arg(engine)
  if (isTRUE(doMC)) {
    warning("doMC is deprecated and ignored in GAM_SAR_CFE(); CFE pre-fits are sequential.")
  }
  ptm1<-proc.time()
  ## evaluate the response directly: get_all_vars() would also try to pull
  ## RHS symbols referenced inside smooth specs (e.g. xt = list(W = W) for
  ## bs = "spx"), which are not data columns
  Y=as.numeric(eval(formula[[2]], data, environment(formula)))
  data$Y=Y
  n=length(Y)
  bam_threshold <- as.integer(bam_threshold[[1]])
  if (!is.finite(bam_threshold) || bam_threshold < 1L) bam_threshold <- 12000L
  use_bam <- switch(engine, auto = n >= bam_threshold, gam = FALSE, bam = TRUE)

  bam_threads <- spb_bam_threads(bam_nthreads = bam_nthreads, ncores = ncores, max_threads = 3L)

  fit_backend <- function(ff, data, nthreads) {
    if (use_bam) {
      mgcv::bam(ff, data = data, discrete = isTRUE(bam_discrete), nthreads = nthreads)
    } else {
      mgcv::gam(ff, data = data)
    }
  }

  data$WY=as.numeric(W%*%Y)
  data$W2Y=as.numeric(W%*%data$WY)
  f0=formula
  f0<-update.formula(f0,'Y~.')
  f1<-update.formula(f0,'WY~.')
  f2<-update.formula(f0,'W2Y~.')
  if (isTRUE(crossfit)) {
    ## cross-fitted (out-of-fold) residuals: the partialling-out score of the
    ## CFE is Neyman-orthogonal, but its first-order insensitivity to errors
    ## in the nuisance fits only materializes when the residuals of Y, WY and
    ## W2Y are computed on observations not used to fit the smoothers
    ## (own-observation bias; the estimation-error channel of the geoadditive
    ## trap). The final interpretable fit on YS below remains full-sample.
    folds <- cf_folds
    if (is.null(folds)) {
      cf_nfold <- max(2L, as.integer(cf_nfold[[1]]))
      cvars <- cf_coord_vars[cf_coord_vars %in% names(data)]
      if (length(cvars) >= 2L) {
        folds <- spb_scatter_folds(as.matrix(data[cvars[1:2]]),
                                   nfold = cf_nfold, ncell = cf_ncell,
                                   seed = cf_seed)
      } else {
        warning("crossfit: coordinate columns '",
                paste(cf_coord_vars, collapse = "','"),
                "' not found in data; falling back to random folds",
                " (spatially leaky under strong dependence)")
        set.seed(cf_seed)
        folds <- sample(rep_len(seq_len(cf_nfold), n))
      }
    }
    folds <- as.integer(folds)
    if (length(folds) != n || anyNA(folds)) {
      stop("'cf_folds' must be a complete fold vector of length n")
    }
    e0 <- e1 <- e2 <- rep(NA_real_, n)
    for (k in sort(unique(folds))) {
      tr <- folds != k; te <- !tr
      f0k <- spb_cf_patch_spx(f0, tr)
      f1k <- spb_cf_patch_spx(f1, tr)
      f2k <- spb_cf_patch_spx(f2, tr)
      dtr <- data[tr, , drop = FALSE]
      dte <- data[te, , drop = FALSE]
      m0k <- fit_backend(f0k, data = dtr, nthreads = bam_threads)
      m1k <- fit_backend(f1k, data = dtr, nthreads = bam_threads)
      m2k <- fit_backend(f2k, data = dtr, nthreads = bam_threads)
      e0[te] <- data$Y[te]   - as.numeric(predict(m0k, dte))
      e1[te] <- data$WY[te]  - as.numeric(predict(m1k, dte))
      e2[te] <- data$W2Y[te] - as.numeric(predict(m2k, dte))
    }
  } else {
    m0 <- fit_backend(f0, data = data, nthreads = bam_threads)
    m1 <- fit_backend(f1, data = data, nthreads = bam_threads)
    m2 <- fit_backend(f2, data = data, nthreads = bam_threads)
    e0=residuals(m0)
    e1=residuals(m1)
    e2=residuals(m2)
  }
  a=as.numeric(t(e1) %*% e2)
  b=as.numeric(t(e0)%*% e2+t(e1) %*% e1)
  c=as.numeric(t(e0)%*% e1)
  D=b^2-4*a*c

  rho <- NA_real_
  rho_method <- NA_character_
  if (D < 0 && abs(D) <= tol) D <- 0
  if (abs(a) > tol && D >= 0) {
    rho <- as.numeric((b - sqrt(D))/(2*a))
    rho_method <- "cfe_exact"
  } else if (fallback == "auto") {
    den_r <- b
    if (abs(den_r) > tol) {
      rho <- as.numeric(c / den_r)
      rho_method <- "cfe_ratio_R"
    } else {
      den_iv <- as.numeric(t(e1) %*% e1)
      if (abs(den_iv) > tol) {
        rho <- as.numeric(c / den_iv)
        rho_method <- "cfe_iv"
      }
    }
  }

  if (is.na(rho) || !is.finite(rho)) {
    model <- paste0("CFE failed: no admissible SAR rho (D=", signif(D, 6), ", a=", signif(a, 6), ").")
    class(model) <- "error"
    return(model)
  }

  rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
  data$YS=as.numeric(Y-rho*data$WY)
  f3<-update.formula(f0,'YS~.')
  model=fit_backend(f3, data = data, nthreads = bam_threads)
  model$call[['formula']]=deparse(formula)
  #e=residuals(model)
  den_var <- (b-2*rho*a)
  if (abs(den_var) > tol) {
    model$var_rho=(t(e0-rho*e1) %*% (e0-rho*e1)/n)/den_var
    ## heteroskedasticity-robust variants (delta method on the quasi-score:
    ## var(rho_hat) = Var(sum_i m_i)/den^2 with m_i = u_i v_i). HC0 keeps the
    ## diagonal only; SHAC adds the cross-products of pairs within graph
    ## distance 2 of W (the moment contributions m_i, m_j are correlated for
    ## overlapping neighbourhoods because v contains W*eps), in the spirit of
    ## the spatial HAC of Kelejian and Prucha (2007).
    u <- as.numeric(e0 - rho*e1)
    v <- as.numeric(e1 - rho*e2)
    m <- u * v
    model$var_rho_hc0 <- sum(m^2) / den_var^2
    model$var_rho_shac <- tryCatch({
      Ws <- if (inherits(W, "Matrix")) W else Matrix::Matrix(W, sparse = TRUE)
      A <- abs(Ws) + abs(Matrix::t(Ws))
      A <- methods::as(A, "CsparseMatrix")
      A@x[] <- 1
      P <- A %*% A + A
      Matrix::diag(P) <- 0
      P@x[P@x != 0] <- 1
      (sum(m^2) + as.numeric(Matrix::crossprod(m, P %*% m))) / den_var^2
    }, error = function(e) NA_real_)
  } else {
    model$var_rho=NA_real_
    model$var_rho_hc0=NA_real_
    model$var_rho_shac=NA_real_
  }
  #model$var_rho=((t(e) %*% e)/n)/(b-2*a*rho)
  duree<-(proc.time()-ptm1)[3]
  model$residuals=residuals(model)
  model$rmse=sqrt(mean(model$residuals^2))
  model$fittedYS=fitted(model)
  model$fitted=Y-model$residuals
  model$rho=rho
  model$rho_method=rho_method
  model$crossfit=isTRUE(crossfit)
  if (isTRUE(crossfit)) model$cf_nfold=length(unique(folds))
  model$engine=if (use_bam) "bam" else "gam"
  model$bam_nthreads=if (use_bam) bam_threads else NA_integer_
  model$ncores_cfe=1L
  model$D=D
  model$elapsed=duree
  model$formula=formula
  model$Y=Y
  class(model)<-c('spboost','GAM_SAR_CFE',class(model))
  return(model)
}
