#' BLA_SAR_ML
#' BLA_SAR_ML allows the estimation of SAR models using the gradient boosting
#' method with linear base learner for estimating the coefficients Beta while
#' the estimation of the spatial parameter is based on a concentrated likelihood
#' function. This function makes it possible to estimate a SAR model while
#' automatically selecting the explanatory variables.
#' @usage BLA_SAR_ML(formula,data,W,center=TRUE,RHO=NULL,WW=NULL,
#' control=boost_control(),verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param RHO a vector of rho values, default NULL
#' @param WW  a list of row-standardized spatial weight matrices for Spatial Autocorrelation, default NULL
#' @param center a boolean, if covariate should be centered or not.
#' @param control boost_control() see mboost help.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = FALSE, myseed = 8
#' )
#' fit <- BLA_SAR_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' fit$rho
#' summary(fit)
BLA_SAR_ML=function(formula,data,W,center=TRUE,RHO=NULL,WW=NULL,control=boost_control(),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  stage_cfg <- spb_make_stage1_boost_control(control)
  control_stage1 <- stage_cfg$control_stage1
  control_final <- stage_cfg$control_final
  if(is.null(RHO)) {
    if(!is.list(W)) W<-list(W)
  }
  namesW=names(W)
  data$Endogenous_spboost<-Y<-data[,as.character(attr(terms(formula),'variables')[[2]])]
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef,W,env,which=1)
  {
    I <- get("I", envir = env)
    n=get("n", envir = env)
    if(length(coef)>1) {
      iW=I
      for(i in 1:length(coef))  iW=iW-coef[i] *W[[i]]
      #iW=(I - coef[2] *W[[2]] - coef[1] *W[[1]])
      } else  iW=(I - coef *W[[1]])
    LU <- lu(iW)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## lagsar.error.f from spatialreg package
  lagsar.error.f<-function (Y,e,W,RHO,env)
  {
    #e=Y-rho*W%*%Y-fit
    SSE=sum(e^2)
    s2 <- SSE/n
    ldet <- LU_ldet(RHO, W, env, which = 1)
    ret <- (ldet-((n/2) *log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  ## custom family (loss & gradient) adapted for SAR model
  cust_loss_sar = function(W,rho){
    I_rhoW=Diagonal(nrow(W))-rho*W
    Family(ngradient = function(y, f,w=1) as.numeric(I_rhoW%*%y - f),
           loss = function(y, f) as.numeric((I_rhoW%*%y - f)^2),
           name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W")
  }
  ## custom loglig using glmboost instead of lm for finding Beta coefficients
  loglig.glmboost_SAR<-function(rho,RHO=NULL,formula,data,control,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    if(is.null(RHO)) {
      RHO=rho
      iW=(I - RHO *W[[1]])
    } else {
      RHO<-c(RHO,rho)
      iW=I
      for(i in 1:length(RHO))  iW=iW-RHO[i] *W[[i]]
      #iW=(I - RHO[2] *W[[2]] - RHO[1] *W[[1]])
    }
    data$Endogenous_spboost_spfiltered=as.numeric(iW %*%data$Endogenous_spboost)
    formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
    glmboostC=glmboost(formula2, data=data,center=center,control=control)
    lagsar.error.f(Y=data[,as.character(attr(terms(formula),'variables')[[2]])],e=residuals(glmboostC),W=W,RHO=RHO, env)
  }

  # ## step 1: if mstop0 is not provided by the user, finding an appropriate mstop0 for a given set of rho using cross-validation
  # min_cv= NULL
  # search_mstop=is.null(mstop0)
  # if(search_mstop){
  #   if(verbose>0) cat('Approximation mstop0 using cvrisk (25 kfolds) with rho=',rho0,' \n')
  #   mstop0=c()
  #   for(rho_temp in rho0){
  #     glmboost_sar=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sar(W,rho_temp))
  #     cv5f <- cv(model.weights(glmboost_sar), type = "kfold",B=25)
  #     cvm <- cvrisk(glmboost_sar, folds = cv5f, mc.cores = ncores)
  #     mstop0=c(mstop0,mstop(cvm))
  #   }
  #   if(verbose>0) cat('mstop0 mean of ', mstop0,'\n')
  #   mstop0=ceiling(mean(mstop0))
  #   if(verbose>0) cat('mstop0=', mstop0,'\n')
  # }

  ## step 2: optiming loglig.glmboost_SAR for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  if(verbose>0 && isTRUE(stage_cfg$two_stage)) {
    cat('Two-stage ML objective with stage1 mstop=', stage_cfg$stage1_mstop,
        ' / final mstop=', stage_cfg$final_mstop, '\n')
  }
  res=optimize(loglig.glmboost_SAR,lower=-0.99,upper=0.99,control=control_stage1,formula=formula,data=data,W=W,RHO=RHO,maximum =TRUE)
  rho=res$maximum
  if(verbose>0) cat('rho=', rho, '\n')

  # ## step 3: if mstop0 is not provided by the user, finding  mstop0 for rho using cross-validation
  # if(search_mstop){
  #   glmboost_sar=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sar(W,rho))
  #   if(verbose>0) cat('Start final optimization of mstop \n')
  #   cv25f <- cv(model.weights(glmboost_sar), type = "kfold",B=25)
  #   cvm <- cvrisk(glmboost_sar, folds = cv25f, mc.cores = ncores)
  #   min_cv<-sqrt(mean(cvm[,which.min(colMeans(cvm))]))
  #   mstop0=mstop(cvm)
  #   if(verbose>0) cat('mstop=', mstop0,'\n')
  #   if(verbose>0) cat('min(cv) =',min_cv,'\n')
  # }

  ## step 4:  estimation of final model using glmboost with optimal rho & mstop.
  if(!is.null(RHO)){
    RHO<-c(RHO,rho)
    iW=I
    for(i in 1:length(RHO))  iW=iW-RHO[i] *W[[i]]
    } else iW=(I - rho*W[[1]])
  data$Endogenous_spboost_spfiltered=as.numeric(iW %*% data$Endogenous_spboost)
  formula2<-update.formula(formula,'Endogenous_spboost_spfiltered~.')
  glmboost_sar=glmboost(formula2, data=data,center=center,control=control_final)
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  fittedYS=fitted(glmboost_sar)
  Y_pred = as.numeric(
    spb_solve_linear_system(
      iW, fittedYS,
      direct_max_n = 25000L,
      tol = 1e-6,
      max_order = 50L
    )
  )
  glmboost_sar$residuals=Y-Y_pred

  if(is.null(RHO)) {
    names(rho)=namesW
    glmboost_sar$rho=rho
    } else {
      names(RHO)=namesW
      glmboost_sar$rho=RHO
    }
  glmboost_sar$Y=Y
  glmboost_sar$logl=res$objective
  glmboost_sar$AIC=-2* glmboost_sar$logl+ 2*(length(glmboost_sar$rho)+length(coefficients(glmboost_sar)))
  glmboost_sar$fitted=Y_pred
  glmboost_sar$fittedYS=fittedYS
  glmboost_sar$rmse=sqrt(mean(glmboost_sar$residuals^2))
  glmboost_sar$formula=formula
  glmboost_sar$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  glmboost_sar$ml_stage1_mstop <- stage_cfg$stage1_mstop
  glmboost_sar$ml_final_mstop <- stage_cfg$final_mstop
  class(glmboost_sar)<-c('spboost','BLA_SAR_ML',class(glmboost_sar))
  return(glmboost_sar)
}
