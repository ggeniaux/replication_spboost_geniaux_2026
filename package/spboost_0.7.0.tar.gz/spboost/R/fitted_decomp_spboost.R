#' fitted_decomp_spboost
#' Decompose fitted values of a spboost model by variable.
#' @usage fitted_decomp_spboost(model, newdata = NULL, include_offset = TRUE, include_total = TRUE, aggregate = TRUE, include_wy_resu = FALSE)
#' @param model an object returned by `spbgam` (`mboost`, `gam`/`glm`/`lm` or `xgboost` based classes).
#' @param newdata optional data.frame for out-of-sample decomposition. If `NULL`, in-sample fitted decomposition is returned.
#' @param include_offset logical, include the intercept in output (`Intercept` column).
#' @param include_total logical, include the summed fitted value (`Intercept + sum(contributions)`).
#' @param aggregate logical, if several terms map to the same variable name, aggregate them by summing contributions.
#' @param include_wy_resu logical, include `Wy` and `resU` contribution columns when present.
#' @return A data.frame with one column per variable contribution, and optional `Intercept` and `fitted`.
#' @details
#' Names are simplified to variable-level labels when possible (e.g. `bbs(X1, ...)` or `s(X1)` become `X1`).
#' Contributions are returned on the linear predictor scale of the fitted model.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 7
#' )
#' fit <- spbgam(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   DGP = "SAR", method = "BSPA_SAR_CFE",
#'   control = list(control_gamboost = mboost::boost_control(mstop = 5, nu = 0.2))
#' )
#' fit$rho
#' summary(fit)
#' head(fitted_decomp_spboost(fit))
fitted_decomp_spboost <- function(model, newdata = NULL, include_offset = TRUE, include_total = TRUE, aggregate = TRUE, include_wy_resu = FALSE) {
  if (inherits(model, "error")) {
    stop(paste0("Model estimation failed upstream: ", paste(as.character(model), collapse = " ")))
  }

  short_term_name <- function(x) {
    x <- trimws(x)
    if (!grepl("(", x, fixed = TRUE)) return(sub("^`(.*)`$", "\\1", x))
    inside <- sub("^[^(]*\\(", "", x)
    inside <- sub("\\).*$", "", inside)
    parts <- trimws(strsplit(inside, ",", fixed = TRUE)[[1]])
    parts <- parts[!grepl("=", parts, fixed = TRUE)]
    parts <- sub("^`(.*)`$", "\\1", parts)
    if (length(parts) == 0) return(sub("^`(.*)`$", "\\1", x))
    if (length(parts) == 1) return(parts[1])
    paste(parts, collapse = ":")
  }

  mk_df <- function(mat, names_vec = NULL) {
    if (is.list(mat) && !is.data.frame(mat)) {
      out <- as.data.frame(mat, check.names = FALSE)
      if (!is.null(names_vec)) names(out) <- names_vec
      return(out)
    }
    if (is.null(dim(mat))) mat <- matrix(as.numeric(mat), ncol = 1)
    out <- as.data.frame(mat, check.names = FALSE)
    if (!is.null(names_vec)) names(out) <- names_vec
    out
  }

  aggregate_cols <- function(df) {
    if (!aggregate || ncol(df) == 0 || !any(duplicated(names(df)))) return(df)
    u <- unique(names(df))
    out <- lapply(u, function(nm) rowSums(df[, names(df) == nm, drop = FALSE]))
    out <- as.data.frame(out, check.names = FALSE)
    names(out) <- u
    out
  }

  predict_link_like <- function(obj, newdata) {
    if (inherits(obj, "mboost")) {
      if (is.null(newdata)) return(as.numeric(predict(obj, type = "link")))
      return(as.numeric(predict(obj, newdata = newdata, type = "link")))
    }
    if (inherits(obj, "gam")) {
      # Use mgcv method explicitly: generic predict() may dispatch to
      # predict.spboost for class vectors starting with GAM_SAR_*.
      if (is.null(newdata)) return(as.numeric(mgcv::predict.gam(obj, type = "link")))
      return(as.numeric(mgcv::predict.gam(obj, newdata = newdata, type = "link")))
    }
    if (inherits(obj, "glm")) {
      if (is.null(newdata)) return(as.numeric(stats::predict.glm(obj, type = "link")))
      return(as.numeric(stats::predict.glm(obj, newdata = newdata, type = "link")))
    }
    if (inherits(obj, "lm")) {
      if (is.null(newdata)) return(as.numeric(stats::predict.lm(obj)))
      return(as.numeric(stats::predict.lm(obj, newdata = newdata)))
    }
    if (is.null(newdata)) return(as.numeric(predict(obj)))
    as.numeric(predict(obj, newdata = newdata))
  }

  predict_terms_like <- function(obj, newdata) {
    if (inherits(obj, "gam")) {
      if (is.null(newdata)) return(mgcv::predict.gam(obj, type = "terms"))
      return(mgcv::predict.gam(obj, newdata = newdata, type = "terms"))
    }
    if (inherits(obj, "glm") || inherits(obj, "lm")) {
      if (is.null(newdata)) return(stats::predict(obj, type = "terms"))
      return(stats::predict(obj, newdata = newdata, type = "terms"))
    }
    if (is.null(newdata)) return(predict(obj, type = "terms"))
    predict(obj, newdata = newdata, type = "terms")
  }

  predict_total_like <- function(obj, newdata, n_expected = NULL) {
    # In-sample: prefer the harmonized spboost field when available
    if (is.null(newdata) && !is.null(obj$fitted) && !is.function(obj$fitted)) {
      yhat <- tryCatch(as.numeric(obj$fitted), error = function(e) NULL)
      if (!is.null(yhat) && (is.null(n_expected) || length(yhat) == n_expected)) return(yhat)
    }
    # Fallback to class-specific prediction on link/response scale
    predict_link_like(obj, newdata)
  }

  out <- NULL

  if (inherits(model, "mboost")) {
    # Use all declared base-learners (not only selected ones) so requested
    # variable columns remain available with zero contribution when unselected.
    bl_names <- names(model$baselearner)
    if (is.null(bl_names) || length(bl_names) == 0) bl_names <- extract(model, "bnames")
    n <- length(predict_link_like(model, newdata))

    if (length(bl_names) == 0) {
      out <- data.frame(matrix(nrow = n, ncol = 0))
    } else {
      contrib <- lapply(seq_along(bl_names), function(i) {
        as.numeric(predict(model, newdata = newdata, which = i, type = "link"))
      })
      out <- mk_df(contrib, vapply(bl_names, short_term_name, character(1)))
    }

    out <- aggregate_cols(out)
    if (include_offset) {
      my_offset <- attr(coef(model), "offset")
      if (is.null(my_offset)) my_offset <- 0
      out$Intercept <- rep(as.numeric(my_offset), n)
    }
    if (include_total) out$fitted <- predict_total_like(model, newdata, n_expected = n)
  } else if (inherits(model, "gam") || inherits(model, "glm") || inherits(model, "lm")) {
    terms_mat <- predict_terms_like(model, newdata)
    n <- length(predict_link_like(model, newdata))

    if (is.null(dim(terms_mat)) || (length(dim(terms_mat)) == 2 && ncol(terms_mat) == 0)) {
      out <- data.frame(matrix(nrow = n, ncol = 0))
    } else {
      out <- mk_df(terms_mat, vapply(colnames(terms_mat), short_term_name, character(1)))
    }

    out <- aggregate_cols(out)
    if (include_offset) {
      cst <- attr(terms_mat, "constant")
      if (is.null(cst)) cst <- 0
      out$Intercept <- rep(as.numeric(cst), n)
    }
    if (include_total) out$fitted <- predict_total_like(model, newdata, n_expected = n)
  } else if (inherits(model, "xgb.Booster")) {
    if (is.null(newdata)) {
      stop("For xgboost models, please provide `newdata` (data.frame or matrix) to compute variable contributions.")
    }
    if (is.matrix(newdata)) {
      xmat <- newdata
    } else if (!is.null(model$formula)) {
      xmat <- model.matrix(model$formula, newdata)
    } else {
      xmat <- as.matrix(newdata)
    }

    contrib <- predict(model, newdata = xmat, predcontrib = TRUE)
    if (is.null(dim(contrib))) contrib <- matrix(contrib, nrow = 1)
    cn <- colnames(contrib)
    if (is.null(cn)) cn <- c(colnames(xmat), "BIAS")

    feat <- contrib[, seq_len(ncol(contrib) - 1), drop = FALSE]
    if (ncol(feat) > 0) {
      out <- mk_df(feat, vapply(cn[-ncol(contrib)], short_term_name, character(1)))
    } else {
      out <- data.frame(matrix(nrow = nrow(contrib), ncol = 0))
    }

    out <- aggregate_cols(out)
    if (include_offset) out$Intercept <- as.numeric(contrib[, ncol(contrib)])
    if (include_total) out$fitted <- as.numeric(predict(model, newdata = xmat))
  } else {
    stop("Unsupported model class. Supported families: mboost, gam/glm/lm, xgb.Booster.")
  }

  if (!include_wy_resu) {
    drop_cols <- intersect(c("Wy", "resU"), names(out))
    if (length(drop_cols) > 0) out <- out[, setdiff(names(out), drop_cols), drop = FALSE]
  }

  contrib_cols <- names(out)[!(names(out) %in% c("Intercept", "fitted"))]
  x_cols <- contrib_cols[grepl("^X[0-9]+$", contrib_cols)]
  if (length(x_cols) > 1) {
    x_cols <- x_cols[order(as.numeric(sub("^X", "", x_cols)))]
  }
  other_cols <- setdiff(contrib_cols, x_cols)
  ordered_cols <- c(x_cols, other_cols)
  out <- out[, c(if ("Intercept" %in% names(out)) "Intercept", ordered_cols, if ("fitted" %in% names(out)) "fitted"), drop = FALSE]
  out
}
