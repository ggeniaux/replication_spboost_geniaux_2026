spb_platform <- function() {
  sys <- tryCatch(tolower(Sys.info()[["sysname"]]), error = function(e) NA_character_)
  if (is.na(sys) || !nzchar(sys)) {
    if (.Platform$OS.type == "windows") {
      return("windows")
    }
    return("other")
  }
  if (sys == "darwin") return("mac")
  if (sys == "linux") return("linux")
  if (sys == "windows") return("windows")
  "other"
}

spb_cfe_workers <- function(ncores = NULL, max_workers = 3L) {
  avail <- suppressWarnings(parallel::detectCores(logical = FALSE))
  if (!is.finite(avail) || avail < 1L) {
    avail <- suppressWarnings(parallel::detectCores(logical = TRUE))
  }
  if (!is.finite(avail) || avail < 1L) avail <- 1L

  requested <- if (is.null(ncores)) max_workers else as.integer(ncores[[1]])
  if (!is.finite(requested) || requested < 1L) requested <- 1L

  as.integer(max(1L, min(max_workers, avail, requested)))
}

spb_bam_threads <- function(bam_nthreads = NULL, ncores = NULL, max_threads = 3L) {
  default_threads <- spb_cfe_workers(ncores = ncores, max_workers = max_threads)

  th <- if (is.null(bam_nthreads)) default_threads else as.integer(bam_nthreads[[1]])
  if (!is.finite(th) || th < 1L) th <- 1L
  th <- min(max_threads, th)
  as.integer(th)
}

spb_run_parallel_models <- function(formulas, data, fitter, do_parallel = FALSE, ncores = NULL, packages = character()) {
  if (!isTRUE(do_parallel) || length(formulas) <= 1L) {
    return(lapply(formulas, function(ff) fitter(ff, data = data)))
  }

  if (foreach::getDoParWorkers() > 1L) {
    warning("A parallel backend is already active; nested CFE parallelization is disabled for this call.")
    return(lapply(formulas, function(ff) fitter(ff, data = data)))
  }

  workers <- min(length(formulas), spb_cfe_workers(ncores = ncores, max_workers = 3L))
  if (workers <= 1L) {
    return(lapply(formulas, function(ff) fitter(ff, data = data)))
  }

  # Fork backend is typically much faster on Unix-like systems because it
  # avoids heavy object serialization.
  if (.Platform$OS.type != "windows") {
    return(parallel::mclapply(
      X = formulas,
      FUN = function(ff) fitter(ff, data = data),
      mc.cores = workers
    ))
  }

  cl <- parallel::makePSOCKcluster(workers)
  on.exit({
    parallel::stopCluster(cl)
    foreach::registerDoSEQ()
  }, add = TRUE)
  doParallel::registerDoParallel(cl)

  foreach::foreach(
    i = seq_along(formulas),
    .packages = packages,
    .errorhandling = "stop"
  ) %dopar% {
    fitter(formulas[[i]], data = data)
  }
}
