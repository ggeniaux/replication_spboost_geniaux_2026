#' MARS_SAR_CFE
#' MARS_SAR_CFE estimates additive nonlinear SAR models using a MARS backend
#' (`earth::earth`) for the nonlinear component and the determinant-free
#' Closed-Form Estimator of Smirnov (2020, doi:10.1111/gean.12268) for the
#' spatial autoregressive parameter.
#' @usage MARS_SAR_CFE(formula,data,W,control=boost_control(),control_earth=list(),
#' doMC=FALSE,ncores=3,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10)
#' @param formula a model formula. mboost-style terms are converted to an earth-compatible formula.
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial autocorrelation.
#' @param control \code{boost_control()} object (used for compatibility and optional defaults for \code{control_earth}).
#' @param control_earth list of control parameters passed to \code{earth::earth}
#' (e.g. \code{degree}, \code{nprune}, \code{nk}, \code{penalty}, \code{thresh}, \code{trace}).
#' Optional CV tuning of \code{nprune} is available with
#' \code{use_cv_nprune=TRUE} and controls
#' \code{cv_nfold}, \code{cv_ncore}, \code{cv_mode},
#' \code{cv_nprune_grid} (or \code{cv_nprune_min/max/length}).
#' @param doMC deprecated, ignored. CFE pre-fits are now sequential.
#' @param ncores deprecated, ignored. CFE pre-fits are now sequential.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses ratio/IV approximations, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @return An object of class \code{earth}, augmented with \code{spboost} fields
#' including \code{rho}, \code{rmse}, fitted values and residuals.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 22
#' )
#' fit <- MARS_SAR_CFE(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   control_earth = list(degree = 1, nk = 10, nprune = 5)
#' )
#' fit$rho
#' summary(fit)
#' @export
MARS_SAR_CFE <- function(formula, data, W, control = boost_control(), control_earth = list(),
                         doMC = FALSE, ncores = 3, fallback = c("auto", "none"),
                         rho_bounds = c(-0.99, 0.99), tol = 1e-10) {
  fallback <- match.arg(fallback)
  rho_bounds <- as.numeric(rho_bounds)
  if (length(rho_bounds) != 2L || any(!is.finite(rho_bounds))) rho_bounds <- c(-0.99, 0.99)
  rho_bounds <- sort(rho_bounds)
  if (isTRUE(doMC)) {
    warning("doMC is deprecated and ignored in MARS_SAR_CFE(); CFE pre-fits are sequential.")
  }

  ptm1 <- proc.time()
  Y <- get_all_vars(formula, data)[, 1]
  data$Y <- Y
  n <- length(Y)
  data$WY <- as.numeric(W %*% Y)
  data$W2Y <- as.numeric(W %*% data$WY)

  f0 <- update.formula(formula, "Y~.")
  f1 <- update.formula(f0, "WY~.")
  f2 <- update.formula(f0, "W2Y~.")

  control_earth_use <- control_earth
  earth_nprune_selection <- tryCatch(
    spb_tune_earth_nprune(
      formula = f0,
      data = data,
      control_earth = control_earth_use,
      control_gamboost = control
    ),
    error = function(e) list(status = "error", message = conditionMessage(e))
  )
  if (!is.null(earth_nprune_selection$best_nprune) &&
      is.finite(as.numeric(earth_nprune_selection$best_nprune[[1]]))) {
    control_earth_use$nprune <- as.integer(earth_nprune_selection$best_nprune[[1]])
  }

  m0 <- spb_fit_earth_model(f0, data = data, control_earth = control_earth_use, control_gamboost = control)
  m1 <- spb_fit_earth_model(f1, data = data, control_earth = control_earth_use, control_gamboost = control)
  m2 <- spb_fit_earth_model(f2, data = data, control_earth = control_earth_use, control_gamboost = control)

  e0 <- residuals(m0)
  e1 <- residuals(m1)
  e2 <- residuals(m2)
  a <- as.numeric(t(e1) %*% e2)
  b <- as.numeric(t(e0) %*% e2 + t(e1) %*% e1)
  c0 <- as.numeric(t(e0) %*% e1)
  D <- b^2 - 4 * a * c0

  rho <- NA_real_
  rho_method <- NA_character_
  score_rho <- function(r) {
    rr <- e0 - as.numeric(r) * e1
    sum(rr^2)
  }

  if (D < 0 && abs(D) <= tol) D <- 0
  if (abs(a) > tol && D >= 0) {
    sqrtD <- sqrt(D)
    cand <- c((b - sqrtD) / (2 * a), (b + sqrtD) / (2 * a))
    cand <- cand[is.finite(cand)]
    cand <- cand[cand >= rho_bounds[1] & cand <= rho_bounds[2]]
    if (length(cand) > 0L) {
      if (length(cand) == 1L) {
        rho <- as.numeric(cand[[1]])
        rho_method <- "cfe_exact"
      } else {
        sc <- vapply(cand, score_rho, numeric(1))
        rho <- as.numeric(cand[[which.min(sc)]])
        rho_method <- "cfe_exact_bestroot"
      }
    }
  } else if (fallback == "auto") {
    den_r <- b
    if (abs(den_r) > tol) {
      rho <- as.numeric(c0 / den_r)
      rho_method <- "cfe_ratio_R"
    } else {
      den_iv <- as.numeric(t(e1) %*% e1)
      if (abs(den_iv) > tol) {
        rho <- as.numeric(c0 / den_iv)
        rho_method <- "cfe_iv"
      }
    }
  }

  if ((is.na(rho) || !is.finite(rho)) && fallback == "auto") {
    den_ols <- as.numeric(sum(e1^2))
    if (is.finite(den_ols) && abs(den_ols) > tol) {
      rho <- as.numeric(sum(e0 * e1) / den_ols)
      rho_method <- "cfe_ols_fallback"
    }
  }
  if ((is.na(rho) || !is.finite(rho)) && fallback == "auto") {
    rho <- 0
    rho_method <- "cfe_zero_fallback"
  }

  if (is.na(rho) || !is.finite(rho)) {
    model <- paste0("CFE failed: no admissible SAR rho (D=", signif(D, 6), ", a=", signif(a, 6), ").")
    class(model) <- "error"
    return(model)
  }

  rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
  data$YS <- as.numeric(Y - rho * data$WY)
  f3 <- update.formula(f0, "YS~.")
  model <- tryCatch(
    spb_fit_earth_model(f3, data = data, control_earth = control_earth_use, control_gamboost = control),
    error = function(e) e
  )
  if (inherits(model, "error") && fallback == "auto" && abs(rho) > tol) {
    rho <- 0
    rho_method <- "cfe_zero_refit"
    data$YS <- as.numeric(Y)
    model <- tryCatch(
      spb_fit_earth_model(f3, data = data, control_earth = control_earth_use, control_gamboost = control),
      error = function(e) e
    )
  }
  if (inherits(model, "error")) {
    err <- paste0("MARS_SAR_CFE failed at final earth fit: ", conditionMessage(model))
    class(err) <- "error"
    return(err)
  }
  model$call[["formula"]] <- deparse(formula)

  den_var <- (b - 2 * rho * a)
  if (abs(den_var) > tol) {
    model$var_rho <- (t(e0 - rho * e1) %*% (e0 - rho * e1) / n) / den_var
  } else {
    model$var_rho <- NA_real_
  }

  duree <- (proc.time() - ptm1)[3]
  model$residuals <- residuals(model)
  model$fittedYS <- fitted(model)
  model$fitted <- Y - model$residuals
  model$rmse <- sqrt(mean(model$residuals^2))
  model$rho <- rho
  model$rho_method <- rho_method
  model$D <- D
  model$elapsed <- duree
  model$formula <- formula
  model$Y <- Y
  model$control_earth <- spb_make_earth_control(control_earth = control_earth_use, control_gamboost = control)
  model$earth_nprune_selection <- earth_nprune_selection
  class(model) <- c("spboost", "MARS_SAR_CFE", class(model))
  model
}
