#' BSPA_SARAR_ML
#'
#' BSPA_SARAR_ML allows the estimation of SARAR models using the gradient boosting method
#' for estimating the non linear part
#' while the estimation of the spatial parameter is based on a concentrated likelihood function.
#' This implementation estimates directly the transformed equation
#' \deqn{(I-\lambda W_2)(I-\rho W)Y = g(X) + \varepsilon}
#' using a standard Gaussian \code{gamboost} fit on the transformed response.
#' @usage BSPA_SARAR_ML(formula,data,W,W2,control=boost_control(),verbose=0,multi_start=FALSE)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial autocorrelation of the endogenous variable.
#' @param W2 a row-standardized spatial weight matrix for spatial autocorrelation of errors.
#' @param control boost_control() see mboost help.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @param multi_start logical. If \code{FALSE} and \code{W2 = W}, the estimator
#' constrains \code{rho = lambda}. Otherwise, if \code{FALSE}, it runs a single
#' unconstrained optimization from \code{(0,0)}. If \code{TRUE}, it runs an
#' unconstrained optimization over \code{(rho, lambda)} from multiple starting
#' points and keeps the best optimum.
#' @details The determinants of \eqn{(I-\rho W)} and \eqn{(I-\lambda W_2)} are
#' computed using sparse LU decompositions. To avoid the non-separable custom-loss
#' issue in SARAR boosting, the estimator works on the transformed response
#' \eqn{(I-\lambda W_2)(I-\rho W)Y} and estimates a transformed regression function
#' \eqn{g(X)} with standard Gaussian boosting.
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho, lambda, fitted values and RMSE on the original Y scale.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.2, lambda = 0.2, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SARAR", nonlin = TRUE, myseed = 15
#' )
#' fit <- BSPA_SARAR_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W, W2 = sim$W2,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' c(rho = fit$rho, lambda = fit$lambda)
#' summary(fit)
BSPA_SARAR_ML <- function(formula, data, W, W2, control = boost_control(), verbose = 0, multi_start = FALSE) {
  n <- nrow(data)
  I_n <- Diagonal(n)
  stage_cfg <- spb_make_stage1_boost_control(control)
  boost_ctl_stage1 <- stage_cfg$control_stage1
  boost_ctl_final <- stage_cfg$control_final

  same_W <- identical(W, W2) || isTRUE(all.equal(W, W2, check.attributes = FALSE))

  # Helper to replace the formula response while keeping the original RHS/environment.
  set_response <- function(fml, resp_name) {
    rhs <- tryCatch(deparse1(fml[[3]], collapse = " "), error = function(e) paste(deparse(fml[[3]]), collapse = " "))
    as.formula(paste0(resp_name, " ~ ", rhs), env = environment(fml))
  }

  # Sparse log-determinant adapted from spatialreg.
  LU_ldet <- function(coef, Wm) {
    LU <- lu(I_n - coef * Wm)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    sum(log(dU))
  }

  sarar_negloglik <- function(rho, lambda, SSE) {
    s2 <- SSE / n
    ldet1 <- LU_ldet(rho, W)
    ldet2 <- LU_ldet(lambda, W2)
    ll <- ldet1 + ldet2 - (n / 2) * log(2 * pi) - (n / 2) * log(s2) - SSE / (2 * s2)
    -ll
  }

  Y <- as.numeric(data[, as.character(attr(terms(formula), "variables")[[2]])])
  WY <- as.numeric(W %*% Y)
  W2Y <- as.numeric(W2 %*% Y)
  W2WY <- as.numeric(W2 %*% WY)

  # General ordered SARAR operator:
  # (I-lambda W2)(I-rho W)Y = Y - rho WY - lambda W2Y + rho*lambda W2WY.
  make_Y_star <- function(rho, lambda) {
    as.numeric(Y - rho * WY - lambda * W2Y + (rho * lambda) * W2WY)
  }

  loglik_gamboost_sarar <- function(par, formula, data, boost_ctl) {
    rho <- as.numeric(par[1])
    lambda <- as.numeric(par[2])
    data_star <- data
    data_star$.Y_star <- make_Y_star(rho, lambda)
    f_star <- set_response(formula, ".Y_star")
    fit_star <- gamboost(f_star, data = data_star, control = boost_ctl)
    e_star <- as.numeric(data_star$.Y_star - fitted(fit_star))
    SSE <- sum(e_star^2)
    sarar_negloglik(rho, lambda, SSE)
  }

  if (!isTRUE(multi_start) && isTRUE(same_W)) {
    if (isTRUE(verbose > 0)) cat("Start constrained optimization with rho = lambda (W2 = W transformed SARAR ML)\n")
    loglik_gamboost_sarar_eq <- function(theta, formula, data, boost_ctl) {
      theta <- as.numeric(theta[1])
      loglik_gamboost_sarar(c(theta, theta), formula = formula, data = data, boost_ctl = boost_ctl)
    }
    opt <- optimize(
      f = loglik_gamboost_sarar_eq,
      interval = c(-0.99, 0.99),
      formula = formula,
      data = data,
      boost_ctl = boost_ctl_stage1
    )
    rho <- as.numeric(opt$minimum)
    lambda <- rho
    opt_objective <- as.numeric(opt$objective)
  } else if (!isTRUE(multi_start)) {
    if (isTRUE(verbose > 0)) cat("Start single-start optimization of rho and lambda (general transformed SARAR ML)\n")
    opt <- nlminb(
      start = c(0, 0),
      objective = loglik_gamboost_sarar,
      formula = formula,
      data = data,
      boost_ctl = boost_ctl_stage1,
      lower = c(-0.99, -0.99),
      upper = c(0.99, 0.99)
    )
    rho <- as.numeric(opt$par[1])
    lambda <- as.numeric(opt$par[2])
    opt_objective <- as.numeric(opt$objective)
  } else {
    if (isTRUE(verbose > 0)) cat("Start multi-start optimization of rho and lambda (general transformed SARAR ML)\n")
    starts <- rbind(
      c(0, 0),
      c(0.25, 0.25),
      c(-0.25, -0.25),
      c(0.25, -0.25),
      c(-0.25, 0.25),
      c(0.50, 0.10),
      c(0.10, 0.50),
      c(-0.50, -0.10),
      c(-0.10, -0.50)
    )
    fits <- lapply(seq_len(nrow(starts)), function(i) {
      try(
        nlminb(
          start = starts[i, ],
          objective = loglik_gamboost_sarar,
          formula = formula,
          data = data,
          boost_ctl = boost_ctl_stage1,
          lower = c(-0.99, -0.99),
          upper = c(0.99, 0.99)
        ),
        silent = TRUE
      )
    })
    ok <- vapply(fits, function(x) !inherits(x, "try-error") && is.finite(as.numeric(x$objective)[1]), logical(1))
    if (!any(ok)) stop("BSPA_SARAR_ML multi_start failed: no successful optimization run.")
    objs <- vapply(fits[ok], function(x) as.numeric(x$objective)[1], numeric(1))
    opt <- fits[ok][[which.min(objs)]]
    rho <- as.numeric(opt$par[1])
    lambda <- as.numeric(opt$par[2])
    opt_objective <- as.numeric(opt$objective)
  }

  if (isTRUE(verbose > 0)) {
    if (isTRUE(stage_cfg$two_stage)) cat("Two-stage ML objective with stage1 mstop=", stage_cfg$stage1_mstop, " / final mstop=", stage_cfg$final_mstop, "\n")
    cat("rho=", rho, " and lambda=", lambda, "\n")
  }

  data_star <- data
  data_star$.Y_star <- make_Y_star(rho, lambda)
  f_star <- set_response(formula, ".Y_star")
  gamboost_sarar <- gamboost(f_star, data = data_star, control = boost_ctl_final)

  fitted_star <- as.numeric(fitted(gamboost_sarar))
  Y_pred <- as.numeric(
    spb_solve_nested_spatial_rhs(
      W, rho, W2, lambda, fitted_star,
      direct_max_n = 25000L,
      tol = 1e-6,
      max_order = 50L
    )
  )

  residuals_pred <- as.numeric(Y - Y_pred)
  residuals_filtered <- as.numeric(data_star$.Y_star - fitted_star)

  gamboost_sarar$residuals <- residuals_pred
  gamboost_sarar$residuals_pred <- residuals_pred
  gamboost_sarar$residuals_filtered <- residuals_filtered
  gamboost_sarar$rho <- rho
  gamboost_sarar$lambda <- lambda
  gamboost_sarar$Y <- Y
  gamboost_sarar$fitted <- Y_pred
  gamboost_sarar$fittedYS <- fitted_star
  gamboost_sarar$rmse <- sqrt(mean(residuals_pred^2))
  gamboost_sarar$formula <- formula
  gamboost_sarar$logl <- -as.numeric(opt_objective)
  gamboost_sarar$sarar_mode <- if (isTRUE(multi_start)) {
    if (isTRUE(same_W)) "W_eq_W_transformed_response_multistart" else "W_neq_W2_transformed_response_multistart"
  } else {
    if (isTRUE(same_W)) "W_eq_W_transformed_response_rho_eq_lambda" else "W_neq_W2_transformed_response_single_start"
  }
  gamboost_sarar$multi_start <- isTRUE(multi_start)
  gamboost_sarar$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  gamboost_sarar$ml_stage1_mstop <- stage_cfg$stage1_mstop
  gamboost_sarar$ml_final_mstop <- stage_cfg$final_mstop
  class(gamboost_sarar) <- c("spboost", "BSPA_SARAR_ML", class(gamboost_sarar))
  gamboost_sarar
}
