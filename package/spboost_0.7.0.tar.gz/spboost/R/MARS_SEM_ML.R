#' MARS_SEM_ML
#' MARS_SEM_ML estimates nonlinear SEM models using a MARS backend
#' (`earth::earth`) and concentrated likelihood optimization for the
#' spatial error parameter.
#' @usage MARS_SEM_ML(formula,data,W,control=boost_control(),control_earth=list(),verbose=0)
#' @param formula a model formula. mboost-style terms are converted to an earth-compatible formula.
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial autocorrelation.
#' @param control \code{boost_control()} object (used for compatibility and optional defaults for \code{control_earth}).
#' @param control_earth list of control parameters passed to \code{earth::earth}
#' (e.g. \code{degree}, \code{nprune}, \code{nk}, \code{penalty}, \code{thresh}, \code{trace}).
#' Optional CV tuning of \code{nprune} is available with
#' \code{use_cv_nprune=TRUE} and controls
#' \code{cv_nfold}, \code{cv_ncore}, \code{cv_mode},
#' \code{cv_nprune_grid} (or \code{cv_nprune_min/max/length}).
#' @param verbose verbose mode, default \code{0}.
#' @return An object of class \code{earth}, augmented with \code{spboost} fields
#' including \code{rho}, \code{rmse}, fitted values and residuals.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = TRUE, myseed = 25
#' )
#' fit <- MARS_SEM_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   control_earth = list(degree = 1, nk = 10, nprune = 5)
#' )
#' fit$rho
#' summary(fit)
#' @export
MARS_SEM_ML <- function(formula, data, W, control = boost_control(), control_earth = list(), verbose = 0) {
  n <- nrow(data)
  I <- Diagonal(n)
  stage_cfg <- spb_make_stage1_boost_control(control)
  control_stage1 <- stage_cfg$control_stage1
  control_final <- stage_cfg$control_final
  env <- environment()

  YX <- get_all_vars(formula, data)
  Y <- as.numeric(YX[, 1])
  X <- as.matrix(YX[, -1, drop = FALSE])
  namesX <- colnames(X)
  response_name <- as.character(attr(terms(formula), "variables")[[2]])
  WY <- as.numeric(W %*% Y)
  WX <- as.matrix(W %*% X)

  control_earth_use <- control_earth
  earth_nprune_selection <- tryCatch(
    spb_tune_earth_nprune(
      formula = formula,
      data = data,
      control_earth = control_earth_use,
      control_gamboost = control_final
    ),
    error = function(e) list(status = "error", message = conditionMessage(e))
  )
  if (!is.null(earth_nprune_selection$best_nprune) &&
      is.finite(as.numeric(earth_nprune_selection$best_nprune[[1]]))) {
    control_earth_use$nprune <- as.integer(earth_nprune_selection$best_nprune[[1]])
  }

  LU_ldet <- function(coef, env, which = 1) {
    I <- get("I", envir = env)
    W <- get("W", envir = env)
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    sum(log(dU))
  }

  sem_error_f <- function(SSE, lambda, env) {
    s2 <- SSE / n
    ldet <- LU_ldet(lambda, env, which = 1)
    (ldet - ((n / 2) * log(2 * pi)) - (n / 2) * log(s2) - (1 / (2 * s2)) * SSE)
  }

  make_sem_transformed_data <- function(lambda) {
    y_tf <- as.numeric(Y - lambda * WY)
    x_tf <- as.matrix(X - lambda * WX)
    d_tf <- as.data.frame(x_tf)
    colnames(d_tf) <- namesX
    d_tf[[response_name]] <- y_tf
    d_tf
  }

  loglik_earth_sem <- function(lambda, formula, control_fit, control_earth_use) {
    d_tf <- make_sem_transformed_data(lambda)
    fit <- tryCatch(
      spb_fit_earth_model(
        formula = formula,
        data = d_tf,
        control_earth = control_earth_use,
        control_gamboost = control_fit
      ),
      error = function(e) e
    )
    if (inherits(fit, "error")) return(-1e30)
    SSE <- sum(residuals(fit)^2)
    ll <- sem_error_f(SSE, lambda, env)
    if (!is.finite(ll)) return(-1e30)
    ll
  }

  if (verbose > 0) cat("Start optimization of lambda\n")
  if (verbose > 0 && isTRUE(stage_cfg$two_stage)) cat("Two-stage ML objective with stage1 mstop=", stage_cfg$stage1_mstop, " / final mstop=", stage_cfg$final_mstop, "\n")
  res <- optimize(
    loglik_earth_sem,
    lower = -0.99, upper = 0.99,
    formula = formula,
    control_fit = control_stage1,
    control_earth_use = control_earth_use,
    maximum = TRUE
  )
  lambda_hat <- as.numeric(res$maximum)
  if (!is.finite(lambda_hat)) lambda_hat <- 0
  if (verbose > 0) cat("lambda=", lambda_hat, "\n")

  data_final <- make_sem_transformed_data(lambda_hat)
  mars_sem <- tryCatch(
    spb_fit_earth_model(
      formula = formula,
      data = data_final,
      control_earth = control_earth_use,
      control_gamboost = control_final
    ),
    error = function(e) e
  )
  if (inherits(mars_sem, "error")) {
    err <- paste0("MARS_SEM_ML failed at final earth fit: ", conditionMessage(mars_sem))
    class(err) <- "error"
    return(err)
  }

  Y_pred <- as.numeric(fitted(mars_sem))
  mars_sem$rho <- lambda_hat
  mars_sem$residuals <- Y - Y_pred
  mars_sem$Y <- Y
  mars_sem$fitted <- Y_pred
  mars_sem$fittedYS <- Y_pred
  mars_sem$logl <- as.numeric(res$objective)
  mars_sem$rmse <- sqrt(mean(mars_sem$residuals^2))
  mars_sem$formula <- formula
  mars_sem$control_earth <- spb_make_earth_control(control_earth = control_earth_use, control_gamboost = control_final)
  mars_sem$earth_nprune_selection <- earth_nprune_selection
  mars_sem$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  mars_sem$ml_stage1_mstop <- stage_cfg$stage1_mstop
  mars_sem$ml_final_mstop <- stage_cfg$final_mstop
  class(mars_sem) <- c("spboost", "MARS_SEM_ML", class(mars_sem))

  if (verbose > 0) cat("RMSE =", mars_sem$rmse, "\n")
  mars_sem
}
