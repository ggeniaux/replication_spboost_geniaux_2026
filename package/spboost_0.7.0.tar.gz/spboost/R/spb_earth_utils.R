spb_get_formula_response_name <- function(formula) {
  if (!inherits(formula, "formula")) stop("`formula` must be a formula.")
  response_vars <- tryCatch(all.vars(formula[[2]]), error = function(e) character(0))
  if (length(response_vars) < 1L || !nzchar(response_vars[1])) {
    stop("Unable to extract response name from formula.")
  }
  response_vars[1]
}

spb_formula_rhs_vars <- function(formula, data = NULL) {
  if (!inherits(formula, "formula")) stop("`formula` must be a formula.")
  rhs_expr <- formula[[3]]
  rhs_vars_raw <- tryCatch(all.vars(rhs_expr), error = function(e) character(0))
  has_dot <- any(rhs_vars_raw == ".")
  response <- spb_get_formula_response_name(formula)

  if (isTRUE(has_dot)) {
    if (is.null(data) || !is.data.frame(data)) {
      stop("`data` is required to expand '.' terms in formula for earth backend.")
    }
    rhs_vars <- setdiff(names(data), response)
  } else {
    rhs_vars <- setdiff(rhs_vars_raw, response)
  }

  rhs_vars <- unique(rhs_vars)
  rhs_vars <- rhs_vars[nzchar(rhs_vars) & rhs_vars != "."]
  rhs_vars
}

spb_formula_to_earth <- function(formula, data = NULL, response_override = NULL) {
  response <- if (is.null(response_override)) {
    spb_get_formula_response_name(formula)
  } else {
    as.character(response_override[[1]])
  }
  if (!nzchar(response)) stop("Invalid response name for earth formula.")

  rhs_vars <- spb_formula_rhs_vars(formula, data = data)
  if (!is.null(data) && length(rhs_vars) > 0L) {
    missing_vars <- setdiff(rhs_vars, names(data))
    if (length(missing_vars) > 0L) {
      stop(
        "Variables referenced in formula are missing in `data`: ",
        paste(missing_vars, collapse = ", ")
      )
    }
  }

  if (length(rhs_vars) == 0L) {
    return(stats::as.formula(paste(response, "~ 1")))
  }
  stats::as.formula(paste(response, "~", paste(rhs_vars, collapse = " + ")))
}

spb_make_earth_control <- function(control_earth = NULL, control_gamboost = NULL) {
  if (is.null(control_earth)) control_earth <- list()
  if (!is.list(control_earth)) {
    stop("`control_earth` must be a list.")
  }

  scalar_int <- function(x, default = NA_integer_) {
    x <- suppressWarnings(as.integer(x[[1]]))
    if (length(x) != 1L || is.na(x) || !is.finite(x)) return(default)
    x
  }
  scalar_num <- function(x, default = NA_real_) {
    x <- suppressWarnings(as.numeric(x[[1]]))
    if (length(x) != 1L || is.na(x) || !is.finite(x)) return(default)
    x
  }

  defaults <- list(
    degree = 1L,
    nprune = NULL,
    nk = NA_integer_,
    pmethod = "backward",
    penalty = 2,
    thresh = 0.001,
    minspan = 0L,
    endspan = 0L,
    fast.k = 20L,
    fast.beta = 1,
    newvar.penalty = 0,
    trace = 0,
    keepxy = FALSE
  )

  ctl <- utils::modifyList(defaults, control_earth)

  ctl$degree <- scalar_int(ctl$degree, default = 1L)
  if (ctl$degree < 1L) ctl$degree <- 1L

  ctl$nprune <- scalar_int(ctl$nprune, default = NA_integer_)
  if (is.finite(ctl$nprune) && ctl$nprune < 2L) ctl$nprune <- 2L

  ctl$nk <- scalar_int(ctl$nk, default = NA_integer_)
  if (is.finite(ctl$nk) && ctl$nk < 3L) ctl$nk <- 3L
  if (is.finite(ctl$nprune) && !is.finite(ctl$nk)) {
    ctl$nk <- as.integer(max(21L, ctl$nprune + 5L))
  }
  if (is.finite(ctl$nprune) && is.finite(ctl$nk) && ctl$nk <= ctl$nprune) {
    ctl$nk <- as.integer(ctl$nprune + 1L)
  }

  ctl$penalty <- scalar_num(ctl$penalty, default = 2)
  if (!is.finite(ctl$penalty) || ctl$penalty < 0) ctl$penalty <- 2
  ctl$thresh <- scalar_num(ctl$thresh, default = 0.001)
  if (!is.finite(ctl$thresh) || ctl$thresh <= 0) ctl$thresh <- 0.001
  ctl$minspan <- scalar_int(ctl$minspan, default = 0L)
  if (ctl$minspan < 0L) ctl$minspan <- 0L
  ctl$endspan <- scalar_int(ctl$endspan, default = 0L)
  if (ctl$endspan < 0L) ctl$endspan <- 0L
  ctl$fast.k <- scalar_int(ctl$fast.k, default = 20L)
  if (ctl$fast.k < 1L) ctl$fast.k <- 20L
  ctl$fast.beta <- scalar_num(ctl$fast.beta, default = 1)
  if (!is.finite(ctl$fast.beta) || ctl$fast.beta <= 0) ctl$fast.beta <- 1
  ctl$newvar.penalty <- scalar_num(ctl$newvar.penalty, default = 0)
  if (!is.finite(ctl$newvar.penalty) || ctl$newvar.penalty < 0) ctl$newvar.penalty <- 0
  ctl$trace <- scalar_num(ctl$trace, default = 0)
  if (!is.finite(ctl$trace)) ctl$trace <- 0

  ctl$pmethod <- as.character(ctl$pmethod[[1]])
  if (!nzchar(ctl$pmethod)) ctl$pmethod <- "backward"
  ctl$keepxy <- isTRUE(ctl$keepxy)

  if (!is.finite(ctl$nprune)) ctl$nprune <- NULL
  if (!is.finite(ctl$nk)) ctl$nk <- NULL

  # Keep only arguments supported by earth::earth.default (not the S3 generic).
  earth_fun <- tryCatch(
    get("earth.default", envir = asNamespace("earth")),
    error = function(e) {
      f <- tryCatch(getS3method("earth", "default", optional = TRUE), error = function(e2) NULL)
      if (is.null(f)) earth::earth else f
    }
  )
  allowed <- names(formals(earth_fun))
  ctl <- ctl[intersect(names(ctl), allowed)]
  ctl
}

spb_make_earth_cv_control <- function(control_earth = NULL, control_gamboost = NULL) {
  if (is.null(control_earth)) control_earth <- list()
  if (!is.list(control_earth)) {
    stop("`control_earth` must be a list.")
  }

  scalar_int <- function(x, default = NA_integer_) {
    x <- suppressWarnings(as.integer(x[[1]]))
    if (length(x) != 1L || is.na(x) || !is.finite(x)) return(default)
    x
  }
  scalar_num <- function(x, default = NA_real_) {
    x <- suppressWarnings(as.numeric(x[[1]]))
    if (length(x) != 1L || is.na(x) || !is.finite(x)) return(default)
    x
  }

  defaults <- list(
    use_cv_nprune = FALSE,
    cv_nfold = 5L,
    cv_ncore = NA_integer_,
    cv_seed = NA_integer_,
    cv_mode = "random", # random | spatial_block | spatial_hex | predefined
    cv_coord_vars = c("x", "y"),
    cv_hex_size = NULL,
    cv_hexagon = TRUE,
    cv_crs = NA,
    cv_progress = FALSE,
    cv_nprune_grid = integer(0),
    cv_nprune_min = 5L,
    cv_nprune_max = NA_integer_,
    cv_nprune_length = 12L,
    cv_fold_ids = NULL,
    cv_reuse_best = TRUE
  )
  ctl <- utils::modifyList(defaults, control_earth)

  ctl$use_cv_nprune <- isTRUE(ctl$use_cv_nprune)
  ctl$cv_nfold <- scalar_int(ctl$cv_nfold, default = 5L)
  if (!is.finite(ctl$cv_nfold) || ctl$cv_nfold < 2L) ctl$cv_nfold <- 5L
  ctl$cv_ncore <- scalar_int(ctl$cv_ncore, default = NA_integer_)
  if (is.finite(ctl$cv_ncore) && ctl$cv_ncore < 1L) ctl$cv_ncore <- 1L
  ctl$cv_seed <- scalar_int(ctl$cv_seed, default = NA_integer_)
  ctl$cv_mode <- tolower(as.character(ctl$cv_mode[[1]]))
  if (!nzchar(ctl$cv_mode)) ctl$cv_mode <- "random"
  if (!ctl$cv_mode %in% c("random", "spatial_block", "spatial_hex", "predefined")) ctl$cv_mode <- "random"

  ctl$cv_coord_vars <- as.character(ctl$cv_coord_vars)
  ctl$cv_coord_vars <- ctl$cv_coord_vars[nzchar(ctl$cv_coord_vars)]
  if (length(ctl$cv_coord_vars) < 2L) ctl$cv_coord_vars <- c("x", "y")
  ctl$cv_coord_vars <- ctl$cv_coord_vars[1:2]

  ctl$cv_hex_size <- scalar_num(ctl$cv_hex_size, default = NA_real_)
  if (!is.finite(ctl$cv_hex_size) || ctl$cv_hex_size <= 0) ctl$cv_hex_size <- NULL
  ctl$cv_hexagon <- isTRUE(ctl$cv_hexagon)
  ctl$cv_crs <- scalar_num(ctl$cv_crs, default = NA_real_)
  if (!is.finite(ctl$cv_crs)) ctl$cv_crs <- NA_real_
  ctl$cv_progress <- isTRUE(ctl$cv_progress)

  ctl$cv_nprune_grid <- suppressWarnings(as.integer(ctl$cv_nprune_grid))
  ctl$cv_nprune_grid <- ctl$cv_nprune_grid[is.finite(ctl$cv_nprune_grid) & ctl$cv_nprune_grid >= 2L]
  ctl$cv_nprune_grid <- sort(unique(ctl$cv_nprune_grid))
  ctl$cv_nprune_min <- scalar_int(ctl$cv_nprune_min, default = 5L)
  if (!is.finite(ctl$cv_nprune_min) || ctl$cv_nprune_min < 2L) ctl$cv_nprune_min <- 5L
  ctl$cv_nprune_max <- scalar_int(ctl$cv_nprune_max, default = NA_integer_)
  ctl$cv_nprune_length <- scalar_int(ctl$cv_nprune_length, default = 12L)
  if (!is.finite(ctl$cv_nprune_length) || ctl$cv_nprune_length < 2L) ctl$cv_nprune_length <- 12L
  if (!is.null(ctl$cv_fold_ids)) {
    fid <- suppressWarnings(as.integer(ctl$cv_fold_ids))
    if (!length(fid)) fid <- NULL
    ctl$cv_fold_ids <- fid
  }
  ctl$cv_reuse_best <- isTRUE(ctl$cv_reuse_best)
  ctl
}

spb_make_random_fold_ids <- function(n, nfold = 5L, seed = NULL) {
  if (!is.null(seed) && is.finite(seed)) set.seed(as.integer(seed))
  nfold <- suppressWarnings(as.integer(nfold[[1]]))
  if (!is.finite(nfold) || nfold < 2L) nfold <- 5L
  as.integer(sample(rep(seq_len(nfold), length.out = n)))
}

spb_make_spatial_hex_fold_ids <- function(data, nfold = 5L,
                                          coord_vars = c("x", "y"),
                                          hex_size = NULL,
                                          hexagon = TRUE,
                                          spatial_crs = NA,
                                          spatial_progress = FALSE) {
  if (!requireNamespace("blockCV", quietly = TRUE) || !requireNamespace("sf", quietly = TRUE)) {
    return(NULL)
  }
  if (!all(coord_vars %in% names(data))) return(NULL)

  pts <- tryCatch({
    if (is.finite(as.numeric(spatial_crs[[1]]))) {
      sf::st_as_sf(data, coords = coord_vars, crs = as.integer(spatial_crs[[1]]), remove = FALSE)
    } else {
      sf::st_as_sf(data, coords = coord_vars, crs = 3857, remove = FALSE)
    }
  }, error = function(e) NULL)
  if (is.null(pts)) return(NULL)

  size_use <- suppressWarnings(as.numeric(hex_size[[1]]))
  if (!is.finite(size_use) || size_use <= 0) {
    bb <- sf::st_bbox(pts)
    span <- max(as.numeric(bb$xmax - bb$xmin), as.numeric(bb$ymax - bb$ymin))
    if (!is.finite(span) || span <= 0) return(NULL)
    nf <- suppressWarnings(as.integer(nfold[[1]]))
    if (!is.finite(nf) || nf < 2L) nf <- 5L
    size_use <- span / max(2, sqrt(nf))
  }

  sb <- tryCatch({
    out <- NULL
    suppressWarnings(utils::capture.output({
      out <- blockCV::cv_spatial(
        x = pts,
        k = as.integer(nfold[[1]]),
        size = size_use,
        hexagon = isTRUE(hexagon),
        progress = isTRUE(spatial_progress)
      )
    }))
    out
  }, error = function(e) NULL)
  if (is.null(sb) || is.null(sb$folds_ids)) return(NULL)
  as.integer(sb$folds_ids)
}

spb_make_spatial_block_fold_ids <- function(data, nfold = 5L,
                                            coord_vars = c("x", "y"),
                                            spatial_crs = NA) {
  if (!requireNamespace("blockCV", quietly = TRUE) || !requireNamespace("sf", quietly = TRUE)) {
    return(NULL)
  }
  if (!all(coord_vars %in% names(data))) return(NULL)

  pts <- tryCatch({
    if (is.finite(as.numeric(spatial_crs[[1]]))) {
      sf::st_as_sf(data, coords = coord_vars, crs = as.integer(spatial_crs[[1]]), remove = FALSE)
    } else {
      sf::st_as_sf(data, coords = coord_vars, crs = 3857, remove = FALSE)
    }
  }, error = function(e) NULL)
  if (is.null(pts)) return(NULL)

  sb <- tryCatch({
    out <- NULL
    suppressWarnings(utils::capture.output({
      out <- blockCV::cv_cluster(
        x = pts,
        k = as.integer(nfold[[1]]),
        report = FALSE
      )
    }))
    out
  }, error = function(e) NULL)
  if (is.null(sb) || is.null(sb$folds_ids)) return(NULL)
  as.integer(sb$folds_ids)
}

spb_build_earth_nprune_grid <- function(control_earth = NULL, control_gamboost = NULL, n_obs = NULL) {
  cv_ctl <- spb_make_earth_cv_control(control_earth = control_earth, control_gamboost = control_gamboost)
  ctl <- spb_make_earth_control(control_earth = control_earth, control_gamboost = control_gamboost)

  cand_user <- cv_ctl$cv_nprune_grid
  if (!is.null(cand_user) && length(cand_user) > 0L) {
    return(sort(unique(as.integer(cand_user[cand_user >= 2L]))))
  }

  nmin <- cv_ctl$cv_nprune_min
  nmax <- cv_ctl$cv_nprune_max
  if (!is.finite(nmax)) {
    if (!is.null(ctl$nk) && is.finite(as.numeric(ctl$nk[[1]]))) {
      nmax <- as.integer(max(2L, as.integer(ctl$nk[[1]]) - 1L))
    } else if (is.finite(as.numeric(n_obs[[1]]))) {
      nmax <- as.integer(min(160L, max(20L, floor(as.numeric(n_obs[[1]]) / 5))))
    } else {
      nmax <- 120L
    }
  }
  if (nmax < nmin) nmax <- nmin
  glen <- cv_ctl$cv_nprune_length
  grid <- unique(as.integer(round(seq(from = nmin, to = nmax, length.out = glen))))
  grid <- sort(unique(grid[is.finite(grid) & grid >= 2L]))
  if (!length(grid)) grid <- as.integer(c(5L, 10L, 20L, 30L))
  grid
}

spb_tune_earth_nprune <- function(formula, data, control_earth = NULL, control_gamboost = NULL) {
  nprune_default <- NA_integer_
  if (is.list(control_earth) && !is.null(control_earth$nprune)) {
    nprune_default <- suppressWarnings(as.integer(control_earth$nprune[[1]]))
    if (length(nprune_default) != 1L || !is.finite(nprune_default)) nprune_default <- NA_integer_
  }
  cv_ctl <- spb_make_earth_cv_control(control_earth = control_earth, control_gamboost = control_gamboost)
  if (!isTRUE(cv_ctl$use_cv_nprune)) {
    return(list(
      status = "disabled",
      best_nprune = nprune_default,
      grid = integer(0),
      cv_rmse = numeric(0),
      cv_mode_requested = cv_ctl$cv_mode,
      cv_mode_used = "disabled",
      nfold = NA_integer_,
      ncore = NA_integer_
    ))
  }

  f_earth <- spb_formula_to_earth(formula = formula, data = data)
  response <- spb_get_formula_response_name(f_earth)
  rhs_vars <- setdiff(all.vars(f_earth), response)
  vars_use <- unique(c(response, rhs_vars))
  vars_use <- vars_use[vars_use %in% names(data)]
  d_cv <- data[, vars_use, drop = FALSE]
  keep_cc <- stats::complete.cases(d_cv)
  d_cv <- d_cv[keep_cc, , drop = FALSE]
  if (nrow(d_cv) < max(20L, cv_ctl$cv_nfold * 4L)) {
    return(list(
      status = "insufficient_data",
      best_nprune = nprune_default,
      grid = integer(0),
      cv_rmse = numeric(0),
      cv_mode_requested = cv_ctl$cv_mode,
      cv_mode_used = "insufficient_data",
      nfold = NA_integer_,
      ncore = NA_integer_
    ))
  }

  rhs_keep <- rhs_vars[rhs_vars %in% names(d_cv)]
  if (length(rhs_keep) > 0L) {
    keep_var <- vapply(rhs_keep, function(v) {
      x <- d_cv[[v]]
      if (is.numeric(x) || is.integer(x) || is.logical(x)) {
        xx <- suppressWarnings(as.numeric(x))
        nuniq <- length(unique(xx[is.finite(xx)]))
      } else {
        nuniq <- length(unique(x[!is.na(x)]))
      }
      nuniq >= 2L
    }, logical(1))
    rhs_keep <- rhs_keep[keep_var]
  }
  f_cv <- if (length(rhs_keep) == 0L) {
    stats::as.formula(paste(response, "~ 1"))
  } else {
    stats::as.formula(paste(response, "~", paste(rhs_keep, collapse = " + ")))
  }

  grid <- spb_build_earth_nprune_grid(control_earth = control_earth, control_gamboost = control_gamboost, n_obs = nrow(d_cv))
  if (!length(grid)) {
    return(list(
      status = "invalid_grid",
      best_nprune = nprune_default,
      grid = integer(0),
      cv_rmse = numeric(0),
      cv_mode_requested = cv_ctl$cv_mode,
      cv_mode_used = "invalid_grid",
      nfold = NA_integer_,
      ncore = NA_integer_
    ))
  }

  fold_ids <- NULL
  mode_used <- cv_ctl$cv_mode
  if (!is.null(cv_ctl$cv_fold_ids) && length(cv_ctl$cv_fold_ids) == nrow(data)) {
    fold_ids <- cv_ctl$cv_fold_ids[keep_cc]
    if (!any(is.finite(fold_ids))) fold_ids <- NULL
  }

  if (is.null(fold_ids) && cv_ctl$cv_mode == "spatial_block") {
    if (is.finite(cv_ctl$cv_seed)) set.seed(as.integer(cv_ctl$cv_seed))
    fold_ids <- spb_make_spatial_block_fold_ids(
      data = d_cv,
      nfold = cv_ctl$cv_nfold,
      coord_vars = cv_ctl$cv_coord_vars,
      spatial_crs = cv_ctl$cv_crs
    )
    if (is.null(fold_ids)) mode_used <- "random"
  } else if (is.null(fold_ids) && cv_ctl$cv_mode == "spatial_hex") {
    if (is.finite(cv_ctl$cv_seed)) set.seed(as.integer(cv_ctl$cv_seed))
    fold_ids <- spb_make_spatial_hex_fold_ids(
      data = d_cv,
      nfold = cv_ctl$cv_nfold,
      coord_vars = cv_ctl$cv_coord_vars,
      hex_size = cv_ctl$cv_hex_size,
      hexagon = cv_ctl$cv_hexagon,
      spatial_crs = cv_ctl$cv_crs,
      spatial_progress = cv_ctl$cv_progress
    )
    if (is.null(fold_ids)) mode_used <- "random"
  }
  if (is.null(fold_ids)) {
    fold_ids <- spb_make_random_fold_ids(
      n = nrow(d_cv),
      nfold = cv_ctl$cv_nfold,
      seed = cv_ctl$cv_seed
    )
    mode_used <- "random"
  } else if (cv_ctl$cv_mode == "predefined") {
    mode_used <- "predefined"
  }

  fold_levels <- sort(unique(fold_ids[is.finite(fold_ids)]))
  if (length(fold_levels) < 2L) {
    return(list(
      status = "invalid_folds",
      best_nprune = nprune_default,
      grid = grid,
      cv_rmse = rep(Inf, length(grid)),
      cv_mode_requested = cv_ctl$cv_mode,
      cv_mode_used = "invalid_folds",
      nfold = length(fold_levels),
      ncore = NA_integer_
    ))
  }

  ctl_fit <- spb_make_earth_control(control_earth = control_earth, control_gamboost = control_gamboost)
  ctl_fit$nprune <- NULL
  if (!is.null(ctl_fit$pmethod) && identical(tolower(as.character(ctl_fit$pmethod[[1]])), "cv")) {
    ctl_fit$pmethod <- "backward"
  }

  rmse_for_nprune <- function(npr) {
    fold_rmse <- rep(NA_real_, length(fold_levels))
    for (j in seq_along(fold_levels)) {
      fid <- fold_levels[[j]]
      id_te <- which(fold_ids == fid)
      id_tr <- which(fold_ids != fid)
      if (length(id_te) == 0L || length(id_tr) < 5L) next
      d_tr <- d_cv[id_tr, , drop = FALSE]
      d_te <- d_cv[id_te, , drop = FALSE]

      args <- c(list(formula = f_cv, data = d_tr), ctl_fit, list(nprune = as.integer(npr)))
      fit <- tryCatch(do.call(earth::earth, args), error = function(e) e)
      if (inherits(fit, "error")) next
      pr <- tryCatch(as.numeric(stats::predict(fit, newdata = d_te)), error = function(e) e)
      if (inherits(pr, "error") || length(pr) != nrow(d_te)) next
      yy <- as.numeric(d_te[[response]])
      fold_rmse[[j]] <- sqrt(mean((yy - pr)^2, na.rm = TRUE))
    }
    if (!any(is.finite(fold_rmse))) return(Inf)
    mean(fold_rmse[is.finite(fold_rmse)])
  }

  workers <- cv_ctl$cv_ncore
  if (!is.finite(workers) || workers < 1L) workers <- 1L
  workers <- as.integer(max(1L, min(workers, length(grid))))

  scores <- if (.Platform$OS.type != "windows" && workers > 1L) {
    unlist(parallel::mclapply(grid, rmse_for_nprune, mc.cores = workers, mc.preschedule = FALSE), use.names = FALSE)
  } else {
    unlist(lapply(grid, rmse_for_nprune), use.names = FALSE)
  }
  scores <- as.numeric(scores)
  if (length(scores) != length(grid)) scores <- rep(Inf, length(grid))

  ok <- is.finite(scores)
  best_nprune <- nprune_default
  status <- "failed"
  if (any(ok)) {
    best_nprune <- as.integer(grid[which.min(scores)])
    status <- "ok"
  }

  list(
    status = status,
    best_nprune = best_nprune,
    grid = as.integer(grid),
    cv_rmse = scores,
    cv_mode_requested = cv_ctl$cv_mode,
    cv_mode_used = mode_used,
    nfold = as.integer(length(fold_levels)),
    ncore = workers
  )
}

spb_fit_earth_model <- function(formula, data, control_earth = NULL, control_gamboost = NULL) {
  f_earth <- spb_formula_to_earth(formula = formula, data = data)
  ctl_earth <- spb_make_earth_control(
    control_earth = control_earth,
    control_gamboost = control_gamboost
  )
  args <- c(list(formula = f_earth, data = data), ctl_earth)
  fit <- tryCatch(do.call(earth::earth, args), error = function(e) e)
  if (inherits(fit, "error")) {
    # Retry on a sanitized design:
    # - complete cases on variables used in formula
    # - drop non-varying RHS columns
    response <- spb_get_formula_response_name(f_earth)
    rhs_vars <- setdiff(all.vars(f_earth), response)
    vars_use <- unique(c(response, rhs_vars))
    vars_use <- vars_use[vars_use %in% names(data)]
    d2 <- data[, vars_use, drop = FALSE]
    d2 <- d2[stats::complete.cases(d2), , drop = FALSE]

    rhs_keep <- rhs_vars[rhs_vars %in% names(d2)]
    if (length(rhs_keep) > 0L) {
      keep <- vapply(rhs_keep, function(v) {
        x <- d2[[v]]
        if (is.numeric(x) || is.integer(x) || is.logical(x)) {
          xx <- suppressWarnings(as.numeric(x))
          nuniq <- length(unique(xx[is.finite(xx)]))
        } else {
          nuniq <- length(unique(x[!is.na(x)]))
        }
        nuniq >= 2L
      }, logical(1))
      rhs_keep <- rhs_keep[keep]
    }
    f_retry <- if (length(rhs_keep) == 0L) {
      stats::as.formula(paste(response, "~ 1"))
    } else {
      stats::as.formula(paste(response, "~", paste(rhs_keep, collapse = " + ")))
    }

    args2 <- c(list(formula = f_retry, data = d2), ctl_earth)
    fit2 <- tryCatch(do.call(earth::earth, args2), error = function(e) e)
    if (inherits(fit2, "error")) {
      stop(
        "earth::earth failed on primary and sanitized fits. Primary: ",
        conditionMessage(fit),
        " | Retry: ",
        conditionMessage(fit2)
      )
    }
    fit <- fit2
    f_earth <- f_retry
  }
  fit$formula_earth <- f_earth
  fit
}
