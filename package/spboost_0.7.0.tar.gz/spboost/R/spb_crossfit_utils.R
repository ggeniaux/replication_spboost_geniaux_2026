## Internal utilities for cross-fitted CFE residuals.

## Scattered-block spatial folds: coords are clustered into `ncell` small
## kmeans cells, and cells are assigned round-robin to `nfold` folds. Each
## fold is a union of small spatially compact blocks scattered over the
## domain: held-out predictions are interpolations (unlike large contiguous
## blocks, which force extrapolation of geographic smooths), while the
## within-block leakage of plain random folds is avoided.
spb_scatter_folds <- function(coords, nfold = 5L, ncell = NULL, seed = 1L) {
  n <- nrow(coords)
  nfold <- max(2L, as.integer(nfold[[1]]))
  if (is.null(ncell)) ncell <- min(max(10L * nfold, 20L), max(nfold, n %/% 20L))
  ncell <- max(nfold, min(as.integer(ncell[[1]]), n))
  set.seed(seed)
  cl <- stats::kmeans(coords, centers = ncell, nstart = 3L,
                      iter.max = 50L)$cluster
  ((cl - 1L) %% nfold) + 1L
}

## Rewrite a formula for a cross-fitting training fold: every smooth with
## bs = "spx" carries in `xt` a spatial weight matrix aligned with the full
## sample; on a fold the constructor must see W[tr, tr] instead (and any
## precomputed `eigs`, valid only for the full W, must be dropped so the
## fold eigenvectors are recomputed). The patched `xt` value is bound to a
## generated symbol in a child environment of the formula environment, so
## mgcv's term labels stay short and every other symbol keeps resolving.
spb_cf_patch_spx <- function(fml, tr) {
  env0 <- environment(fml)
  envk <- new.env(parent = env0)
  cnt <- 0L
  patch <- function(e) {
    if (!is.call(e)) return(e)
    fn <- e[[1]]
    if (is.name(fn) && as.character(fn) %in% c("s", "te", "ti", "t2")) {
      xt_expr <- e[["xt"]]
      bs <- tryCatch(eval(e[["bs"]], envir = env0), error = function(err) NULL)
      if (!is.null(xt_expr) && identical(bs, "spx")) {
        xt <- eval(xt_expr, envir = env0)
        if (!is.null(xt$W)) xt$W <- xt$W[tr, tr]
        xt$eigs <- NULL
        cnt <<- cnt + 1L
        nm <- paste0(".spb_cf_xt_", cnt)
        assign(nm, xt, envir = envk)
        e[["xt"]] <- as.name(nm)
      }
      return(e)
    }
    for (i in seq_along(e)) {
      if (i > 1L && !is.null(e[[i]])) e[[i]] <- patch(e[[i]])
    }
    e
  }
  rhs <- patch(fml[[3]])
  if (cnt == 0L) return(fml)
  out <- fml
  out[[3]] <- rhs
  environment(out) <- envk
  out
}
