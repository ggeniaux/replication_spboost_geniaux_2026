spb_extract_ml_stage_params <- function(control,
                                        enabled_default = TRUE,
                                        frac_default = 0.25,
                                        min_default = 50L,
                                        max_default = 300L) {
  if (is.null(control)) control <- mboost::boost_control()

  ctl <- control
  extra_names <- c(
    "spboost_ml_two_stage",
    "spboost_ml_stage1_frac",
    "spboost_ml_stage1_min",
    "spboost_ml_stage1_max"
  )

  enabled <- enabled_default
  frac <- frac_default
  min_mstop <- min_default
  max_mstop <- max_default

  if ("spboost_ml_two_stage" %in% names(ctl)) {
    tmp <- suppressWarnings(as.logical(ctl$spboost_ml_two_stage[[1]]))
    if (is.finite(tmp) || isTRUE(tmp) || identical(tmp, FALSE)) enabled <- isTRUE(tmp)
  }
  if ("spboost_ml_stage1_frac" %in% names(ctl)) {
    tmp <- suppressWarnings(as.numeric(ctl$spboost_ml_stage1_frac[[1]]))
    if (is.finite(tmp) && tmp > 0 && tmp <= 1) frac <- tmp
  }
  if ("spboost_ml_stage1_min" %in% names(ctl)) {
    tmp <- suppressWarnings(as.integer(ctl$spboost_ml_stage1_min[[1]]))
    if (is.finite(tmp) && tmp >= 1L) min_mstop <- tmp
  }
  if ("spboost_ml_stage1_max" %in% names(ctl)) {
    tmp <- suppressWarnings(as.integer(ctl$spboost_ml_stage1_max[[1]]))
    if (is.finite(tmp) && tmp >= 1L) max_mstop <- tmp
  }

  ctl[extra_names] <- NULL
  attr(ctl, "class") <- class(control)

  list(
    control = ctl,
    enabled = isTRUE(enabled),
    frac = frac,
    min_mstop = as.integer(min_mstop),
    max_mstop = as.integer(max_mstop)
  )
}

spb_make_stage1_boost_control <- function(control,
                                          enabled_default = TRUE,
                                          frac_default = 0.25,
                                          min_default = 50L,
                                          max_default = 300L) {
  cfg <- spb_extract_ml_stage_params(
    control = control,
    enabled_default = enabled_default,
    frac_default = frac_default,
    min_default = min_default,
    max_default = max_default
  )

  ctl_final <- cfg$control
  ctl_stage1 <- ctl_final
  final_mstop <- suppressWarnings(as.integer(ctl_final$mstop[[1]]))

  if (!cfg$enabled || !is.finite(final_mstop) || final_mstop <= 1L) {
    return(list(
      control_final = ctl_final,
      control_stage1 = ctl_final,
      two_stage = FALSE,
      final_mstop = final_mstop,
      stage1_mstop = final_mstop
    ))
  }

  stage1_mstop <- ceiling(final_mstop * cfg$frac)
  stage1_mstop <- max(as.integer(cfg$min_mstop), stage1_mstop)
  stage1_mstop <- min(as.integer(cfg$max_mstop), stage1_mstop)
  stage1_mstop <- min(stage1_mstop, final_mstop)

  if (!is.finite(stage1_mstop) || stage1_mstop >= final_mstop) {
    return(list(
      control_final = ctl_final,
      control_stage1 = ctl_final,
      two_stage = FALSE,
      final_mstop = final_mstop,
      stage1_mstop = final_mstop
    ))
  }

  ctl_stage1$mstop <- as.integer(stage1_mstop)

  list(
    control_final = ctl_final,
    control_stage1 = ctl_stage1,
    two_stage = TRUE,
    final_mstop = as.integer(final_mstop),
    stage1_mstop = as.integer(stage1_mstop)
  )
}
