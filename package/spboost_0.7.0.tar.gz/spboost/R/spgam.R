#' spbgam
#' spbgam allows the estimation of gaussian additive non linear SAR/SEM models
#' using gradient boosting or generalized additive models for estimating the
#' non linear part of the model while
#' the estimation of the spatial parameter is based on a concentrated likelihood
#' function (ML) or the determinant-free Closed-Form Estimator of Smirnov
#' (2020, doi:10.1111/gean.12268). This function
#' makes it possible to estimate an additive non linear SAR or SEM model while
#' automatically selecting the explanatory variables. If the functional forms are
#' already known, GAM (\code{mgcv}) can be used directly for the nonlinear component.
#' When variable selection or data-driven smoothness is needed, gradient boosting
#' (\code{mboost}) is preferred.
#' @usage spbgam(formula,data,W,W2=NULL,DGP='SAR',method='gamboost_ML',control=list(),
#'              debug=NULL,debug_fit_each_iter=NULL,debug_print=NULL)
#' @param formula a gamboost formula (see mboost help) or a gam formula (see mgcv help)
#' @param data a dataframe.
#' @param W a row-standardized spatial sparse weight matrix for Spatial
#' Autocorrelation.
#' @param W2 a row-standardized spatial sparse weight matrix for Spatial
#' Autocorrelation.
#' @param DGP the name of the spatial autoregressive model that can be SAR or SEM,
#' default='SAR'.
#' @param method a method for estimation. The available choices are 'BSPA_SAR_ML',
#' 'BSPA_SAR_CFE', 'BLA_SAR_ML', 'MARS_SAR_ML', 'MARS_SAR_CFE', 'GAM_SAR_ML',
#' 'GAM_SAR_CFE', 'XGBOOST_SAR_ML', 'LM_SAR_ML',
#' 'BSPA_SEM_ML', 'BSPA_SEM_CFE', 'BSPA_SEM_CFE_iter', 'MARS_SEM_ML',
#' 'MARS_SEM_CFE', 'BSPA_SARAR_ML', 'BSPA_SARAR_CFE', 'BLA_SARAR_ML'.
#' The suffix ML indicates the use of maximum likelihood for estimating
#' the spatial autoregressive terms, while the suffix CFE refers to the Closed
#' Form Estimator approach of Smirnov (2020, doi:10.1111/gean.12268). The prefix
#' 'BSPA' refers to gradient boosting (mboost package) with splines for the
#' nonlinear part, 'GAM' to the gam function from mgcv, 'MARS' to multivariate
#' adaptive regression splines (earth package), and 'XGBOOST' to xgboost.
#' @param control a list of control parameters, see details.
#' @param debug Logical debug flag for selected iterative estimators.
#' @param debug_fit_each_iter Logical; when supported, compute auxiliary
#' fit diagnostics at each iteration.
#' @param debug_print Logical; when supported, print iterative debug details.
#' @details The syntax of the spline functions in formula should be coherent with the
#' chosen method (see mboost and mgcv packages for the syntax). When ML is used, the
#' determinant of (I - rho W) is computed using code from Matrix packages with a sparse
#' matrix decomposition approach (option 'LU' of function lagsarlm from spatialreg).
#' If 'gamboost' is used, the user can adapt the hyper parameters using
#' \code{control=list(control_gamboost=boost_control())}, see mboost package.
#' If 'MARS' is used, set \code{control_earth=list(...)} with \code{earth::earth}
#' controls (e.g. \code{degree}, \code{nprune}, \code{nk}, \code{penalty},
#' \code{thresh}, \code{trace}).
#' Optional internal CV tuning of \code{nprune} is available via
#' \code{control_earth$use_cv_nprune=TRUE} with \code{cv_nfold}, \code{cv_ncore},
#' \code{cv_mode} (\code{"random"}, \code{"spatial_block"}, \code{"spatial_hex"}
#' or \code{"predefined"}), and \code{cv_nprune_grid}.
#' For \code{method = "BSPA_SAR_CFE"} or \code{"BSPA_SAR_ML"}, \code{control} can
#' include \code{mstop_criterion = "CV"} to select \code{mstop} by cross-validation.
#' For SEM methods, \code{mstop_criterion = "CV"} tunes \code{mstop} using the
#' SEM-filtered loss. Use \code{cv_mode} for fold construction strategy and
#' \code{cv_plot = TRUE} to draw spatial CV folds.
#' @return An object of class spboost, which, depending on the method and underlying
#' package used, inherits from the mboost, xgboost or mgcv class, augmented with
#' spatial parameter estimates, residuals, fitted values and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 2
#' )
#' fit <- spbgam(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   DGP = "SAR", method = "BSPA_SAR_CFE",
#'   control = list(control_gamboost = mboost::boost_control(mstop = 5, nu = 0.2))
#' )
#' fit$rho
#' fit$rmse
#' summary(fit)
#' @export
spbgam<-function(formula,data,W,W2=NULL,DGP='SAR',method='gamboost_ML',control=list(),
                 debug=NULL,debug_fit_each_iter=NULL,debug_print=NULL){
  spbgam_call <- match.call()
  model <- NULL
  con=list(control_gamboost=boost_control(),control_earth=list(degree=1L,nprune=NULL,nk=NULL,pmethod="backward",penalty=2,thresh=1e-3,trace=0),doMC_cfe=FALSE,ncores_cfe=3,gam_engine_cfe='auto',bam_threshold_cfe=12000L,bam_discrete_cfe=TRUE,bam_nthreads_cfe=NULL,mstop0=NULL,mstop_init=500,myparams_xgboost=list(booster="gblinear",eta=0.3,gamma = 1, max_depth = 4,min_child_weight = 5,subsample = 0.9,colsample_bytree = 0.9,nthread=7,nfold=5,folds = NULL,early_stopping_rounds=3,verbose = 0),rho0=c(0,0.2,0.6,0.8),mstop_criterion="none",nfold=5L,ncore=NULL,cv_seed_spatial=1001L,cv_mode="random",cv_mode_spatial=NULL,cv_coord_vars_spatial=c("x","y"),cv_hex_size_spatial=NULL,cv_hexagon_spatial=TRUE,cv_crs_spatial=NA,cv_progress_spatial=FALSE,cv_plot=FALSE,cv_eval_y_spatial=TRUE,cv_eval_y_store_oof=FALSE,sem_cfe_aux_cv=FALSE,sem_cfe_aux_nfold=5L,sem_cfe_aux_ncore=1L,sem_cfe_aux_seed=NA_integer_,iter_max=1L,tol_lambda=1e-4,multi_start=FALSE,spectral_overlap=FALSE,spectral_k=50L,spectral_vars_pattern="^X[0-9]+$",verbose=0)
  nmsC <- names(con)
  con[(namc <- names(control))] <- control
  if (length(noNms <- namc[!namc %in% nmsC]))  warning("unknown names in control: ", paste(noNms, collapse = ", "))
  if ("cv_mode_spatial" %in% namc && !"cv_mode" %in% namc && !is.null(con$cv_mode_spatial)) {
    con$cv_mode <- con$cv_mode_spatial
  }
  con$cv_mode <- tolower(as.character(con$cv_mode[[1]]))
  if (!nzchar(con$cv_mode) || !con$cv_mode %in% c("random", "spatial_block", "spatial_hex")) {
    con$cv_mode <- "random"
  }
  for(i in 1:length(con))
  {
    assign(names(con)[i],con[[i]],envir =parent.frame())
    #assign(names(con)[i],con[[i]],envir=envavirer)
  }

  # Optional top-level debug flags (mainly for BSPA_SARAR_CFE) can be passed
  # either directly to spbgam() or via control=list(...).
  if (!is.null(debug)) con$debug <- isTRUE(debug)
  if (!is.null(debug_fit_each_iter)) con$debug_fit_each_iter <- isTRUE(debug_fit_each_iter)
  if (!is.null(debug_print)) con$debug_print <- isTRUE(debug_print)

  # Normalize/validate boost control once to avoid type issues (e.g. mstop as character).
  con$control_gamboost <- spb_make_boost_control(
    con$control_gamboost,
    data = data,
    method = method,
    DGP = DGP
  )

  # Harmonize Earth-CV controls with global CV controls so MARS estimators
  # can run internal nprune tuning consistently inside spbgam().
  if (is.null(con$control_earth)) con$control_earth <- list()
  if (!is.list(con$control_earth)) {
    stop("`control_earth` must be a list when provided in `control`.")
  }
  if (is.null(con$control_earth$use_cv_nprune)) con$control_earth$use_cv_nprune <- FALSE
  if (is.null(con$control_earth$cv_nfold)) con$control_earth$cv_nfold <- con$nfold
  if (is.null(con$control_earth$cv_ncore)) con$control_earth$cv_ncore <- con$ncore
  if (is.null(con$control_earth$cv_seed) || !is.finite(suppressWarnings(as.numeric(con$control_earth$cv_seed[[1]])))) {
    con$control_earth$cv_seed <- con$cv_seed_spatial
  }
  if (is.null(con$control_earth$cv_mode) || !nzchar(as.character(con$control_earth$cv_mode[[1]]))) {
    con$control_earth$cv_mode <- con$cv_mode
  }
  if (is.null(con$control_earth$cv_coord_vars)) con$control_earth$cv_coord_vars <- con$cv_coord_vars_spatial
  if (is.null(con$control_earth$cv_hex_size)) con$control_earth$cv_hex_size <- con$cv_hex_size_spatial
  if (is.null(con$control_earth$cv_hexagon)) con$control_earth$cv_hexagon <- con$cv_hexagon_spatial
  if (is.null(con$control_earth$cv_crs)) con$control_earth$cv_crs <- con$cv_crs_spatial
  if (is.null(con$control_earth$cv_progress)) con$control_earth$cv_progress <- con$cv_progress_spatial

  # Input diagnostics for spatial weights.
  if (identical(DGP, "SARAR") && is.null(W2)) {
    warning("DGP='SARAR' and W2 is NULL: using W2 = W by default.")
    W2 <- W
  }
  spb_warn_w_quality(W, name = "W")
  if (!is.null(W2)) spb_warn_w_quality(W2, name = "W2")

  if(!(method %in% c('BSPA_SAR_ML','BSPA_SAR_CFE','BLA_SAR_CFE','MARS_SAR_ML','MARS_SAR_CFE','GAM_SAR_ML','GAM_SAR_CFE','GAM_SAR_FIVA','GAM_SAR_2SLSA','XGBOOST_SAR_ML','XGBOOST_SAR_CFE','LM_SAR_ML','BLA_SAR_ML','BSPA_SEM_ML','BSPA_SEM_CFE','BSPA_SEM_CFE_iter','BSPA_SEM_CFE_BRUT','MARS_SEM_ML','MARS_SEM_CFE','GAM_SEM_CFE','BLA_SEM_ML','BSPA_SARAR_ML','BSPA_SARAR_CFE','BLA_SARAR_ML'))) stop(paste0(method, ' is an Unknow method'))
  criterion_requested <- tolower(as.character(con$mstop_criterion[[1]]))
  criterion_is_cv <- criterion_requested %in% c("cv", "spatial", "sem_spatial")
  if (criterion_is_cv) {
    con$mstop_criterion <- "CV"
  }
  sem_cv_methods <- c("BSPA_SEM_ML", "BSPA_SEM_CFE", "BSPA_SEM_CFE_iter", "BSPA_SEM_CFE_BRUT")
  if (criterion_is_cv &&
      !(DGP == "SAR" && method %in% c("BSPA_SAR_ML", "BSPA_SAR_CFE")) &&
      !(DGP == "SEM" && method %in% sem_cv_methods)) {
    warning("mstop_criterion='CV' is available for BSPA_SAR_* and BSPA_SEM_* estimators only.")
  }
  if(DGP=='SAR'){
    use_spatial_mstop <- method %in% c("BSPA_SAR_ML", "BSPA_SAR_CFE") &&
      criterion_is_cv

    if (use_spatial_mstop) {
      y_raw <- get_all_vars(formula, data)[, 1]
      mstop_max <- as.integer(con$control_gamboost$mstop[[1]])
      if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L

      mstop_init_use <- as.integer(con$mstop_init[[1]])
      if (!is.finite(mstop_init_use) || mstop_init_use < 1L) mstop_init_use <- min(150L, mstop_max)
      mstop_init_use <- min(mstop_init_use, mstop_max)

      control_init <- spb_make_boost_control(con$control_gamboost, mstop_override = mstop_init_use)
      model_init <- spb_fit_bspa_sar(
        method = method,
        formula = formula,
        data = data,
        W = W,
        control_gamboost = control_init,
        con = con
      )
      if (inherits(model_init, "error")) {
        return(model_init)
      }
      rho_init <- suppressWarnings(as.numeric(model_init$rho[[1]]))
      if (!is.finite(rho_init)) {
        warning("Spatial mstop tuning skipped: non-finite rho from initialization fit.")
        use_spatial_mstop <- FALSE
      } else {
        y_rho <- as.numeric(y_raw - rho_init * as.numeric(W %*% y_raw))
        cv_mstop <- spb_cv_spatial_mstop(
          formula = formula,
          data = data,
          y_filtered = y_rho,
          control_gamboost = con$control_gamboost,
          nfold = con$nfold,
          ncore = con$ncore,
          seed = con$cv_seed_spatial,
          cv_mode = con$cv_mode,
          coord_vars = con$cv_coord_vars_spatial,
          hex_size = con$cv_hex_size_spatial,
          hexagon = con$cv_hexagon_spatial,
          spatial_crs = con$cv_crs_spatial,
          spatial_progress = con$cv_progress_spatial,
          cv_plot = con$cv_plot
        )

        control_final <- spb_make_boost_control(
          con$control_gamboost,
          mstop_override = cv_mstop$best_mstop
        )
        model <- spb_fit_bspa_sar(
          method = method,
          formula = formula,
          data = data,
          W = W,
          control_gamboost = control_final,
          con = con
        )
        if (!inherits(model, "error")) {
          cv_eval_y <- list(
            cv_rmse_y_bpn = NA_real_,
            cv_n_oof_pred = 0L,
            cv_oof_n = nrow(data),
            cv_fold_rmse_y_bpn = rep(NA_real_, cv_mstop$nfold),
            cv_eval_error = NA_character_,
            cv_oof_pred = NULL
          )
          if (isTRUE(con$cv_eval_y_spatial)) {
            cv_eval_y <- spb_cv_oof_rmse_y_bpn(
              formula = formula,
              data = data,
              W = W,
              cv_folds = cv_mstop$cv_folds,
              best_mstop = cv_mstop$best_mstop,
              method = method,
              con = con
            )
          }

          model$mstop_selection <- list(
            criterion = "CV",
            mstop_init = mstop_init_use,
            mstop_max = mstop_max,
            best_mstop = cv_mstop$best_mstop,
            nfold = cv_mstop$nfold,
            ncore = cv_mstop$ncore,
            rho_init = rho_init,
            cv_mode_requested = cv_mstop$cv_mode_requested,
            cv_mode_used = cv_mstop$cv_mode_used,
            cv_hex_size = cv_mstop$cv_hex_size,
            cv_plot_data = cv_mstop$cv_plot_data,
            cv_rmse_filtered_at_best = cv_mstop$cv_rmse_filtered_at_best,
            cv_mse_filtered_at_best = cv_mstop$cv_mse_filtered_at_best,
            cv_rmse_y_bpn = cv_eval_y$cv_rmse_y_bpn,
            cv_n_oof_pred = cv_eval_y$cv_n_oof_pred,
            cv_oof_n = cv_eval_y$cv_oof_n,
            cv_fold_rmse_y_bpn = cv_eval_y$cv_fold_rmse_y_bpn,
            cv_eval_error = cv_eval_y$cv_eval_error
          )
          if (isTRUE(con$cv_eval_y_store_oof)) {
            model$mstop_selection$cv_oof_pred <- cv_eval_y$cv_oof_pred
          }
        }
      }
    }

    if(is.null(model) && method=='BSPA_SAR_ML') model=BSPA_SAR_ML(formula=formula,data=data,W=W,control=con$control_gamboost)
    else if(is.null(model) && method=='BSPA_SAR_CFE') model=BSPA_SAR_CFE(formula=formula,data=data,W=W,control=con$control_gamboost,doMC=con$doMC_cfe,ncores=con$ncores_cfe)
    else if(is.null(model) && method=='BLA_SAR_CFE') model=BSPA_SAR_CFE(formula=formula,data=data,W=W,control=con$control_gamboost,doMC=con$doMC_cfe,ncores=con$ncores_cfe)
    else if(is.null(model) && method=='MARS_SAR_ML') model=MARS_SAR_ML(formula=formula,data=data,W=W,control=con$control_gamboost,control_earth=con$control_earth,verbose=con$verbose)
    else if(is.null(model) && method=='MARS_SAR_CFE') model=MARS_SAR_CFE(formula=formula,data=data,W=W,control=con$control_gamboost,control_earth=con$control_earth,doMC=con$doMC_cfe,ncores=con$ncores_cfe)
    else if(method=='GAM_SAR_ML') model=GAM_SAR_ML(formula=formula,data=data,W=W)
    else if(method=='GAM_SAR_CFE') model=GAM_SAR_CFE(formula=formula,data=data,W=W,doMC=con$doMC_cfe,ncores=con$ncores_cfe,engine=con$gam_engine_cfe,bam_threshold=con$bam_threshold_cfe,bam_discrete=con$bam_discrete_cfe,bam_nthreads=con$bam_nthreads_cfe)
    else if(method=='GAM_SAR_FIVA') model=GAM_SAR_FIVA(formula=formula,data=data,W=W,nlz=TRUE,ncores=con$ncores_cfe,engine=con$gam_engine_cfe,bam_threshold=con$bam_threshold_cfe,bam_discrete=con$bam_discrete_cfe,bam_nthreads=con$bam_nthreads_cfe)
    else if(method=='GAM_SAR_2SLSA') model=GAM_SAR_FIVA(formula=formula,data=data,W=W,nlz=FALSE,ncores=con$ncores_cfe,engine=con$gam_engine_cfe,bam_threshold=con$bam_threshold_cfe,bam_discrete=con$bam_discrete_cfe,bam_nthreads=con$bam_nthreads_cfe)
    else if(method=='XGBOOST_SAR_ML') model=XGBOOST_SAR_ML(formula=formula,data=data,W=W,mstop0=con$mstop0,mstop_init=con$mstop_init,myparams=con$myparams_xgboost)
    else if(method=='XGBOOST_SAR_CFE') model=XGBOOST_SAR_CFE(formula=formula,data=data,W=W,mstop0=con$mstop0,mstop_init=con$mstop_init,myparams=con$myparams_xgboost)
    else if(method=='LM_SAR_ML') model=LM_SAR_ML(formula=formula,data=data,W=W)
    else if(method=='BLA_SAR_ML') model=BLA_SAR_ML(formula=formula,data=data,W=W)

  } else if(DGP=='SEM'){
    use_sem_mstop <- method %in% sem_cv_methods &&
      criterion_is_cv

    if (use_sem_mstop && method %in% c("BSPA_SEM_CFE", "BSPA_SEM_CFE_iter") && !isTRUE(con$sem_cfe_aux_cv)) {
      warning(sprintf("%s with SEM CV: enabling internal CV on CFE auxiliary regressions (Y and WY).", method))
      con$sem_cfe_aux_cv <- TRUE
      con$sem_cfe_aux_nfold <- con$nfold
      aux_ncore <- if (is.null(con$ncore)) 1L else suppressWarnings(as.integer(con$ncore[[1]]))
      if (!is.finite(aux_ncore) || aux_ncore < 1L) aux_ncore <- 1L
      con$sem_cfe_aux_ncore <- aux_ncore
      con$sem_cfe_aux_seed <- con$cv_seed_spatial
    }

    if (use_sem_mstop) {
      mstop_max <- as.integer(con$control_gamboost$mstop[[1]])
      if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L

      mstop_init_use <- as.integer(con$mstop_init[[1]])
      if (!is.finite(mstop_init_use) || mstop_init_use < 1L) mstop_init_use <- min(150L, mstop_max)
      mstop_init_use <- min(mstop_init_use, mstop_max)

      # For BSPA_SEM_CFE* with auxiliary-CV enabled, the lambda-init stage should
      # optimize auxiliary regressions on the full CV search range, not be capped
      # by mstop_init.
      control_init <- if (method %in% c("BSPA_SEM_CFE", "BSPA_SEM_CFE_iter") && isTRUE(con$sem_cfe_aux_cv)) {
        spb_make_boost_control(con$control_gamboost, mstop_override = mstop_max)
      } else {
        spb_make_boost_control(con$control_gamboost, mstop_override = mstop_init_use)
      }
      model_init <- spb_fit_bspa_sem(
        method = method,
        formula = formula,
        data = data,
        W = W,
        control_gamboost = control_init,
        con = con
      )
      if (inherits(model_init, "error")) {
        return(model_init)
      }

      lambda_init <- suppressWarnings(as.numeric(model_init$rho[[1]]))
      if (!is.finite(lambda_init)) {
        warning("SEM mstop tuning skipped: non-finite lambda from initialization fit.")
        use_sem_mstop <- FALSE
      } else {
        cv_mstop <- spb_cv_sem_mstop(
          formula = formula,
          data = data,
          W = W,
          lambda_init = lambda_init,
          control_gamboost = con$control_gamboost,
          nfold = con$nfold,
          ncore = con$ncore,
          seed = con$cv_seed_spatial,
          cv_mode = con$cv_mode,
          coord_vars = con$cv_coord_vars_spatial,
          hex_size = con$cv_hex_size_spatial,
          hexagon = con$cv_hexagon_spatial,
          spatial_crs = con$cv_crs_spatial,
          spatial_progress = con$cv_progress_spatial,
          cv_plot = con$cv_plot
        )

        control_final <- spb_make_boost_control(
          con$control_gamboost,
          mstop_override = cv_mstop$best_mstop
        )
        model <- spb_fit_bspa_sem(
          method = method,
          formula = formula,
          data = data,
          W = W,
          control_gamboost = control_final,
          con = con
        )
        if (!inherits(model, "error")) {
          model$mstop_selection <- list(
            criterion = "CV",
            mstop_init = mstop_init_use,
            mstop_max = mstop_max,
            best_mstop = cv_mstop$best_mstop,
            nfold = cv_mstop$nfold,
            ncore = cv_mstop$ncore,
            rho_init = lambda_init,
            lambda_init = lambda_init,
            cv_mode_requested = cv_mstop$cv_mode_requested,
            cv_mode_used = cv_mstop$cv_mode_used,
            cv_hex_size = cv_mstop$cv_hex_size,
            cv_plot_data = cv_mstop$cv_plot_data,
            cv_rmse_filtered_at_best = cv_mstop$cv_rmse_filtered_at_best,
            cv_mse_filtered_at_best = cv_mstop$cv_mse_filtered_at_best,
            cv_rmse_y_bpn = NA_real_,
            cv_n_oof_pred = 0L,
            cv_oof_n = nrow(data),
            cv_fold_rmse_y_bpn = rep(NA_real_, cv_mstop$nfold),
            cv_eval_error = NA_character_
          )
        }
      }
    }

    if(is.null(model) && method=='BSPA_SEM_ML') model=BSPA_SEM_ML(formula=formula,data=data,W=W,control=con$control_gamboost)
    else if(is.null(model) && method=='BSPA_SEM_CFE') model=BSPA_SEM_CFE(formula=formula,data=data,W=W,control=con$control_gamboost,doMC=con$doMC_cfe,cfe_aux_cv=isTRUE(con$sem_cfe_aux_cv),cfe_cv_nfold=con$sem_cfe_aux_nfold,cfe_cv_ncore=con$sem_cfe_aux_ncore,cfe_cv_seed=con$sem_cfe_aux_seed)
    else if(is.null(model) && method=='BSPA_SEM_CFE_iter') model=BSPA_SEM_CFE_iter(formula=formula,data=data,W=W,control=con$control_gamboost,iter_max=con$iter_max,tol_lambda=con$tol_lambda,doMC=con$doMC_cfe,cfe_aux_cv=isTRUE(con$sem_cfe_aux_cv),cfe_cv_nfold=con$sem_cfe_aux_nfold,cfe_cv_ncore=con$sem_cfe_aux_ncore,cfe_cv_seed=con$sem_cfe_aux_seed)
    else if(is.null(model) && method=='BSPA_SEM_CFE_BRUT') model=BSPA_SEM_CFE_BRUT(formula=formula,data=data,W=W,control=con$control_gamboost,verbose=con$verbose)
    else if(is.null(model) && method=='MARS_SEM_ML') model=MARS_SEM_ML(formula=formula,data=data,W=W,control=con$control_gamboost,control_earth=con$control_earth,verbose=con$verbose)
    else if(is.null(model) && method=='MARS_SEM_CFE') model=MARS_SEM_CFE(formula=formula,data=data,W=W,control=con$control_gamboost,control_earth=con$control_earth,doMC=con$doMC_cfe,ncores=con$ncores_cfe)
    else if(method=='GAM_SEM_CFE') model=GAM_SEM_CFE(formula=formula,data=data,W=W,doMC=con$doMC_cfe,ncores=con$ncores_cfe,engine=con$gam_engine_cfe,bam_threshold=con$bam_threshold_cfe,bam_discrete=con$bam_discrete_cfe,bam_nthreads=con$bam_nthreads_cfe)
    else if(method=='BLA_SEM_ML') model=BLA_SEM_ML(formula=formula,data=data,W=W)
  } else if(DGP=='SARAR'){
    if(method=='BSPA_SARAR_ML') model=BSPA_SARAR_ML(formula=formula,data=data,W=W,W2=W2,control=con$control_gamboost,multi_start=isTRUE(con$multi_start))
    else if(method=='BSPA_SARAR_CFE') model=BSPA_SARAR_CFE(
      formula=formula,
      data=data,
      W=W,
      W2=W2,
      control=con$control_gamboost,
      iter_max=con$iter_max,
      tol_iter=con$tol_lambda,
      damping=if (!is.null(con$damping)) con$damping else 0.5,
      lambda_switch=if (!is.null(con$lambda_switch)) con$lambda_switch else 0.80,
      verbose=con$verbose,
      debug=isTRUE(con$debug),
      debug_fit_each_iter=isTRUE(con$debug_fit_each_iter),
      debug_print=if (is.null(con$debug_print)) TRUE else isTRUE(con$debug_print)
    )
    else if(method=='BLA_SARAR_ML') model=BLA_SARAR_ML(formula=formula,data=data,W=W,W2=W2)

  } else {
    stop(paste0("Unknown DGP: ", DGP, ". Expected one of 'SAR', 'SEM', 'SARAR'."))
  }

  if (is.null(model)) {
    stop(paste0("Method '", method, "' is not compatible with DGP='", DGP, "'."))
  }

  if (!inherits(model, "error")) {
    mstop_final <- suppressWarnings(tryCatch(as.integer(mboost::mstop(model)), error = function(e) NA_integer_))
    if (!is.finite(mstop_final)) mstop_final <- NA_integer_

    spbgam_meta <- list(
      method = method,
      DGP = DGP,
      mstop_criterion_requested = as.character(con$mstop_criterion[[1]]),
      cv_mode_requested = tolower(as.character(con$cv_mode[[1]])),
      control_mstop = suppressWarnings(as.integer(con$control_gamboost$mstop[[1]])),
      mstop_final = mstop_final,
      mstop_source = NA_character_,
      spectral_overlap_requested = isTRUE(con$spectral_overlap),
      spectral_k_requested = suppressWarnings(as.integer(con$spectral_k[[1]]))
    )

    if (!is.null(model$mstop_selection$best_mstop) &&
        is.finite(model$mstop_selection$best_mstop)) {
      spbgam_meta$mstop_source <- "cv"
    } else if (!is.null(spbgam_meta$mstop_criterion_requested) &&
               tolower(spbgam_meta$mstop_criterion_requested) %in% c("spatial", "sem_spatial", "cv")) {
      spbgam_meta$mstop_source <- "fixed_fallback"
    } else if (is.finite(mstop_final)) {
      spbgam_meta$mstop_source <- "fixed"
    }

    # Store call/metadata both as attributes (robust across object classes)
    # and as list components when possible for convenience.
    attr(model, "call_spbgam") <- spbgam_call
    attr(model, "spbgam_meta") <- spbgam_meta

    if (isTRUE(con$spectral_overlap)) {
      rho_use <- if (!is.null(model$rho)) as.numeric(model$rho)[1] else NA_real_
      spec_diag <- tryCatch(
        spb_compute_spectral_overlap(
          W = W,
          data = data,
          formula = formula,
          rho = rho_use,
          k = con$spectral_k,
          vars_pattern = as.character(con$spectral_vars_pattern[[1]])
        ),
        error = function(e) list(status = "error", reason = conditionMessage(e))
      )
      model$spectral_overlap <- spec_diag
    }

    model <- tryCatch({
      model$call_spbgam <- spbgam_call
      model$spbgam_meta <- spbgam_meta
      model
    }, error = function(e) model)
  }

  # Defensive class harmonization for all successful outputs.
  # This keeps downstream dispatch stable even when the underlying estimator
  # returns a plain gam/glm/lm object.
  if (!inherits(model, "error")) {
    cls <- class(model)
    cls <- setdiff(cls, c(method, "spboost", "spbbost"))
    # Put estimator + spboost first so S3 dispatch can use summary/predict methods.
    class(model) <- c(method, "spboost", cls)

    # CFE diagnostics: warn when closed-form exact root was not obtained and
    # suggest the ML counterpart for a robustness check.
    cfe_methods <- c("BSPA_SAR_CFE", "BLA_SAR_CFE", "MARS_SAR_CFE", "GAM_SAR_CFE", "BSPA_SEM_CFE", "BSPA_SEM_CFE_iter", "BSPA_SEM_CFE_BRUT", "MARS_SEM_CFE", "GAM_SEM_CFE")
    if (method %in% cfe_methods) {
      rho_method_use <- if (!is.null(model$rho_method)) as.character(model$rho_method[[1]]) else NA_character_
      exact_ok <- is.character(rho_method_use) && length(rho_method_use) == 1L &&
        !is.na(rho_method_use) &&
        rho_method_use %in% c("cfe_exact", "cfe_brut_iter_exact", "cfe_brut_residuals", "cfe_brut_exact", "cfe_filtered_exact")
      if (!exact_ok) {
        ml_counterpart <- switch(
          method,
          BSPA_SAR_CFE = "BSPA_SAR_ML",
          BLA_SAR_CFE = "BLA_SAR_ML",
          MARS_SAR_CFE = "MARS_SAR_ML",
          GAM_SAR_CFE = "GAM_SAR_ML",
          BSPA_SEM_CFE = "BSPA_SEM_ML",
          BSPA_SEM_CFE_iter = "BSPA_SEM_ML",
          BSPA_SEM_CFE_BRUT = "BSPA_SEM_ML",
          MARS_SEM_CFE = "MARS_SEM_ML",
          GAM_SEM_CFE = "BLA_SEM_ML",
          NA_character_
        )
        if (is.na(rho_method_use) || !nzchar(rho_method_use)) rho_method_use <- "unknown"
        if (!is.na(ml_counterpart) && nzchar(ml_counterpart)) {
          warning(
            sprintf(
              "spbgam(method='%s'): CFE did not return cfe_exact (rho_method='%s'). Consider re-estimating with '%s' (ML counterpart).",
              method, rho_method_use, ml_counterpart
            )
          )
        } else {
          warning(
            sprintf(
              "spbgam(method='%s'): CFE did not return cfe_exact (rho_method='%s'). Consider re-estimating with the corresponding ML estimator.",
              method, rho_method_use
            )
          )
        }
      }
    }
  }
  model
}

spb_make_boost_control <- function(control, mstop_override = NULL, data = NULL, method = NULL, DGP = NULL) {
  if (is.null(control)) {
    control <- mboost::boost_control()
  }
  if (!inherits(control, "boost_control")) {
    if (is.list(control)) {
      base_ctl <- as.list(mboost::boost_control())
      ctl_list <- utils::modifyList(base_ctl, control)
      class(ctl_list) <- "boost_control"
      control <- ctl_list
    } else {
      stop("`control_gamboost` must be a `boost_control` object or a compatible list.")
    }
  }

  # Adaptive default for invalid mstop:
  # - non-SEM: min(500 + round(n/2), 5000)
  # - SEM:     min(1500 + round(n/2), 5000)
  # where n = nrow(data), if available.
  n_obs <- suppressWarnings(as.integer(nrow(data)))
  if (length(n_obs) != 1L || is.na(n_obs) || !is.finite(n_obs) || n_obs < 0L) n_obs <- 0L
  method_chr <- if (length(method) > 0L) toupper(as.character(method[[1]])) else ""
  dgp_chr <- if (length(DGP) > 0L) toupper(as.character(DGP[[1]])) else ""
  is_sem_est <- identical(dgp_chr, "SEM") || grepl("SEM", method_chr, fixed = TRUE)
  mstop_default <- if (is_sem_est) {
    as.integer(min(1500 + round(n_obs / 2), 5000L))
  } else {
    as.integer(min(500 + round(n_obs / 2), 5000L))
  }
  if (!is.finite(mstop_default) || mstop_default < 1L) mstop_default <- if (is_sem_est) 1500L else 500L

  mstop_use <- suppressWarnings(as.integer(control$mstop[[1]]))
  if (!is.null(mstop_override)) {
    mstop_use <- as.integer(mstop_override[[1]])
  }
  if (length(mstop_use) != 1L || is.na(mstop_use) || !is.finite(mstop_use) || mstop_use < 1L) {
    mstop_use <- mstop_default
  }
  nu_use <- suppressWarnings(as.numeric(control$nu[[1]]))
  if (length(nu_use) != 1L || is.na(nu_use) || !is.finite(nu_use) || nu_use <= 0) nu_use <- 0.1
  risk_use <- as.character(control$risk[[1]])
  if (!nzchar(risk_use)) risk_use <- "inbag"

  mboost::boost_control(
    mstop = as.integer(mstop_use),
    nu = nu_use,
    risk = risk_use,
    stopintern = isTRUE(control$stopintern),
    center = isTRUE(control$center),
    trace = isTRUE(control$trace)
  )
}

spb_plot_spatial_cv_folds <- function(data_cv, coord_vars, fold_ids,
                                      main = "Spatial CV folds") {
  if (!all(coord_vars %in% names(data_cv))) return(NULL)
  x <- suppressWarnings(as.numeric(data_cv[[coord_vars[1]]]))
  y <- suppressWarnings(as.numeric(data_cv[[coord_vars[2]]]))
  fold_ids <- suppressWarnings(as.integer(fold_ids))
  ok <- is.finite(x) & is.finite(y) & is.finite(fold_ids)
  if (!any(ok)) return(NULL)

  fold_levels <- sort(unique(fold_ids[ok]))
  fold_index <- match(fold_ids, fold_levels)
  cols <- grDevices::hcl.colors(length(fold_levels), palette = "Dark 3")

  graphics::plot(
    x[ok], y[ok],
    col = cols[fold_index[ok]],
    pch = 19,
    xlab = coord_vars[1],
    ylab = coord_vars[2],
    main = main
  )
  graphics::legend(
    "topright",
    legend = paste("fold", fold_levels),
    col = cols,
    pch = 19,
    bty = "n",
    cex = 0.8
  )

  data.frame(
    x = x,
    y = y,
    fold = fold_ids
  )
}

spb_build_spatial_hex_folds <- function(data_cv, fit_cv, nfold,
                                        coord_vars = c("x", "y"),
                                        hex_size = NULL,
                                        hexagon = TRUE,
                                        spatial_crs = NA,
                                        spatial_progress = FALSE,
                                        cv_plot = FALSE) {
  if (!all(coord_vars %in% names(data_cv))) return(NULL)
  if (!requireNamespace("blockCV", quietly = TRUE) || !requireNamespace("sf", quietly = TRUE)) {
    return(NULL)
  }

  spatial_crs_num <- suppressWarnings(as.numeric(spatial_crs[[1]]))
  coord_x <- as.numeric(data_cv[[coord_vars[1]]])
  coord_y <- as.numeric(data_cv[[coord_vars[2]]])
  scale_factor <- 1

  pts <- tryCatch({
    if (is.finite(spatial_crs_num)) {
      sf::st_as_sf(data_cv, coords = coord_vars, crs = as.integer(spatial_crs_num), remove = FALSE)
    } else {
      # If CRS is missing (e.g., dgp() coordinates in [0,1]), map coordinates
      # to a pseudo-metric frame so blockCV size can be interpreted stably.
      span <- max(diff(range(coord_x, na.rm = TRUE)), diff(range(coord_y, na.rm = TRUE)))
      if (!is.finite(span) || span <= 0) return(NULL)
      scale_factor <- 10000 / span
      data_tmp <- data_cv
      data_tmp$.spb_x <- coord_x * scale_factor
      data_tmp$.spb_y <- coord_y * scale_factor
      sf::st_as_sf(data_tmp, coords = c(".spb_x", ".spb_y"), crs = 3857, remove = FALSE)
    }
  }, error = function(e) NULL)
  if (is.null(pts)) return(NULL)

  hex_size_use <- if (is.null(hex_size)) NA_real_ else suppressWarnings(as.numeric(hex_size[[1]]))
  if (!is.finite(spatial_crs_num) && is.finite(hex_size_use) && hex_size_use > 0) {
    hex_size_use <- hex_size_use * scale_factor
  }
  if (!is.finite(hex_size_use) || hex_size_use <= 0) {
    bb <- sf::st_bbox(pts)
    span <- max(as.numeric(bb$xmax - bb$xmin), as.numeric(bb$ymax - bb$ymin))
    if (!is.finite(span) || span <= 0) return(NULL)
    hex_size_use <- span / max(2, sqrt(nfold))
  }

  sb <- tryCatch({
    out <- NULL
    suppressWarnings(utils::capture.output({
      out <- blockCV::cv_spatial(
        x = pts,
        k = nfold,
        size = hex_size_use,
        hexagon = isTRUE(hexagon),
        progress = isTRUE(spatial_progress),
        report = FALSE,
        plot = FALSE
      )
    }))
    out
  }, error = function(e) NULL)
  if (is.null(sb) || is.null(sb$folds_ids)) return(NULL)

  fold_ids <- as.integer(sb$folds_ids)
  fold_levels <- sort(unique(fold_ids[is.finite(fold_ids)]))
  if (length(fold_levels) < 2L) return(NULL)

  weights <- model.weights(fit_cv)
  folds <- matrix(rep(weights, length(fold_levels)), ncol = length(fold_levels))
  for (j in seq_along(fold_levels)) {
    folds[fold_ids == fold_levels[j], j] <- 0
  }
  attr(folds, "type") <- paste0(length(fold_levels), "-fold spatial_hex")

  cv_plot_data <- NULL
  if (isTRUE(cv_plot)) {
    cv_plot_data <- spb_plot_spatial_cv_folds(
      data_cv = data_cv,
      coord_vars = coord_vars,
      fold_ids = fold_ids,
      main = "Spatial hex CV folds"
    )
  }

  list(folds = folds, hex_size = hex_size_use, cv_plot_data = cv_plot_data)
}

spb_build_spatial_block_folds <- function(data_cv, fit_cv, nfold,
                                          coord_vars = c("x", "y"),
                                          spatial_crs = NA,
                                          cv_plot = FALSE) {
  if (!all(coord_vars %in% names(data_cv))) return(NULL)
  if (!requireNamespace("blockCV", quietly = TRUE) || !requireNamespace("sf", quietly = TRUE)) {
    return(NULL)
  }

  spatial_crs_num <- suppressWarnings(as.numeric(spatial_crs[[1]]))
  pts <- tryCatch({
    if (is.finite(spatial_crs_num)) {
      sf::st_as_sf(data_cv, coords = coord_vars, crs = as.integer(spatial_crs_num), remove = FALSE)
    } else {
      sf::st_as_sf(data_cv, coords = coord_vars, crs = 3857, remove = FALSE)
    }
  }, error = function(e) NULL)
  if (is.null(pts)) return(NULL)

  sb <- tryCatch({
    out <- NULL
    suppressWarnings(utils::capture.output({
      out <- blockCV::cv_cluster(
        x = pts,
        k = nfold,
        report = FALSE
      )
    }))
    out
  }, error = function(e) NULL)
  if (is.null(sb) || is.null(sb$folds_ids)) return(NULL)

  fold_ids <- as.integer(sb$folds_ids)
  fold_levels <- sort(unique(fold_ids[is.finite(fold_ids)]))
  if (length(fold_levels) < 2L) return(NULL)

  weights <- model.weights(fit_cv)
  folds <- matrix(rep(weights, length(fold_levels)), ncol = length(fold_levels))
  for (j in seq_along(fold_levels)) {
    folds[fold_ids == fold_levels[j], j] <- 0
  }
  attr(folds, "type") <- paste0(length(fold_levels), "-fold spatial_block")

  cv_plot_data <- NULL
  if (isTRUE(cv_plot)) {
    cv_plot_data <- spb_plot_spatial_cv_folds(
      data_cv = data_cv,
      coord_vars = coord_vars,
      fold_ids = fold_ids,
      main = "Spatial block CV folds"
    )
  }

  list(folds = folds, hex_size = NA_real_, cv_plot_data = cv_plot_data)
}

spb_row_normalize <- function(W, tol = 1e-12) {
  if (is.null(W)) return(W)

  if (inherits(W, "Matrix")) {
    rs <- as.numeric(Matrix::rowSums(W))
    ok <- which(is.finite(rs) & abs(rs) > tol)
    if (length(ok) > 0L) {
      W[ok, ] <- W[ok, , drop = FALSE] / rs[ok]
    }
    return(W)
  }

  Wm <- as.matrix(W)
  rs <- as.numeric(base::rowSums(Wm))
  ok <- which(is.finite(rs) & abs(rs) > tol)
  if (length(ok) > 0L) {
    Wm[ok, ] <- Wm[ok, , drop = FALSE] / rs[ok]
  }
  Wm
}

spb_cv_oof_rmse_y_bpn <- function(formula, data, W, cv_folds, best_mstop, method, con) {
  if (is.null(cv_folds) || !is.matrix(cv_folds) || ncol(cv_folds) < 2L) {
    return(list(
      cv_rmse_y_bpn = NA_real_,
      cv_n_oof_pred = 0L,
      cv_oof_n = nrow(data),
      cv_fold_rmse_y_bpn = rep(NA_real_, if (is.null(cv_folds)) 0L else ncol(cv_folds)),
      cv_eval_error = "invalid_cv_folds",
      cv_oof_pred = NULL
    ))
  }

  if (!exists("predict_spboost", mode = "function")) {
    return(list(
      cv_rmse_y_bpn = NA_real_,
      cv_n_oof_pred = 0L,
      cv_oof_n = nrow(data),
      cv_fold_rmse_y_bpn = rep(NA_real_, ncol(cv_folds)),
      cv_eval_error = "predict_spboost_not_found",
      cv_oof_pred = NULL
    ))
  }

  y_all <- as.numeric(get_all_vars(formula, data)[, 1])
  n <- length(y_all)
  k <- ncol(cv_folds)
  pred_oof <- rep(NA_real_, n)
  rmse_by_fold <- rep(NA_real_, k)

  workers <- if (is.null(con$ncore)) k else as.integer(con$ncore[[1]])
  if (!is.finite(workers) || workers < 1L) workers <- 1L
  workers <- as.integer(min(max(1L, workers), k))
  if (workers > 1L && foreach::getDoParWorkers() > 1L) {
    warning("Nested parallel backend detected: OOF BPN CV switched to ncore = 1.")
    workers <- 1L
  }

  fold_runner <- function(j) {
    idx_test <- which(cv_folds[, j] == 0)
    idx_train <- which(cv_folds[, j] != 0)

    if (length(idx_test) == 0L || length(idx_train) < 2L) {
      return(list(ok = FALSE, idx_test = idx_test, pred = numeric(0), rmse = NA_real_, error = "empty_or_too_small_fold"))
    }

    d_train <- data[idx_train, , drop = FALSE]
    d_test <- data[idx_test, , drop = FALSE]

    idx_all <- c(idx_train, idx_test)
    W_train <- spb_row_normalize(W[idx_train, idx_train, drop = FALSE])
    W_in_out <- spb_row_normalize(W[idx_all, idx_all, drop = FALSE])

    control_fold <- spb_make_boost_control(con$control_gamboost, mstop_override = best_mstop)
    fit_fold <- tryCatch(
      spb_fit_bspa_sar(
        method = method,
        formula = formula,
        data = d_train,
        W = W_train,
        control_gamboost = control_fold,
        con = con
      ),
      error = function(e) e
    )

    if (inherits(fit_fold, "error")) {
      return(list(ok = FALSE, idx_test = idx_test, pred = numeric(0), rmse = NA_real_, error = conditionMessage(fit_fold)))
    }

    # Ensure class dispatch is consistent with predict_spboost()/predict.spboost checks.
    if (!inherits(fit_fold, method)) {
      cls_fold <- class(fit_fold)
      cls_fold <- setdiff(cls_fold, c(method, "spboost", "spbbost"))
      class(fit_fold) <- c(method, "spboost", cls_fold)
    }

    pred <- tryCatch(
      as.numeric(predict_spboost(
        model = fit_fold,
        newdata = d_test,
        data = d_train,
        W = W_in_out,
        type = "BPN"
      )),
      error = function(e) e
    )

    if (inherits(pred, "error") || length(pred) != length(idx_test)) {
      err <- if (inherits(pred, "error")) conditionMessage(pred) else "invalid_prediction_length"
      return(list(ok = FALSE, idx_test = idx_test, pred = numeric(0), rmse = NA_real_, error = err))
    }

    y_test <- y_all[idx_test]
    rmse_fold <- sqrt(mean((y_test - pred)^2, na.rm = TRUE))
    list(ok = TRUE, idx_test = idx_test, pred = pred, rmse = rmse_fold, error = NA_character_)
  }

  fold_res <- if (.Platform$OS.type != "windows" && workers > 1L) {
    parallel::mclapply(seq_len(k), fold_runner, mc.cores = workers, mc.preschedule = FALSE)
  } else {
    lapply(seq_len(k), fold_runner)
  }

  fold_errors <- character(0)
  for (j in seq_len(k)) {
    rj <- fold_res[[j]]
    rmse_by_fold[j] <- rj$rmse
    if (isTRUE(rj$ok)) {
      pred_oof[rj$idx_test] <- rj$pred
    } else if (!is.null(rj$error) && nzchar(rj$error)) {
      fold_errors <- c(fold_errors, paste0("fold_", j, ": ", rj$error))
    }
  }

  ok_oof <- is.finite(y_all) & is.finite(pred_oof)
  rmse_global <- if (any(ok_oof)) sqrt(mean((y_all[ok_oof] - pred_oof[ok_oof])^2, na.rm = TRUE)) else NA_real_
  err_msg <- if (length(fold_errors) > 0L) paste(fold_errors, collapse = " | ") else NA_character_

  list(
    cv_rmse_y_bpn = rmse_global,
    cv_n_oof_pred = as.integer(sum(ok_oof)),
    cv_oof_n = as.integer(n),
    cv_fold_rmse_y_bpn = rmse_by_fold,
    cv_eval_error = err_msg,
    cv_oof_pred = pred_oof
  )
}

spb_cv_spatial_mstop <- function(formula, data, y_filtered, control_gamboost,
                                 nfold = 5L, ncore = NULL, seed = NULL,
                                 cv_mode = "random",
                                 coord_vars = c("x", "y"),
                                 hex_size = NULL,
                                 hexagon = TRUE,
                                 spatial_crs = NA,
                                 spatial_progress = FALSE,
                                 cv_plot = FALSE) {
  mstop_max <- as.integer(control_gamboost$mstop[[1]])
  if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L

  nfold <- as.integer(nfold[[1]])
  if (!is.finite(nfold) || nfold < 2L) nfold <- 5L

  workers <- if (is.null(ncore)) nfold else as.integer(ncore[[1]])
  if (!is.finite(workers) || workers < 1L) workers <- nfold
  workers <- as.integer(max(1L, workers))
  if (workers > 1L && foreach::getDoParWorkers() > 1L) {
    warning("Nested parallel backend detected: spatial CV switched to ncore = 1.")
    workers <- 1L
  }

  data_cv <- data
  data_cv$Y_spatial <- as.numeric(y_filtered)
  f_cv <- stats::update.formula(formula, Y_spatial ~ .)
  fit_cv <- mboost::gamboost(
    formula = f_cv,
    data = data_cv,
    control = spb_make_boost_control(control_gamboost, mstop_override = mstop_max)
  )

  if (!is.null(seed)) set.seed(as.integer(seed[[1]]))

  cv_mode_requested <- tolower(as.character(cv_mode[[1]]))
  if (!cv_mode_requested %in% c("random", "spatial_block", "spatial_hex")) cv_mode_requested <- "random"
  cv_mode_used <- cv_mode_requested
  cv_hex_size <- NA_real_
  cv_folds <- NULL
  cv_plot_data <- NULL

  if (cv_mode_requested %in% c("spatial_block", "spatial_hex")) {
    folds_obj <- if (cv_mode_requested == "spatial_block") spb_build_spatial_block_folds(
      data_cv = data_cv,
      fit_cv = fit_cv,
      nfold = nfold,
      coord_vars = coord_vars,
      spatial_crs = spatial_crs,
      cv_plot = cv_plot
    ) else spb_build_spatial_hex_folds(
      data_cv = data_cv,
      fit_cv = fit_cv,
      nfold = nfold,
      coord_vars = coord_vars,
      hex_size = hex_size,
      hexagon = hexagon,
      spatial_crs = spatial_crs,
      spatial_progress = spatial_progress,
      cv_plot = cv_plot
    )
    if (is.null(folds_obj)) {
      warning(sprintf("%s CV failed or unavailable; falling back to random CV.", cv_mode_requested))
      cv_mode_used <- "random"
    } else {
      cv_folds <- folds_obj$folds
      cv_hex_size <- folds_obj$hex_size
      cv_plot_data <- folds_obj$cv_plot_data
    }
  }

  if (cv_mode_used == "random") {
    cv_folds <- mboost::cv(model.weights(fit_cv), type = "kfold", B = nfold)
  }

  if (.Platform$OS.type != "windows" && workers > 1L) {
    cv_res <- mboost::cvrisk(
      fit_cv,
      folds = cv_folds,
      grid = seq_len(mstop_max),
      papply = parallel::mclapply,
      mc.cores = workers,
      mc.preschedule = FALSE
    )
  } else {
    cv_res <- mboost::cvrisk(
      fit_cv,
      folds = cv_folds,
      grid = seq_len(mstop_max),
      papply = lapply
    )
  }

  best_mstop <- as.integer(mboost::mstop(cv_res))
  if (!is.finite(best_mstop) || best_mstop < 1L) best_mstop <- mstop_max

  cv_curve_mse_filtered <- rep(NA_real_, mstop_max)
  cv_mse_filtered_at_best <- NA_real_
  cv_rmse_filtered_at_best <- NA_real_
  cv_mat <- tryCatch(unclass(cv_res), error = function(e) NULL)
  if (is.matrix(cv_mat) && ncol(cv_mat) > 0L) {
    mmax <- min(length(cv_curve_mse_filtered), ncol(cv_mat))
    cv_curve_mse_filtered[seq_len(mmax)] <- colMeans(cv_mat[, seq_len(mmax), drop = FALSE], na.rm = TRUE)
    if (is.finite(best_mstop) && best_mstop >= 1L && best_mstop <= length(cv_curve_mse_filtered)) {
      cv_mse_filtered_at_best <- cv_curve_mse_filtered[best_mstop]
      if (is.finite(cv_mse_filtered_at_best) && cv_mse_filtered_at_best >= 0) {
        cv_rmse_filtered_at_best <- sqrt(cv_mse_filtered_at_best)
      }
    }
  }

  list(
    best_mstop = best_mstop,
    nfold = as.integer(ncol(cv_folds)),
    ncore = workers,
    cv_mode_requested = cv_mode_requested,
    cv_mode_used = cv_mode_used,
    cv_hex_size = cv_hex_size,
    cv_folds = cv_folds,
    cv_plot_data = cv_plot_data,
    cv_rmse_filtered_at_best = cv_rmse_filtered_at_best,
    cv_mse_filtered_at_best = cv_mse_filtered_at_best
  )
}

spb_fit_bspa_sar <- function(method, formula, data, W, control_gamboost, con) {
  if (method %in% c("BSPA_SAR_CFE", "BLA_SAR_CFE")) {
    return(BSPA_SAR_CFE(
      formula = formula, data = data, W = W,
      control = control_gamboost, doMC = con$doMC_cfe, ncores = con$ncores_cfe
    ))
  }
  if (method == "BSPA_SAR_ML") {
    return(BSPA_SAR_ML(
      formula = formula, data = data, W = W,
      control = control_gamboost, verbose = con$verbose
    ))
  }
  if (method == "MARS_SAR_CFE") {
    return(MARS_SAR_CFE(
      formula = formula, data = data, W = W,
      control = control_gamboost, control_earth = con$control_earth,
      doMC = con$doMC_cfe, ncores = con$ncores_cfe
    ))
  }
  if (method == "MARS_SAR_ML") {
    return(MARS_SAR_ML(
      formula = formula, data = data, W = W,
      control = control_gamboost, control_earth = con$control_earth,
      verbose = con$verbose
    ))
  }
  stop("Unsupported method in spb_fit_bspa_sar: ", method)
}

spb_sem_family <- function(I_lambdaW) {
  mboost::Family(
    ngradient = function(y, f, w = 1) as.numeric(I_lambdaW %*% (y - f)),
    loss = function(y, f) as.numeric((I_lambdaW %*% (y - f))^2),
    name = "SEM with fixed (I-lambda W)"
  )
}

spb_cv_sem_mstop <- function(formula, data, W, lambda_init, control_gamboost,
                             nfold = 5L, ncore = NULL, seed = NULL,
                             cv_mode = "random",
                             coord_vars = c("x", "y"),
                             hex_size = NULL,
                             hexagon = TRUE,
                             spatial_crs = NA,
                             spatial_progress = FALSE,
                             cv_plot = FALSE) {
  mstop_max <- as.integer(control_gamboost$mstop[[1]])
  if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L

  nfold <- as.integer(nfold[[1]])
  if (!is.finite(nfold) || nfold < 2L) nfold <- 5L

  workers <- if (is.null(ncore)) nfold else as.integer(ncore[[1]])
  if (!is.finite(workers) || workers < 1L) workers <- nfold
  workers <- as.integer(max(1L, workers))
  if (workers > 1L && foreach::getDoParWorkers() > 1L) {
    warning("Nested parallel backend detected: SEM CV switched to ncore = 1.")
    workers <- 1L
  }

  n <- nrow(data)
  I_lambdaW <- Matrix::Diagonal(n) - as.numeric(lambda_init[[1]]) * W
  fit_cv <- mboost::gamboost(
    formula = formula,
    data = data,
    control = spb_make_boost_control(control_gamboost, mstop_override = mstop_max),
    family = spb_sem_family(I_lambdaW)
  )

  if (!is.null(seed)) set.seed(as.integer(seed[[1]]))

  cv_mode_requested <- tolower(as.character(cv_mode[[1]]))
  if (!cv_mode_requested %in% c("random", "spatial_block", "spatial_hex")) cv_mode_requested <- "random"
  cv_mode_used <- cv_mode_requested
  cv_hex_size <- NA_real_
  cv_folds <- NULL
  cv_plot_data <- NULL

  if (cv_mode_requested %in% c("spatial_block", "spatial_hex")) {
    folds_obj <- if (cv_mode_requested == "spatial_block") spb_build_spatial_block_folds(
      data_cv = data,
      fit_cv = fit_cv,
      nfold = nfold,
      coord_vars = coord_vars,
      spatial_crs = spatial_crs,
      cv_plot = cv_plot
    ) else spb_build_spatial_hex_folds(
      data_cv = data,
      fit_cv = fit_cv,
      nfold = nfold,
      coord_vars = coord_vars,
      hex_size = hex_size,
      hexagon = hexagon,
      spatial_crs = spatial_crs,
      spatial_progress = spatial_progress,
      cv_plot = cv_plot
    )
    if (is.null(folds_obj)) {
      warning(sprintf("%s CV failed or unavailable for SEM; falling back to random CV.", cv_mode_requested))
      cv_mode_used <- "random"
    } else {
      cv_folds <- folds_obj$folds
      cv_hex_size <- folds_obj$hex_size
      cv_plot_data <- folds_obj$cv_plot_data
    }
  }

  if (cv_mode_used == "random") {
    cv_folds <- mboost::cv(model.weights(fit_cv), type = "kfold", B = nfold)
  }

  if (.Platform$OS.type != "windows" && workers > 1L) {
    cv_res <- mboost::cvrisk(
      fit_cv,
      folds = cv_folds,
      grid = seq_len(mstop_max),
      papply = parallel::mclapply,
      mc.cores = workers,
      mc.preschedule = FALSE
    )
  } else {
    cv_res <- mboost::cvrisk(
      fit_cv,
      folds = cv_folds,
      grid = seq_len(mstop_max),
      papply = lapply
    )
  }

  best_mstop <- as.integer(mboost::mstop(cv_res))
  if (!is.finite(best_mstop) || best_mstop < 1L) best_mstop <- mstop_max

  cv_curve_mse_filtered <- rep(NA_real_, mstop_max)
  cv_mse_filtered_at_best <- NA_real_
  cv_rmse_filtered_at_best <- NA_real_
  cv_mat <- tryCatch(unclass(cv_res), error = function(e) NULL)
  if (is.matrix(cv_mat) && ncol(cv_mat) > 0L) {
    mmax <- min(length(cv_curve_mse_filtered), ncol(cv_mat))
    cv_curve_mse_filtered[seq_len(mmax)] <- colMeans(cv_mat[, seq_len(mmax), drop = FALSE], na.rm = TRUE)
    if (is.finite(best_mstop) && best_mstop >= 1L && best_mstop <= length(cv_curve_mse_filtered)) {
      cv_mse_filtered_at_best <- cv_curve_mse_filtered[best_mstop]
      if (is.finite(cv_mse_filtered_at_best) && cv_mse_filtered_at_best >= 0) {
        cv_rmse_filtered_at_best <- sqrt(cv_mse_filtered_at_best)
      }
    }
  }

  list(
    best_mstop = best_mstop,
    nfold = as.integer(ncol(cv_folds)),
    ncore = workers,
    cv_mode_requested = cv_mode_requested,
    cv_mode_used = cv_mode_used,
    cv_hex_size = cv_hex_size,
    cv_folds = cv_folds,
    cv_plot_data = cv_plot_data,
    cv_rmse_filtered_at_best = cv_rmse_filtered_at_best,
    cv_mse_filtered_at_best = cv_mse_filtered_at_best
  )
}

spb_fit_bspa_sem <- function(method, formula, data, W, control_gamboost, con) {
  if (method == "BSPA_SEM_CFE") {
    return(BSPA_SEM_CFE(
      formula = formula, data = data, W = W,
      control = control_gamboost, doMC = con$doMC_cfe,
      cfe_aux_cv = isTRUE(con$sem_cfe_aux_cv),
      cfe_cv_nfold = con$sem_cfe_aux_nfold,
      cfe_cv_ncore = con$sem_cfe_aux_ncore,
      cfe_cv_seed = con$sem_cfe_aux_seed
    ))
  }
  if (method == "BSPA_SEM_CFE_iter") {
    return(BSPA_SEM_CFE_iter(
      formula = formula, data = data, W = W,
      control = control_gamboost,
      iter_max = con$iter_max,
      tol_lambda = con$tol_lambda,
      doMC = con$doMC_cfe,
      cfe_aux_cv = isTRUE(con$sem_cfe_aux_cv),
      cfe_cv_nfold = con$sem_cfe_aux_nfold,
      cfe_cv_ncore = con$sem_cfe_aux_ncore,
      cfe_cv_seed = con$sem_cfe_aux_seed
    ))
  }
  if (method == "BSPA_SEM_CFE_BRUT") {
    return(BSPA_SEM_CFE_BRUT(
      formula = formula, data = data, W = W,
      control = control_gamboost,
      tol = 1e-10,
      verbose = con$verbose
    ))
  }
  if (method == "BSPA_SEM_ML") {
    return(BSPA_SEM_ML(
      formula = formula, data = data, W = W,
      control = control_gamboost, verbose = con$verbose
    ))
  }
  if (method == "MARS_SEM_CFE") {
    return(MARS_SEM_CFE(
      formula = formula, data = data, W = W,
      control = control_gamboost, control_earth = con$control_earth,
      doMC = con$doMC_cfe, ncores = con$ncores_cfe
    ))
  }
  if (method == "MARS_SEM_ML") {
    return(MARS_SEM_ML(
      formula = formula, data = data, W = W,
      control = control_gamboost, control_earth = con$control_earth,
      verbose = con$verbose
    ))
  }
  stop("Unsupported method in spb_fit_bspa_sem: ", method)
}

spb_warn_w_quality <- function(W, name = "W", tol = 1e-8) {
  if (is.null(W)) return(invisible(NULL))

  rs <- tryCatch({
    if (inherits(W, "Matrix")) {
      as.numeric(Matrix::rowSums(W))
    } else {
      as.numeric(base::rowSums(as.matrix(W)))
    }
  }, error = function(e) NULL)

  if (is.null(rs)) {
    warning(name, " quality check skipped: unable to compute row sums.")
    return(invisible(NULL))
  }

  bad_finite <- !is.finite(rs)
  if (any(bad_finite)) {
    warning(name, " has ", sum(bad_finite), " non-finite row sum(s).")
  }

  rs_ok <- rs[is.finite(rs)]
  if (length(rs_ok) == 0L) return(invisible(NULL))

  n_islands <- sum(abs(rs_ok) <= tol)
  if (n_islands > 0L) {
    warning(name, " contains ", n_islands, " island row(s) (row sum ~ 0).")
  }

  non_island <- abs(rs_ok) > tol
  if (any(non_island)) {
    dev <- abs(rs_ok[non_island] - 1)
    n_bad <- sum(dev > tol)
    if (n_bad > 0L) {
      warning(
        name, " is not row-normalized: ", n_bad,
        " non-island row(s) differ from 1 (max abs dev=",
        format(max(dev), scientific = TRUE, digits = 3),
        "). Consider mgwrsar::normW()."
      )
    }
  }

  invisible(NULL)
}

spb_compute_spectral_overlap <- function(W, data, formula, rho,
                                         k = 50L,
                                         vars_pattern = "^X[0-9]+$") {
  t0 <- proc.time()[3]
  out <- list(
    status = "skipped",
    reason = NA_character_,
    k = NA_integer_,
    n = NA_integer_,
    by_var = NULL,
    mean_overlap = NA_real_,
    max_overlap = NA_real_,
    min_overlap = NA_real_,
    elapsed = NA_real_
  )

  if (is.null(W)) {
    out$reason <- "W_is_null"
    return(out)
  }
  if (!is.finite(as.numeric(rho)[1])) {
    out$reason <- "rho_not_finite"
    return(out)
  }

  y <- tryCatch(as.numeric(get_all_vars(formula, data)[, 1]), error = function(e) NULL)
  if (is.null(y) || length(y) < 3L) {
    out$reason <- "invalid_response"
    return(out)
  }

  x_vars <- grep(vars_pattern, names(data), value = TRUE)
  x_vars <- setdiff(x_vars, "X0")
  if (length(x_vars) == 0L) {
    out$reason <- "no_matching_covariates"
    return(out)
  }

  n <- length(y)
  k_use <- suppressWarnings(as.integer(k[[1]]))
  if (!is.finite(k_use) || k_use < 2L) k_use <- 50L
  k_use <- min(k_use, n - 1L)
  if (k_use < 2L) {
    out$reason <- "n_too_small"
    return(out)
  }

  Wn <- tryCatch(spb_row_normalize(W), error = function(e) W)
  S <- tryCatch({
    if (inherits(Wn, "Matrix")) {
      (Wn + Matrix::t(Wn)) / 2
    } else {
      Wm <- as.matrix(Wn)
      (Wm + t(Wm)) / 2
    }
  }, error = function(e) NULL)
  if (is.null(S)) {
    out$reason <- "failed_to_build_symmetric_W"
    return(out)
  }

  eig_vec <- tryCatch({
    has_rspectra <- requireNamespace("RSpectra", quietly = TRUE)
    if (n > 3000L && !has_rspectra) {
      return(NULL)
    }
    if (inherits(S, "Matrix") && has_rspectra && k_use < (n - 1L)) {
      eg <- RSpectra::eigs_sym(S, k = k_use, which = "LM")
      eg$vectors
    } else {
      Sm <- if (inherits(S, "Matrix")) as.matrix(S) else S
      if (n > 3000L) return(NULL)
      eg <- eigen(Sm, symmetric = TRUE)
      eg$vectors[, seq_len(k_use), drop = FALSE]
    }
  }, error = function(e) NULL)
  if (is.null(eig_vec) || !is.matrix(eig_vec)) {
    out$reason <- if (n > 3000L && !requireNamespace("RSpectra", quietly = TRUE)) "eigendecomposition_failed_rspectra_missing" else "eigendecomposition_failed"
    return(out)
  }

  spectral_profile <- function(v) {
    vv <- as.numeric(v)
    vv <- vv - mean(vv, na.rm = TRUE)
    vv[!is.finite(vv)] <- 0
    z <- as.numeric(crossprod(eig_vec, vv))
    e <- z^2
    s <- sum(e)
    if (!is.finite(s) || s <= 0) return(rep(NA_real_, ncol(eig_vec)))
    e / s
  }

  target <- suppressWarnings(as.numeric(rho)[1]) * as.numeric(Wn %*% y)
  p_target <- spectral_profile(target)
  if (!any(is.finite(p_target))) {
    out$reason <- "invalid_target_spectrum"
    return(out)
  }

  by_var <- lapply(x_vars, function(vn) {
    xv <- as.numeric(data[[vn]])
    px <- spectral_profile(xv)
    ov <- sum(pmin(px, p_target), na.rm = TRUE)
    cr <- suppressWarnings(stats::cor(px, p_target, use = "complete.obs"))
    data.frame(variable = vn, overlap = ov, spectral_corr = cr, stringsAsFactors = FALSE)
  })
  by_var <- do.call(rbind, by_var)
  by_var <- by_var[order(by_var$overlap, decreasing = TRUE), , drop = FALSE]

  out$status <- "ok"
  out$reason <- NA_character_
  out$k <- as.integer(ncol(eig_vec))
  out$n <- as.integer(n)
  out$by_var <- by_var
  out$mean_overlap <- mean(by_var$overlap, na.rm = TRUE)
  out$max_overlap <- max(by_var$overlap, na.rm = TRUE)
  out$min_overlap <- min(by_var$overlap, na.rm = TRUE)
  out$elapsed <- as.numeric(proc.time()[3] - t0)
  out
}

