#' summary.spboost
#' Summary method for `spbgam` estimators with full-model diagnostics.
#' @usage summary.spboost(object, ...)
#' @param object a fitted object returned by `spbgam`.
#' @param ... additional arguments passed to the underlying summary method.
#' @return An object of class `summary.spboost`.
#' @noRd
spb_summary_impl <- function(object, ...) {
  known_estimators <- c(
    "BSPA_SAR_ML", "BSPA_SAR_CFE", "BLA_SAR_CFE", "MARS_SAR_ML", "MARS_SAR_CFE", "GAM_SAR_ML", "GAM_SAR_CFE",
    "GAM_SAR_FIVA", "GAM_SAR_2SLSA", "XGBOOST_SAR_ML", "XGBOOST_SAR_CFE",
    "XGBOOST_LINEAR_SAR_ML", "XGBOOST_LINEAR_SAR_CFE", "LM_SAR_ML",
    "BLA_SAR_ML", "BSPA_SEM_ML", "BSPA_SEM_CFE", "BSPA_SEM_CFE_iter", "BSPA_SEM_CFE_BRUT", "MARS_SEM_ML", "MARS_SEM_CFE", "GAM_SEM_CFE", "BLA_SEM_ML",
    "BSPA_SARAR_ML", "BSPA_SARAR_CFE", "BLA_SARAR_ML", "glmboost_sarIV", "glmboost_sem"
  )
  estimator_candidates <- intersect(class(object), known_estimators)
  estimator <- if (length(estimator_candidates) > 0) estimator_candidates[1] else class(object)[1]

  base_obj <- object
  base_class <- setdiff(class(base_obj), c("spbbost", "spboost", known_estimators))
  base_summary <- NULL
  base_summary_error <- NULL
  if (length(base_class) > 0) {
    class(base_obj) <- base_class
    base_summary <- tryCatch(summary(base_obj, ...), error = function(e) e)
    if (inherits(base_summary, "error")) {
      base_summary_error <- conditionMessage(base_summary)
      base_summary <- NULL
    }
  }

  y <- NULL
  if (!is.null(object$Y) && !is.function(object$Y)) {
    y <- as.numeric(object$Y)
  } else if (!is.null(object$y) && !is.function(object$y)) {
    y <- as.numeric(object$y)
  }

  yhat <- NULL
  if (!is.null(object$fitted) && !is.function(object$fitted)) {
    yhat <- as.numeric(object$fitted)
  } else if (!is.null(object$fitted.values) && !is.function(object$fitted.values)) {
    yhat <- as.numeric(object$fitted.values)
  } else {
    yhat <- tryCatch(as.numeric(stats::fitted(object)), error = function(e) NULL)
  }

  nobs <- NA_integer_
  rmse_full <- NA_real_
  mae_full <- NA_real_
  r2_full <- NA_real_
  dev_full <- NA_real_

  if (!is.null(y) && !is.null(yhat)) {
    n <- min(length(y), length(yhat))
    if (n > 0) {
      y <- y[seq_len(n)]
      yhat <- yhat[seq_len(n)]
      ok <- is.finite(y) & is.finite(yhat)
      if (any(ok)) {
        y_ok <- y[ok]
        yhat_ok <- yhat[ok]
        e <- y_ok - yhat_ok
        sse <- sum(e^2)
        sst <- sum((y_ok - mean(y_ok))^2)

        nobs <- length(y_ok)
        rmse_full <- sqrt(mean(e^2))
        mae_full <- mean(abs(e))
        dev_full <- if (sst > 0) 1 - sse / sst else NA_real_
        r2_full <- dev_full
      }
    }
  } else if (!is.null(object$residuals) && !is.function(object$residuals)) {
    e <- as.numeric(object$residuals)
    e <- e[is.finite(e)]
    if (length(e) > 0) {
      nobs <- length(e)
      rmse_full <- sqrt(mean(e^2))
      mae_full <- mean(abs(e))
    }
  }

  if (!is.null(object$rmse) && is.finite(as.numeric(object$rmse)[1])) {
    rmse_full <- as.numeric(object$rmse)[1]
  }

  call_spbgam <- NULL
  if (!is.null(object$call_spbgam)) {
    call_spbgam <- object$call_spbgam
  } else if (!is.null(attr(object, "call_spbgam"))) {
    call_spbgam <- attr(object, "call_spbgam")
  }

  spbgam_meta <- NULL
  if (!is.null(object$spbgam_meta)) {
    spbgam_meta <- object$spbgam_meta
  } else if (!is.null(attr(object, "spbgam_meta"))) {
    spbgam_meta <- attr(object, "spbgam_meta")
  }

  mstop_value <- suppressWarnings(tryCatch(as.integer(mboost::mstop(object)), error = function(e) NA_integer_))
  if (length(mstop_value) < 1L) mstop_value <- NA_integer_
  mstop_value <- mstop_value[1]
  if (!is.finite(mstop_value)) {
    mstop_value <- suppressWarnings(tryCatch(as.integer(spbgam_meta$mstop_final[[1]]), error = function(e) NA_integer_))
    if (length(mstop_value) < 1L) mstop_value <- NA_integer_
    mstop_value <- mstop_value[1]
  }
  if (!is.finite(mstop_value)) mstop_value <- NA_integer_

  mstop_cv_mode <- NA_character_
  if (!is.null(object$mstop_selection$cv_mode_used)) {
    mstop_cv_mode <- as.character(object$mstop_selection$cv_mode_used)[1]
  }
  if (!is.character(mstop_cv_mode) || !nzchar(mstop_cv_mode)) mstop_cv_mode <- NA_character_

  cv_rmse_filtered_at_best <- suppressWarnings(tryCatch(
    as.numeric(object$mstop_selection$cv_rmse_filtered_at_best)[1],
    error = function(e) NA_real_
  ))
  cv_rmse_y_bpn <- suppressWarnings(tryCatch(
    as.numeric(object$mstop_selection$cv_rmse_y_bpn)[1],
    error = function(e) NA_real_
  ))
  cv_n_oof_pred <- suppressWarnings(tryCatch(
    as.integer(object$mstop_selection$cv_n_oof_pred)[1],
    error = function(e) NA_integer_
  ))
  cv_oof_n <- suppressWarnings(tryCatch(
    as.integer(object$mstop_selection$cv_oof_n)[1],
    error = function(e) NA_integer_
  ))
  cv_eval_error <- suppressWarnings(tryCatch(
    as.character(object$mstop_selection$cv_eval_error)[1],
    error = function(e) NA_character_
  ))
  if (is.character(cv_eval_error) && !nzchar(cv_eval_error)) cv_eval_error <- NA_character_

  mstop_source <- NA_character_
  if (!is.null(object$mstop_selection$best_mstop) &&
      is.finite(object$mstop_selection$best_mstop)) {
    mstop_source <- "CV"
  } else if (!is.null(spbgam_meta$mstop_source)) {
    src <- suppressWarnings(tolower(as.character(spbgam_meta$mstop_source)[1]))
    if (length(src) != 1L || is.na(src) || !nzchar(src)) src <- NA_character_
    if (identical(src, "fixed")) mstop_source <- "fixed"
    if (identical(src, "cv")) mstop_source <- "CV"
    if (identical(src, "fixed_fallback")) mstop_source <- "fixed (CV fallback)"
  } else if (is.finite(mstop_value)) {
    mstop_source <- "fixed"
  }

  if (identical(mstop_source, "fixed (CV fallback)") &&
      is.na(mstop_cv_mode) &&
      !is.null(spbgam_meta$cv_mode_requested)) {
    mode_req <- as.character(spbgam_meta$cv_mode_requested)[1]
    if (is.character(mode_req) && length(mode_req) == 1L && !is.na(mode_req) && nzchar(mode_req)) {
      mstop_cv_mode <- mode_req
    }
  }

  spectral_overlap <- if (!is.null(object$spectral_overlap)) object$spectral_overlap else NULL
  spectral_requested <- isTRUE(spbgam_meta$spectral_overlap_requested)
  spectral_status <- if (!is.null(spectral_overlap$status)) as.character(spectral_overlap$status)[1] else NA_character_
  spectral_reason <- if (!is.null(spectral_overlap$reason)) as.character(spectral_overlap$reason)[1] else NA_character_
  spectral_mean_overlap <- if (!is.null(spectral_overlap$mean_overlap)) as.numeric(spectral_overlap$mean_overlap)[1] else NA_real_
  spectral_max_overlap <- if (!is.null(spectral_overlap$max_overlap)) as.numeric(spectral_overlap$max_overlap)[1] else NA_real_
  spectral_k <- if (!is.null(spectral_overlap$k)) as.integer(spectral_overlap$k)[1] else suppressWarnings(as.integer(spbgam_meta$spectral_k_requested)[1])
  spectral_elapsed <- if (!is.null(spectral_overlap$elapsed)) as.numeric(spectral_overlap$elapsed)[1] else NA_real_
  spectral_top <- NULL
  if (!is.null(spectral_overlap$by_var) && is.data.frame(spectral_overlap$by_var) && nrow(spectral_overlap$by_var) > 0L) {
    spectral_top <- utils::head(spectral_overlap$by_var, 5L)
  }

  structure(
    list(
      estimator = estimator,
      call = object$call,
      call_spbgam = call_spbgam,
      mstop_value = mstop_value,
      mstop_source = mstop_source,
      mstop_cv_mode = mstop_cv_mode,
      cv_rmse_filtered_at_best = cv_rmse_filtered_at_best,
      cv_rmse_y_bpn = cv_rmse_y_bpn,
      cv_n_oof_pred = cv_n_oof_pred,
      cv_oof_n = cv_oof_n,
      cv_eval_error = cv_eval_error,
      rho = if (!is.null(object$rho)) as.numeric(object$rho)[1] else NA_real_,
      lambda = if (!is.null(object$lambda)) as.numeric(object$lambda)[1] else NA_real_,
      rho_method = if (!is.null(object$rho_method)) as.character(object$rho_method)[1] else NA_character_,
      rho_exact_root = if (!is.null(object$rho_exact_root)) suppressWarnings(as.integer(object$rho_exact_root)[1]) else NA_integer_,
      var_rho = if (!is.null(object$var_rho)) as.numeric(object$var_rho)[1] else NA_real_,
      se_rho = if (!is.null(object$var_rho) && is.finite(as.numeric(object$var_rho)[1]) && as.numeric(object$var_rho)[1] > 0) sqrt(as.numeric(object$var_rho)[1]) else NA_real_,
      z_rho = if (!is.null(object$rho) && !is.null(object$var_rho) &&
                  is.finite(as.numeric(object$rho)[1]) && is.finite(as.numeric(object$var_rho)[1]) &&
                  as.numeric(object$var_rho)[1] > 0) as.numeric(object$rho)[1] / sqrt(as.numeric(object$var_rho)[1]) else NA_real_,
      p_value_rho = if (!is.null(object$rho) && !is.null(object$var_rho) &&
                        is.finite(as.numeric(object$rho)[1]) && is.finite(as.numeric(object$var_rho)[1]) &&
                        as.numeric(object$var_rho)[1] > 0) 2 * stats::pnorm(-abs(as.numeric(object$rho)[1] / sqrt(as.numeric(object$var_rho)[1]))) else NA_real_,
      elapsed = if (!is.null(object$elapsed)) as.numeric(object$elapsed)[1] else NA_real_,
      nobs = nobs,
      rmse_full = rmse_full,
      mae_full = mae_full,
      r2_full = r2_full,
      deviance_explained_full = dev_full,
      spectral_requested = spectral_requested,
      spectral_status = spectral_status,
      spectral_reason = spectral_reason,
      spectral_k = spectral_k,
      spectral_mean_overlap = spectral_mean_overlap,
      spectral_max_overlap = spectral_max_overlap,
      spectral_elapsed = spectral_elapsed,
      spectral_top = spectral_top,
      base_summary = base_summary,
      base_summary_error = base_summary_error
    ),
    class = c("summary.spboost", "summary.spbbost")
  )
}

#' Summary method for `spboost` objects
#'
#' @param object A fitted object returned by `spbgam`.
#' @param ... Additional arguments passed to the underlying summary method.
#' @return An object of class `summary.spboost`.
#' @method summary spboost
#' @export
summary.spboost <- function(object, ...) {
  spb_summary_impl(object, ...)
}

#' @export
summary.spbbost <- function(object, ...) {
  summary.spboost(object, ...)
}

spb_format_p_value <- function(p, digits = 4L, eps = .Machine$double.eps) {
  p <- suppressWarnings(as.numeric(p[1L]))
  if (!is.finite(p)) return(NA_character_)
  p <- max(0, min(1, p))
  format.pval(p, digits = digits, eps = eps)
}

spb_print_summary <- function(x, ...) {
  if (!is.null(x$call_spbgam)) {
    cat("Call (spbgam):\n")
    print(x$call_spbgam)
  } else if (!is.null(x$call)) {
    cat("Call:\n")
    print(x$call)
  }

  cat("Estimator:", x$estimator, "\n")
  if (is.finite(x$mstop_value)) {
    cat("mstop:", x$mstop_value)
    if (!is.na(x$mstop_source) && nzchar(x$mstop_source)) cat(" (", x$mstop_source, ")", sep = "")
    cat("\n")
  } else if (!is.na(x$mstop_source) && nzchar(x$mstop_source)) {
    cat("mstop selection:", x$mstop_source, "\n")
  }
  if (!is.na(x$mstop_cv_mode) && nzchar(x$mstop_cv_mode)) {
    cat("CV mode:", x$mstop_cv_mode, "\n")
  }
  if (is.finite(x$cv_rmse_filtered_at_best)) {
    cat("CV RMSE on spatially filtered Y (at best mstop):", formatC(x$cv_rmse_filtered_at_best, digits = 6, format = "f"), "\n")
  }
  if (is.finite(x$cv_rmse_y_bpn)) {
    cat("CV RMSE on Y (OOF BPN, at best mstop):", formatC(x$cv_rmse_y_bpn, digits = 6, format = "f"), "\n")
    if (is.finite(x$cv_n_oof_pred) && is.finite(x$cv_oof_n) && x$cv_oof_n > 0) {
      cat("OOF predictions used:", x$cv_n_oof_pred, "/", x$cv_oof_n, "\n")
    }
  } else if (!is.na(x$cv_eval_error) && nzchar(x$cv_eval_error)) {
    cat("CV Y-OOF evaluation note:", x$cv_eval_error, "\n")
  }

  if (is.finite(x$rho) && is.finite(x$lambda)) {
    cat("Spatial parameter (rho/lambda):",
        paste0(formatC(x$rho, digits = 6, format = "f"), " / ",
               formatC(x$lambda, digits = 6, format = "f")),
        "\n")
  } else if (is.finite(x$rho)) {
    cat("Spatial parameter (rho/lambda):", formatC(x$rho, digits = 6, format = "f"), "\n")
  }
  if (!is.na(x$rho_method) && nzchar(x$rho_method)) {
    cat("Spatial estimator:", x$rho_method, "\n")
  }
  if (is.finite(x$rho_exact_root)) {
    cat("CFE exact root selected:", x$rho_exact_root, "\n")
  }
  if (is.finite(x$var_rho)) {
    cat("Var(rho/lambda):", formatC(x$var_rho, digits = 6, format = "f"), "\n")
  }
  if (is.finite(x$se_rho)) {
    cat("SE(rho/lambda):", formatC(x$se_rho, digits = 6, format = "f"), "\n")
  }
  if (is.finite(x$z_rho)) {
    cat("Wald z-statistic:", formatC(x$z_rho, digits = 6, format = "f"), "\n")
  }
  if (is.finite(x$p_value_rho)) {
    cat("p-value (H0: rho/lambda = 0):", spb_format_p_value(x$p_value_rho), "\n")
  }
  if (is.finite(x$elapsed)) {
    cat("Elapsed (s):", formatC(x$elapsed, digits = 3, format = "f"), "\n")
  }

  if (isTRUE(x$spectral_requested) || is.finite(x$spectral_mean_overlap) || !is.null(x$spectral_top)) {
    cat("Spectral overlap (X vs rhoWy): ")
    if (!is.na(x$spectral_status) && identical(x$spectral_status, "ok")) {
      cat("enabled\n")
      if (is.finite(x$spectral_k)) cat("  k eigvec:", x$spectral_k, "\n")
      if (is.finite(x$spectral_mean_overlap)) cat("  mean overlap:", formatC(x$spectral_mean_overlap, digits = 4, format = "f"), "\n")
      if (is.finite(x$spectral_max_overlap)) cat("  max overlap :", formatC(x$spectral_max_overlap, digits = 4, format = "f"), "\n")
      if (is.finite(x$spectral_elapsed)) cat("  elapsed (s) :", formatC(x$spectral_elapsed, digits = 3, format = "f"), "\n")
      if (!is.null(x$spectral_top) && nrow(x$spectral_top) > 0L) {
        cat("  top variables by overlap:\n")
        print(x$spectral_top, row.names = FALSE)
      }
    } else {
      cat("requested but unavailable")
      if (!is.na(x$spectral_reason) && nzchar(x$spectral_reason)) cat(" (", x$spectral_reason, ")", sep = "")
      cat("\n")
    }
  }

  cat("\nFull model diagnostics (original Y scale)\n")
  if (!is.na(x$nobs)) cat("n =", x$nobs, "\n")
  cat("RMSE:", formatC(x$rmse_full, digits = 6, format = "f"), "\n")
  cat("MAE :", formatC(x$mae_full, digits = 6, format = "f"), "\n")
  cat("R2  :", formatC(x$r2_full, digits = 6, format = "f"), "\n")
  cat("Deviance explained (full):", formatC(x$deviance_explained_full, digits = 6, format = "f"), "\n")

  if (!is.null(x$base_summary)) {
    cat("\nUnderlying model summary (spatially filtered equation)\n")
    print(x$base_summary, ...)
  } else if (!is.null(x$base_summary_error)) {
    cat("\nUnderlying summary unavailable:", x$base_summary_error, "\n")
  }

  invisible(x)
}

#' @export
print.summary.spboost <- function(x, ...) {
  spb_print_summary(x, ...)
}

#' @export
print.summary.spbbost <- function(x, ...) {
  print.summary.spboost(x, ...)
}
