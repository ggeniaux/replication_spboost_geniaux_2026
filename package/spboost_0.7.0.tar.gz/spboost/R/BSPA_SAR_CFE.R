#' BSPA_SAR_CFE
#' BSPA_SAR_CFE allows the estimation of additive non linear SAR models using gradient boosting for the non linear part while the spatial parameter is estimated with the determinant-free Closed-Form Estimator of Smirnov (2020, doi:10.1111/gean.12268). This function makes it possible to estimate an additive non linear SAR model while automatically selecting the explanatory variables.
#' @usage BSPA_SAR_CFE(formula,data,W,control=boost_control(),doMC=FALSE,ncores=3,
#' fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10)
#' @param formula a gamboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param control boost_control() see mboost help.
#' @param doMC deprecated, ignored. CFE pre-fits are now sequential.
#' @param ncores deprecated, ignored. CFE pre-fits are now sequential.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses ratio/IV approximations, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 3
#' )
#' fit <- BSPA_SAR_CFE(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' fit$rho
#' summary(fit)
BSPA_SAR_CFE<-function(formula,data,W,control=boost_control(),doMC=FALSE,ncores=3,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10){
  fallback <- match.arg(fallback)
  if (isTRUE(doMC)) {
    warning("doMC is deprecated and ignored in BSPA_SAR_CFE(); CFE pre-fits are sequential.")
  }
  ptm1<-proc.time()
  Y=get_all_vars(formula, data)[,1]
  data$Y=Y
  n=length(Y)
  data$WY=as.numeric(W%*%Y)
  data$W2Y=as.numeric(W%*%data$WY)
  f0=formula
  f0<-update.formula(f0,'Y~.')
  f1<-update.formula(f0,'WY~.')
  f2<-update.formula(f0,'W2Y~.')
  m0 <- mboost::gamboost(f0, data = data, control = control)
  m1 <- mboost::gamboost(f1, data = data, control = control)
  m2 <- mboost::gamboost(f2, data = data, control = control)

  e0=residuals(m0)
  e1=residuals(m1)
  e2=residuals(m2)
  a=as.numeric(t(e1) %*% e2)
  b=as.numeric(t(e0)%*% e2+t(e1) %*% e1)
  c=as.numeric(t(e0)%*% e1)
  D=b^2-4*a*c

  rho <- NA_real_
  rho_method <- NA_character_
  if (D < 0 && abs(D) <= tol) D <- 0
  if (abs(a) > tol && D >= 0) {
    sqrtD <- sqrt(D)
    cands <- c((b - sqrtD)/(2*a), (b + sqrtD)/(2*a))
    ok    <- is.finite(cands) &
      cands >= rho_bounds[1] & cands <= rho_bounds[2]
    if (any(ok)) {
      cands_ok <- cands[ok]
      scores   <- sapply(cands_ok, function(r) sum((e0 - r*e1)^2))
      rho      <- as.numeric(cands_ok[which.min(scores)])
      rho_method <- "cfe_exact"
    } else {
      rho      <- as.numeric(cands[which.min(abs(cands - mean(rho_bounds)))])
      rho      <- max(min(rho, rho_bounds[2]), rho_bounds[1])
      rho_method <- "cfe_exact_clipped"
    }
  } else if (fallback == "auto") {
    den_r <- b
    if (abs(den_r) > tol) {
      rho <- as.numeric(c / den_r)
      rho_method <- "cfe_ratio_R"
    } else {
      den_iv <- as.numeric(t(e1) %*% e1)
      if (abs(den_iv) > tol) {
        rho <- as.numeric(c / den_iv)
        rho_method <- "cfe_iv"
      }
    }
  }

  if (is.na(rho) || !is.finite(rho)) {
    model <- paste0("CFE failed: no admissible SAR rho (D=", signif(D, 6), ", a=", signif(a, 6), ").")
    class(model) <- "error"
    return(model)
  }

  rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
  data$YS=as.numeric(Y-rho*data$WY)
  f3<-update.formula(f0,'YS~.')
  model=gamboost(f3,data=data,control=control)
  model$call[['formula']]=deparse(formula)
  den_var <- (b - 2*rho*a)
  if (abs(den_var) > tol) {
    model$var_rho=(t(e0-rho*e1) %*% (e0-rho*e1)/n)/den_var
  } else {
    model$var_rho=NA_real_
  }
  duree<-(proc.time()-ptm1)[3]
  model$residuals=residuals(model)
  model$fittedYS=fitted(model)
  model$fitted=Y-model$residuals
  model$rmse=sqrt(mean(model$residuals^2))
  model$rho=rho
  model$rho_method=rho_method
  model$D=D
  model$elapsed=duree
  model$formula=formula
  model$Y=Y
  class(model)<-c('spboost','BSPA_SAR_CFE',class(model))
  return(model)
}
