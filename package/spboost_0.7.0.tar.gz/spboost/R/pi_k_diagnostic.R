#' Spectral projection diagnostic pi_k for penalized-spline smoothers
#'
#' Computes the spectral projection coefficients
#' \eqn{\pi_k = \phi_k^\top S_{\hat\mu} \phi_k}, where \eqn{\phi_k} are the
#' dominant eigenvectors of the symmetrised spatial weight matrix and
#' \eqn{S_{\hat\mu}} is the smoothing operator of a fitted additive model
#' with smoothing parameters held fixed at their estimated values.
#' \eqn{\pi_k \in [0,1]} measures the fraction of the k-th spatial
#' eigenvector lying in the column space of the fitted smoother: values
#' close to 1 on low-frequency modes (large eigenvalues) signal a risk of
#' spatial confounding between the additive covariate component and the
#' spatial autoregressive component (spectral separation condition HSS).
#'
#' The smoother matrix is never formed explicitly: for a gaussian
#' additive model at fixed smoothing parameters,
#' \eqn{S_{\hat\mu}\phi_k = X(X^\top W X + S_\lambda)^{-1}X^\top W\phi_k},
#' which is evaluated directly from the fitted object (its linear
#' predictor matrix and Bayesian covariance matrix), at the cost of a
#' few matrix products for all \code{k} eigenvectors at once.
#'
#' @param fit a fitted \code{mgcv::gam} or \code{mgcv::bam} model with
#'   gaussian family and identity link (for example an auxiliary regression
#'   of a CFE estimator).
#' @param W spatial weight matrix (\code{n x n}, dense or sparse
#'   \code{Matrix}), with rows aligned with the data used in \code{fit}.
#'   It is symmetrised internally as \code{(W + t(W))/2}.
#' @param k integer, number of dominant eigenvectors to use (default 25).
#' @param eigs optional list with components \code{vectors} (an
#'   \code{n x k} matrix of orthonormal eigenvectors of the symmetrised
#'   \code{W}) and \code{values} (the corresponding eigenvalues), as
#'   returned by \code{RSpectra::eigs_sym} or \code{eigen}. When supplied,
#'   the internal eigendecomposition is skipped; useful to reuse one
#'   decomposition across several fits sharing the same \code{W}.
#' @return a \code{data.frame} with columns \code{mode} (rank of the
#'   eigenvector, by decreasing eigenvalue), \code{omega} (eigenvalue of
#'   the symmetrised \code{W}) and \code{pi_k} (the projection
#'   coefficient).
#' @details For \code{n > 3000} the \code{RSpectra} package is required
#'   (sparse iterative eigendecomposition); below that size a dense
#'   \code{eigen} fallback is used when \code{RSpectra} is unavailable.
#' @examples
#' \donttest{
#' sim <- dgp(n = 400, rho = 0.5, sigma2 = 1, model = 'SAR', nonlin = TRUE,
#'            myseed = 1, SNR = 0.7)
#' fit <- mgcv::gam(Y ~ s(X1) + s(X2) + s(X3), data = sim$data)
#' pi_k_diagnostic(fit, sim$W, k = 10)
#' }
#' @export
pi_k_diagnostic <- function(fit, W, k = 25L, eigs = NULL) {
  if (!inherits(fit, "gam")) {
    stop("'fit' must be a fitted mgcv::gam or mgcv::bam model")
  }
  if (!is.null(fit$family) &&
      !(fit$family$family == "gaussian" && fit$family$link == "identity")) {
    stop("pi_k_diagnostic is only implemented for gaussian models with identity link")
  }
  n <- length(fit$y)
  if (n == 0L) n <- nrow(fit$model)
  if (is.null(W) || nrow(W) != n || ncol(W) != n) {
    stop("'W' must be an n x n matrix aligned with the data used in 'fit'")
  }
  k_use <- suppressWarnings(as.integer(k[[1]]))
  if (!is.finite(k_use) || k_use < 1L) k_use <- 25L
  k_use <- min(k_use, n - 1L)

  if (is.null(eigs)) {
    S <- if (inherits(W, "Matrix")) {
      (W + Matrix::t(W)) / 2
    } else {
      Wm <- as.matrix(W)
      (Wm + t(Wm)) / 2
    }
    has_rspectra <- requireNamespace("RSpectra", quietly = TRUE)
    if (has_rspectra && k_use < (n - 1L)) {
      eg <- RSpectra::eigs_sym(S, k = k_use, which = "LA")
      ord <- order(eg$values, decreasing = TRUE)
      phi <- eg$vectors[, ord, drop = FALSE]
      omega <- eg$values[ord]
    } else {
      if (n > 3000L) {
        stop("n > 3000 requires the 'RSpectra' package for the eigendecomposition")
      }
      eg <- eigen(as.matrix(S), symmetric = TRUE)
      phi <- eg$vectors[, seq_len(k_use), drop = FALSE]
      omega <- eg$values[seq_len(k_use)]
    }
  } else {
    phi <- as.matrix(eigs$vectors)
    omega <- as.numeric(eigs$values)
    if (nrow(phi) != n) stop("'eigs$vectors' must have n rows")
    k_use <- min(k_use, ncol(phi))
    phi <- phi[, seq_len(k_use), drop = FALSE]
    omega <- omega[seq_len(k_use)]
  }

  ## closed form: S phi = X (X'WX + S_lambda)^{-1} X' W phi, with
  ## (X'WX + S_lambda)^{-1} = Vp / sig2 from the fitted object
  ## call predict.gam explicitly: spboost objects prepend their own class,
  ## whose predict method does not understand type = "lpmatrix"
  Xlp <- mgcv::predict.gam(fit, type = "lpmatrix")
  w <- fit$prior.weights
  if (is.null(w) || !length(w)) w <- rep(1, n)
  if (is.null(fit$sig2) || !is.finite(fit$sig2) || fit$sig2 <= 0) {
    stop("'fit' has no usable scale estimate (sig2)")
  }
  Sphi <- Xlp %*% ((fit$Vp / fit$sig2) %*% crossprod(Xlp * w, phi))
  pis <- colSums(phi * Sphi) / colSums(phi^2)

  data.frame(mode = seq_len(ncol(phi)), omega = omega,
             pi_k = as.numeric(pis))
}
