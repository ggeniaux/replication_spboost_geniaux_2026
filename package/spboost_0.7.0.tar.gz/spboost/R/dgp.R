#' dgp
#' a function to simulate non-linear spatial autoregressive SAR SEM and SARAR model.
#' @usage dgp(n,rho,betas=NULL,sigma2,model='SAR',lambda=NULL,
#' nonlin=FALSE,X_het=FALSE,X_sp=FALSE,X3_sp=FALSE,f_sp=FALSE,f_corsp=FALSE,
#' X_cor=FALSE,zeta=1,K1=4,K2=6,maxobs=10000,myseed=1,
#' SNR=NULL,snr_method=c('exact','hutch'),snr_m=64L,snr_seed=NULL)
#' @param n  to be documented
#' @param rho  to be documented
#' @param betas numeric vector of length `p+1` where `p` is the number of
#' true covariates in the DGP (currently `p=3`). The first element is the
#' intercept (`beta0`), followed by coefficients for `X1, X2, X3`.
#' If `NULL`, defaults to `c(0,0,0,0)`.
#' @param sigma2  to be documented
#' @param model  to be documented
#' @param lambda to be documented
#' @param nonlin  to be documented
#' @param X_het  to be documented
#' @param X_sp  to be documented
#' @param X3_sp logical. If TRUE, inject spatial autocorrelation into X3 using
#' the same fixed coefficient (0.7) used for X_sp.
#' @param f_sp  to be documented
#' @param f_corsp logical/numeric flag. If TRUE (or 1), build X4, X5, X6 from
#' normalized Euclidean distances to fixed points (0.2,0.2), (0.8,0.2),
#' (0.5,0.8), instead of random draws.
#' @param X_cor  to be documented
#' @param zeta scalar multiplier applied to the spatial heterogeneity term
#' `HS` in the disturbance when `X_het=TRUE`, i.e. `eps <- eps + zeta*HS`.
#' @param K1  number of neighbors (SAR, SEM)
#' @param K2  number of neighbors (SARAR)
#' @param maxobs max observation for solve default 10000
#' @param myseed seed number
#' @param SNR target signal-to-noise ratio in ]0,1[ for SAR/SEM. If provided,
#' sigma2 is calibrated analytically for each simulated dataset.
#' @param snr_method method for tau_B in SNR calibration: 'exact' or 'hutch'
#' @param snr_m number of Rademacher vectors for Hutchinson trace estimator
#' @param snr_seed optional seed used only for SNR calibration with hutch
#' @return to be documented
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 1
#' )
#' names(sim)
#' head(sim$data)
dgp=function(n,rho,betas=NULL,sigma2,model='SAR',lambda=NULL,nonlin=FALSE,X_het=FALSE,X_sp=FALSE,X3_sp=FALSE,f_sp=FALSE,f_corsp=FALSE,X_cor=FALSE,zeta=1,K1=4,K2=6,maxobs=10000,myseed=1,SNR=NULL,snr_method=c('exact','hutch'),snr_m=64L,snr_seed=NULL){
  mycall <- match.call()
  snr_method <- match.arg(snr_method)
  f_corsp <- isTRUE(f_corsp) || (is.numeric(f_corsp) && length(f_corsp) == 1L && is.finite(f_corsp) && f_corsp != 0)
  zeta <- as.numeric(zeta[[1]])
  if(!is.finite(zeta)) stop('zeta must be a finite numeric scalar')

  if(!is.null(SNR)){
    if(!model %in% c('SAR','SEM')) stop('SNR calibration currently implemented for SAR and SEM only')
    if(!is.numeric(SNR) || length(SNR)!=1 || !is.finite(SNR) || SNR<=0 || SNR>=1) stop('SNR must be a scalar in ]0,1[')
    if(!is.numeric(snr_m) || length(snr_m)!=1 || snr_m<1) stop('snr_m must be a positive integer')
    snr_m <- as.integer(snr_m)
  }

  set.seed(myseed)
  coords=cbind(runif(n),runif(n))
  HS=rep(0,n)
  if(X_het) {
    HS=sqrt(abs(coords[,1]-0.35)+abs(coords[,2]-0.65))
    HS=as.numeric(scale(HS,center=TRUE, scale = FALSE))
  }
  eps_shift <- if (X_het) as.numeric(zeta * HS) else rep(0, n)

  f1=function(x) rep(0,length(x))  #(x/2)^3
  f2=function(x) {
    delta <- 0.01
    sqrt(3 * ((2 * x - 1)^2 + delta^2)) - delta * sqrt(3)
  }
  f3=function(x) ((sin(2*pi*x))+1)/2 #-0.5
  #f4= function(x) f2(x) + (1+x*coords[,1]-sqrt(x)*coords[,2])^2
  f5=function(x) x-0.5
  myf=c('f1','f5','f2','f3')
  #if(f_sp)   myf=c('f5','f5','f4','f3')

  W=kernel_matW(H=K1,kernels='rectangle',coords=coords,NN=2,adaptive=TRUE,diagnull=TRUE)
  if(nrow(W)<=maxobs) iW= Matrix::solve(Matrix::Diagonal(nrow(W))-rho*W) else iW=ApproxiW(W,rho,18)

  if(model=='SARAR'){
    W2=kernel_matW(H=K2,kernels='rectangle',coords=coords,NN=8,adaptive=TRUE,diagnull=TRUE)
    W2[W>0]<-0
    W2<-W2/rowSums(W2)
    if(nrow(W)<=maxobs) iW2= Matrix::solve(Matrix::Diagonal(nrow(W))-lambda*W2) else iW2=ApproxiW(W2,lambda,18)
  } else W2=NULL

  ### generate X
  X_const=cbind(const=rep(1,n),X1=runif(n),X2=runif(n),X3=runif(n))
  if(f_sp)   X_const[,3]<-sqrt((coords[,1] - c(0.2, 0.2))^2 + (coords[,2] - c(0.2, 0.2))^2)
  p_true <- ncol(X_const) - 1L
  if(is.null(betas)) betas <- rep(0, p_true + 1L)
  if(!is.numeric(betas) || length(betas) != (p_true + 1L) || any(!is.finite(betas))) {
    stop(paste0("`betas` must be a numeric vector of length ", p_true + 1L,
                " = c(beta0, beta1, ..., beta", p_true, ")."))
  }
  beta0 <- as.numeric(betas[1])
  beta_cov <- as.numeric(betas[-1])
  if(X_sp || X3_sp){
    W_Xsp=kernel_matW(H=K1,kernels='rectangle',coords=coords,NN=50,adaptive=TRUE,diagnull=TRUE)
    if (X_sp) X_const[,2]=as.numeric(ApproxiW_apply(W_Xsp, 0.7, X_const[,2], order = 6, tol = 1e-6, max_order = 50L)) #
    if (X3_sp) X_const[,4]=as.numeric(ApproxiW_apply(W_Xsp, 0.7, X_const[,4], order = 6, tol = 1e-6, max_order = 50L)) #
  }
  if(f_corsp){
    poi <- rbind(c(0.2, 0.2), c(0.8, 0.2), c(0.5, 0.8))
    dmat <- cbind(
      sqrt((coords[,1] - poi[1,1])^2 + (coords[,2] - poi[1,2])^2),
      sqrt((coords[,1] - poi[2,1])^2 + (coords[,2] - poi[2,2])^2),
      sqrt((coords[,1] - poi[3,1])^2 + (coords[,2] - poi[3,2])^2)
    )
    dmat <- dmat / sqrt(2)  # Normalize distances to [0,1] over unit square.
    OX <- cbind(X4 = dmat[,1], X5 = dmat[,2], X6 = dmat[,3], X7 = rnorm(n,-1))
  } else {
    OX <- cbind(X4 = rnorm(n), X5 = -runif(n), X6 = runif(n,2,4), X7 = rnorm(n,-1))
  }

  if(X_cor && !f_corsp) {

    getCor <- function(n, rho, mar.fun=rnorm, x = NULL) {
      if (!is.null(x)) {X1 <- x} else {X1 <- mar.fun(n)}
      if (!is.null(x) & length(x) != n) warning("Variable x does not have the same length as n!")

      C <- matrix(rho, nrow = 2, ncol = 2)
      diag(C) <- 1

      C <- chol(C)

      X2 <- mar.fun(n)
      X <- cbind(X1,X2)
      df <- X %*% C
      return(df[,2])
    }
    ## correlated irrelevant candidates: corr 0.2 with X1, corr 0.7 with X2
    ## (was X_const[,1] = the constant column, an off-by-one)
    OX[,3]<-getCor(n,0.2,mar.fun=rnorm, x= X_const[,2])
    OX[,4]<-getCor(n,0.7,mar.fun=runif, x= X_const[,3])

  } else if (X_cor && f_corsp) {
    warning("f_corsp=TRUE: X_cor adjustments on OX were skipped to preserve distance-based X4:X6.")
  }
  OX<-scale(OX,center=T, scale = FALSE)
  XB=matrix(0,ncol=p_true + 1L,nrow=n)
  XB[,1]=rep(beta0,n)
  for(j in seq_len(p_true)) {
    if(nonlin) {
      f_j <- get(myf[j + 1L], mode = "function")
      z_j <- as.numeric(f_j(X_const[,j + 1L]))
      z_j <- as.numeric(scale(z_j, center = TRUE, scale = FALSE))
      XB[,j + 1L] = beta_cov[j] + z_j
    } else {
      XB[,j + 1L]=as.numeric(X_const[,j + 1L] * beta_cov[j])
    }
  }
  xb=rowSums(XB)

  snr_target <- NA_real_
  snr_theoretical <- NA_real_
  snr_signal <- NA_real_
  snr_tauB <- NA_real_
  snr_shift <- NA_real_
  snr_shift_base <- NA_real_
  snr_max_feasible <- NA_real_
  zeta_max_feasible <- NA_real_
  snr_method_used <- NA_character_

  if(!is.null(SNR)){
    snr_target <- as.numeric(SNR)
    snr_method_used <- snr_method

    if(snr_method=='exact'){
      snr_tauB <- sum(iW*iW)
    } else {
      if(!is.null(snr_seed)) set.seed(snr_seed)
      Z <- matrix(sample(c(-1,1), n*snr_m, replace=TRUE), n, snr_m)
      YZ <- iW %*% Z
      snr_tauB <- mean(colSums(YZ*YZ))
    }

    if(model=='SAR'){
      BX <- as.numeric(iW %*% xb)
      snr_signal <- sum(BX*BX)
      if (X_het) {
        snr_shift_base <- sum((as.numeric(iW %*% HS))^2)
      } else {
        snr_shift_base <- 0
      }
      snr_shift <- (zeta^2) * snr_shift_base
    } else if(model=='SEM'){
      snr_signal <- sum(xb*xb)
      if (X_het) {
        snr_shift_base <- sum((as.numeric(iW %*% HS))^2)
      } else {
        snr_shift_base <- 0
      }
      snr_shift <- (zeta^2) * snr_shift_base
    }

    target_noise <- as.numeric(snr_signal * (1 - snr_target) / snr_target)
    sigma2 <- as.numeric((target_noise - snr_shift) / snr_tauB)
    if(!is.finite(sigma2) || sigma2<=0) {
      if (is.finite(snr_signal) && is.finite(snr_shift) && (snr_signal + snr_shift) > 0) {
        snr_max_feasible <- snr_signal / (snr_signal + snr_shift)
      }
      if (isTRUE(X_het) && is.finite(target_noise) && is.finite(snr_shift_base) && snr_shift_base > 0) {
        zeta_max_feasible <- sqrt(max(0, target_noise / snr_shift_base))
      }
      stop(
        "SNR calibration produced a non-positive sigma2 after accounting for zeta*HS. ",
        "Requested SNR=", signif(snr_target, 6),
        if (is.finite(snr_max_feasible)) paste0(", max feasible SNR for this zeta is ~", signif(snr_max_feasible, 6)) else "",
        if (is.finite(zeta_max_feasible)) paste0(", max feasible |zeta| for this SNR is ~", signif(zeta_max_feasible, 6)) else "",
        ". Try lowering zeta or SNR, or disable X_het."
      )
    }
    snr_theoretical <- snr_signal / (snr_signal + sigma2 * snr_tauB + snr_shift)
  }

  eps=rnorm(n=n, sd=sqrt(sigma2))
  if(X_het) eps=eps+eps_shift

  if(model=='SAR') Y=as.numeric(iW%*%(xb+eps)) else  if(model=='SEM') Y=xb+as.numeric(iW%*%eps) else  if(model=='SARAR') Y=as.numeric(iW%*%(xb+iW2%*%eps)) else  if(model=='OLS') Y=xb+eps
  Wy=as.numeric(W%*%Y)
  WX<-W%*%X_const[,2:ncol(X_const)]
  WWX<-W%*%WX
  WWWX<-W%*%WWX
  Z<-as.matrix(cbind(X_const,WX,WWX,WWWX))
  PzWy=fitted(lm.fit(Z,Wy))

  mydata=data.frame(cbind(Y,X_const,OX,Wy,PzWy,XB,HS,coords,eps))
  mydata$YS=Y-rho*Wy
  colnames(mydata)=c('Y',paste0('X',0:7),'Wy','PzWy','f0','f1','f2','f3','HS','x','y','eps','YS')
  return(list(data=mydata,W=W,W2=W2,coords=coords,call=mycall,sigma2=sigma2,snr=list(target=snr_target,theoretical=snr_theoretical,signal=snr_signal,tauB=snr_tauB,method=snr_method_used)))
}
