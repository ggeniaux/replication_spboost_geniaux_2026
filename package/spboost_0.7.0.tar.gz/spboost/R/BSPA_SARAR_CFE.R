#' BSPA_SARAR_CFE
#' CFE-style alternating estimator for SARAR models with a gamboost core.
#' @usage BSPA_SARAR_CFE(formula,data,W,W2=NULL,control=boost_control(),
#'                       iter_max=6L,tol_iter=1e-4,
#'                       damping=0.5,
#'                       fallback=c('auto','none'),
#'                       rho_bounds=c(-0.99,0.99),
#'                       lambda_bounds=c(-0.99,0.99),
#'                       lambda_switch=0.80,
#'                       tol=1e-10,verbose=0,
#'                       debug=FALSE,debug_fit_each_iter=FALSE,debug_print=TRUE)
#' @param formula a gamboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial lag on Y.
#' @param W2 a row-standardized spatial weight matrix for spatial lag on errors. If `NULL`, `W` is used.
#' @param control boost_control() see mboost help.
#' @param iter_max maximum number of alternating CFE updates.
#' @param tol_iter stopping tolerance on successive \eqn{(\rho,\lambda)} updates.
#' @param damping damping factor applied to alternating updates.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses ratio/projection approximations, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip \eqn{\rho}.
#' @param lambda_bounds lower and upper bounds used to clip \eqn{\lambda}.
#' @param lambda_switch threshold used by the robust lambda update rule.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @param verbose verbosity level (0/1).
#' @param debug logical; if TRUE, stores per-iteration diagnostics in \code{$trace_iter}.
#' @param debug_fit_each_iter logical; if TRUE, runs an auxiliary SARAR fit-at-current-(rho,lambda)
#' each iteration to report RMSE on Y scale (costly).
#' @param debug_print logical; if TRUE and \code{debug=TRUE}, prints one-line diagnostics each iteration.
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with \eqn{\rho}, \eqn{\lambda}, RMSE and alternating-fit metadata.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.2, lambda = 0.2, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SARAR", nonlin = TRUE, myseed = 16
#' )
#' fit <- BSPA_SARAR_CFE(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W, W2 = sim$W2,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   iter_max = 2
#' )
#' c(rho = fit$rho, lambda = fit$lambda)
#' summary(fit)
#' @export
BSPA_SARAR_CFE <- function(formula,data,W,W2=NULL,control=boost_control(),
                           iter_max=6L,tol_iter=1e-4,
                           damping=0.5,
                           fallback=c('auto','none'),
                           rho_bounds=c(-0.99,0.99),
                           lambda_bounds=c(-0.99,0.99),
                           lambda_switch=0.80,
                           tol=1e-10,verbose=0,
                           debug=FALSE,debug_fit_each_iter=FALSE,debug_print=TRUE){
  fallback <- match.arg(fallback)
  ptm1 <- proc.time()
  debug <- isTRUE(debug)
  debug_fit_each_iter <- isTRUE(debug_fit_each_iter)
  debug_print <- isTRUE(debug_print)

  if (is.null(W)) stop("BSPA_SARAR_CFE requires W.")
  if (is.null(W2)) W2 <- W
  n <- nrow(data)
  if (nrow(W) != n || ncol(W) != n || nrow(W2) != n || ncol(W2) != n) {
    stop("W and W2 must be square matrices with dimensions matching nrow(data).")
  }
  if (!is.finite(iter_max) || as.integer(iter_max) < 1L) iter_max <- 6L
  iter_max <- as.integer(iter_max)
  if (!is.finite(tol_iter) || tol_iter <= 0) tol_iter <- 1e-4

  # Helper to replace formula response while keeping RHS and environment.
  set_response <- function(fml, resp_name) {
    rhs <- tryCatch(deparse1(fml[[3]], collapse = " "), error = function(e) paste(deparse(fml[[3]]), collapse = " "))
    as.formula(paste0(resp_name, " ~ ", rhs), env = environment(fml))
  }

  # Sanitize boosting control once.
  control <- spb_make_boost_control(control)

  LU_ldet <- function(coef, Wm) {
    LU <- lu(Matrix::Diagonal(nrow(Wm)) - coef * Wm)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    sum(log(dU))
  }

  fit_transformed_gaussian <- function(rho, lambda) {
    y_star <- as.numeric(Y - rho * WY - lambda * W2Y + (rho * lambda) * W2WY)
    data_star <- data
    data_star$.Y_star <- y_star
    f_star <- set_response(formula, ".Y_star")
    fit_star <- gamboost(f_star, data = data_star, control = control)
    fitted_star <- as.numeric(fitted(fit_star))
    residuals_star <- as.numeric(y_star - fitted_star)
    list(
      data_star = data_star,
      formula_star = f_star,
      fit = fit_star,
      y_star = y_star,
      fitted_star = fitted_star,
      residuals_star = residuals_star,
      SSE = sum(residuals_star^2)
    )
  }

  objective_rho_given_lambda <- function(rho, lambda_fixed) {
    fit_obj <- fit_transformed_gaussian(rho = rho, lambda = lambda_fixed)
    s2 <- fit_obj$SSE / n
    if (!is.finite(s2) || s2 <= 0) return(Inf)
    -(LU_ldet(rho, W) - (n / 2) * log(s2))
  }

  Y <- as.numeric(get_all_vars(formula, data)[, 1])
  WY <- as.numeric(W %*% Y)
  W2Y <- as.numeric(W2 %*% Y)
  W2WY <- as.numeric(W2 %*% WY)

  rho <- 0
  lambda <- 0
  conv <- FALSE
  iter_log <- vector("list", iter_max)
  if (debug) {
    nnz_w <- Matrix::rowSums(W != 0)
    nnz_w2 <- Matrix::rowSums(W2 != 0)
    matrix_stats <- list(
      n = n,
      nnz_w_min = min(nnz_w), nnz_w_q25 = as.numeric(stats::quantile(nnz_w, 0.25)),
      nnz_w_med = stats::median(nnz_w), nnz_w_mean = mean(nnz_w), nnz_w_q75 = as.numeric(stats::quantile(nnz_w, 0.75)), nnz_w_max = max(nnz_w),
      nnz_w2_min = min(nnz_w2), nnz_w2_q25 = as.numeric(stats::quantile(nnz_w2, 0.25)),
      nnz_w2_med = stats::median(nnz_w2), nnz_w2_mean = mean(nnz_w2), nnz_w2_q75 = as.numeric(stats::quantile(nnz_w2, 0.75)), nnz_w2_max = max(nnz_w2)
    )
  } else {
    matrix_stats <- NULL
  }

  for (it in seq_len(iter_max)) {
    rho_old <- rho
    lambda_old <- lambda

    # Step A: rho update on the correctly transformed response
    # (I-lambda W2)(I-rho W)Y, avoiding the invalid commutation shortcut.
    opt_rho <- optimize(
      f = objective_rho_given_lambda,
      interval = rho_bounds,
      lambda_fixed = lambda_old
    )
    rho <- as.numeric(opt_rho$minimum)
    if (!is.finite(rho)) {
      err <- "BSPA_SARAR_CFE failed: non-finite rho update."
      class(err) <- "error"
      return(err)
    }
    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    # Amortissement pour eviter les oscillations de periode 2.
    rho <- (1 - damping) * rho_old + damping * rho

    # Step B: lambda update from rho-filtered response using SEM CFE_BRUT on W2.
    # max_iter=1L : l'alternance externe gere la convergence sur (rho,lambda),
    # les iterations internes de BSPA_SEM_CFE_BRUT sont redondantes et
    # sources d'instabilite dans ce contexte.
    data_lam <- data
    data_lam$.Y_lam <- as.numeric(Y - rho * WY)
    f_lam <- set_response(formula, ".Y_lam")
    fit_lam <- BSPA_SEM_CFE_BRUT(
      formula      = f_lam,
      data         = data_lam,
      W            = W2,
      control      = control,
      rho_bounds   = lambda_bounds,
      tol          = tol,
      max_iter     = 1L,
      lambda_switch = lambda_switch,
      verbose      = 0
    )
    if (inherits(fit_lam, "error")) {
      if (identical(fallback, "none")) return(fit_lam)
      lambda <- lambda_old
      lam_method <- "fallback_keep_previous"
    } else {
      lambda <- as.numeric(fit_lam$rho)
      if (!is.finite(lambda)) {
        if (identical(fallback, "none")) {
          err <- "BSPA_SARAR_CFE failed: non-finite lambda update."
          class(err) <- "error"
          return(err)
        }
        lambda <- lambda_old
        lam_method <- "fallback_keep_previous"
      } else {
        lambda <- max(min(lambda, lambda_bounds[2]), lambda_bounds[1])
        # Amortissement pour eviter les oscillations de periode 2.
        lambda <- (1 - damping) * lambda_old + damping * lambda
        lam_method <- if (!is.null(fit_lam$rho_method)) as.character(fit_lam$rho_method)[1] else "sem_cfe_brut"
      }
    }

    d_rho <- abs(rho - rho_old)
    d_lam <- abs(lambda - lambda_old)
    rmse_from_fit_safe <- function(fit_obj, y_ref = NULL) {
      if (inherits(fit_obj, "error") || is.null(fit_obj)) return(NA_real_)
      # Prefer stored residuals slot when available (works for custom mboost families).
      rr_slot <- suppressWarnings(try(as.numeric(fit_obj$residuals), silent = TRUE))
      if (!inherits(rr_slot, "try-error") && length(rr_slot) > 0L && any(is.finite(rr_slot))) {
        return(sqrt(mean(rr_slot^2, na.rm = TRUE)))
      }
      # Try residuals() first (works for Gaussian mboost families),
      # then fallback to y - fitted for custom families.
      rr <- suppressWarnings(try(as.numeric(residuals(fit_obj)), silent = TRUE))
      if (!inherits(rr, "try-error") && length(rr) == length(y_ref) && any(is.finite(rr))) {
        return(sqrt(mean(rr^2, na.rm = TRUE)))
      }
      if (is.null(y_ref)) {
        y_ref <- suppressWarnings(try(as.numeric(fit_obj$Y), silent = TRUE))
        if (inherits(y_ref, "try-error") || length(y_ref) == 0L || !any(is.finite(y_ref))) {
          return(NA_real_)
        }
      }
      ff <- suppressWarnings(try(as.numeric(fitted(fit_obj)), silent = TRUE))
      if (inherits(ff, "try-error") || length(ff) != length(y_ref) || !any(is.finite(ff))) {
        return(NA_real_)
      }
      ee <- as.numeric(y_ref - ff)
      sqrt(mean(ee^2, na.rm = TRUE))
    }

    fit_rho_stage <- fit_transformed_gaussian(rho = rho, lambda = lambda_old)
    rmse_rho_stage <- sqrt(mean(fit_rho_stage$residuals_star^2, na.rm = TRUE))
    rmse_lam_stage <- NA_real_
    if (!inherits(fit_lam, "error")) {
      # Explicit SEM-stage criterion at current lambda:
      # || (I - lambda W2) (Y_lam - fhat_lam) ||_2 / sqrt(n)
      y_lam <- as.numeric(data_lam$.Y_lam)
      f_lam_hat <- suppressWarnings(try(as.numeric(fit_lam$fittedYS), silent = TRUE))
      if (inherits(f_lam_hat, "try-error") || length(f_lam_hat) != length(y_lam) || !any(is.finite(f_lam_hat))) {
        f_lam_hat <- suppressWarnings(try(as.numeric(fitted(fit_lam)), silent = TRUE))
      }
      if (!inherits(f_lam_hat, "try-error") && length(f_lam_hat) == length(y_lam) && any(is.finite(f_lam_hat))) {
        I_lW2_stage <- Matrix::Diagonal(n) - lambda * W2
        e_lam_stage <- as.numeric(I_lW2_stage %*% (y_lam - f_lam_hat))
        rmse_lam_stage <- sqrt(mean(e_lam_stage^2, na.rm = TRUE))
      } else {
        rmse_lam_stage <- rmse_from_fit_safe(fit_lam, y_ref = y_lam)
      }
    }
    rmse_pred_it <- NA_real_
    rmse_filtered_it <- NA_real_
    cor_pred_it <- NA_real_
    mean_pred_it <- NA_real_
    mean_target_it <- NA_real_
    mean_sf_it <- NA_real_
    sd_sf_it <- NA_real_

    if (debug) {
      I_rhoW_it <- Matrix::Diagonal(n) - rho * W
      I_lW2_it <- Matrix::Diagonal(n) - lambda * W2
      sf_target_it <- as.numeric(I_lW2_it %*% (I_rhoW_it %*% Y))
      mean_sf_it <- mean(sf_target_it)
      sd_sf_it <- stats::sd(sf_target_it)

      if (debug_fit_each_iter) {
        dbg_it <- fit_transformed_gaussian(rho = rho, lambda = lambda)
        fit_sf_it <- dbg_it$fitted_star
        yhat_it <- as.numeric(
          spb_solve_nested_spatial_rhs(
            W, rho, W2, lambda, fit_sf_it,
            direct_max_n = 25000L,
            tol = 1e-6,
            max_order = 50L
          )
        )
        err_pred_it <- as.numeric(Y - yhat_it)
        err_sf_it <- as.numeric(I_lW2_it %*% (I_rhoW_it %*% Y) - fit_sf_it)
        rmse_pred_it <- sqrt(mean(err_pred_it^2))
        rmse_filtered_it <- sqrt(mean(err_sf_it^2))
        cor_pred_it <- suppressWarnings(stats::cor(yhat_it, Y))
        mean_pred_it <- mean(yhat_it)
        mean_target_it <- mean(Y)
      }
    }

    iter_log[[it]] <- list(
      iter = it,
      rho = rho,
      lambda = lambda,
      delta_rho = d_rho,
      delta_lambda = d_lam,
      rho_method = "conditional_transformed_opt",
      lambda_method = lam_method,
      rmse_rho_stage = rmse_rho_stage,
      rmse_lambda_stage = rmse_lam_stage,
      rmse_pred_debug = rmse_pred_it,
      rmse_filtered_debug = rmse_filtered_it,
      cor_pred_y_debug = cor_pred_it,
      mean_pred_debug = mean_pred_it,
      mean_y_debug = mean_target_it,
      mean_sf_target_debug = mean_sf_it,
      sd_sf_target_debug = sd_sf_it
    )

    if (isTRUE(verbose > 0)) {
      cat(
        "BSPA_SARAR_CFE iter", it,
        "| rho=", format(rho, digits = 6),
        "| lambda=", format(lambda, digits = 6),
        "| d_rho=", format(d_rho, digits = 4),
        "| d_lambda=", format(d_lam, digits = 4), "\n"
      )
    }
    if (debug && debug_print) {
      cat(
        "[DEBUG] iter=", it,
        " | rho=", format(rho, digits = 6),
        " | lambda=", format(lambda, digits = 6),
        " | d_rho=", format(d_rho, digits = 4),
        " | d_lam=", format(d_lam, digits = 4),
        " | rmse_rho_stage=", format(rmse_rho_stage, digits = 6),
        " | rmse_lambda_stage=", format(rmse_lam_stage, digits = 6),
        " | mean_sf=", format(mean_sf_it, digits = 6),
        " | sd_sf=", format(sd_sf_it, digits = 6),
        " | rmse_pred=", format(rmse_pred_it, digits = 6),
        " | cor(yhat,y)=", format(cor_pred_it, digits = 6),
        " | mean(yhat)=", format(mean_pred_it, digits = 6),
        " | mean(y)=", format(mean_target_it, digits = 6), "\n",
        sep = ""
      )
    }

    if (max(d_rho, d_lam) <= tol_iter) {
      conv <- TRUE
      iter_log <- iter_log[seq_len(it)]
      break
    }
  }
  if (!conv && length(iter_log) == iter_max) {
    iter_log <- iter_log[seq_len(iter_max)]
  }

  # Final fit on transformed Gaussian response:
  final_fit <- fit_transformed_gaussian(rho = rho, lambda = lambda)
  model <- final_fit$fit
  fitted_sf <- final_fit$fitted_star
  I_rhoW <- Matrix::Diagonal(n) - rho * W
  I_lW2 <- Matrix::Diagonal(n) - lambda * W2
  Y_pred <- as.numeric(
    spb_solve_nested_spatial_rhs(
      W, rho, W2, lambda, fitted_sf,
      direct_max_n = 25000L,
      tol = 1e-6,
      max_order = 50L
    )
  )

  res_pred <- as.numeric(Y - Y_pred)
  res_filtered <- as.numeric(final_fit$residuals_star)

  model$residuals <- res_pred
  model$residuals_filtered <- res_filtered
  model$residuals_pred <- res_pred
  model$fittedYS <- fitted_sf
  model$fitted <- Y_pred
  model$Y <- Y
  model$rho <- as.numeric(rho)
  model$lambda <- as.numeric(lambda)
  model$rmse <- sqrt(mean(res_pred^2))
  model$elapsed <- as.numeric((proc.time() - ptm1)[3])
  model$formula <- formula
  model$cfe_iter <- iter_log
  model$trace_iter <- do.call(rbind, lapply(iter_log, function(x) as.data.frame(x, stringsAsFactors = FALSE)))
  model$debug_matrix_stats <- matrix_stats
  model$debug <- debug
  model$debug_fit_each_iter <- debug_fit_each_iter
  model$converged <- isTRUE(conv)
  model$tol_iter <- tol_iter
  model$iter_max <- iter_max
  model$rho_method <- "conditional_transformed_opt + sem_cfe"
  class(model) <- c("spboost", "BSPA_SARAR_CFE", class(model))
  model
}
