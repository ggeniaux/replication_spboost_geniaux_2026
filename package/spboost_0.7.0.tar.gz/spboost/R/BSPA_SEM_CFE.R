# Internal filtered SEM CFE backend used when the BRUT stage estimates a high rho.
spb_sem_cfe_filtered_legacy <- function(formula,data,W,control,doMC,fallback,rho_bounds,tol,
                                        cfe_aux_cv,cfe_cv_nfold,cfe_cv_ncore,cfe_cv_seed){
  ptm1 <- proc.time()
  YX <- get_all_vars(formula, data)
  Y <- as.numeric(YX[, 1])
  X <- as.matrix(YX[, -1, drop = FALSE])
  namesX <- colnames(X)
  data$Y <- Y
  data$WY <- as.numeric(W %*% Y)
  WX <- data.frame(as.matrix(W %*% X))
  colnames(WX) <- paste0("WX.", namesX)
  data <- cbind(data, WX)
  f0 <- f1 <- formula
  td_form2 <- formula[3]
  for (i in namesX) {
    td_form2 <- gsub(i, paste0("WX.", i), td_form2)
  }
  td_form0 <- paste0("Y~.+", as.name(td_form2))
  td_form1 <- paste0("WY~.+", as.name(td_form2))
  f0 <- update.formula(f0, td_form0)
  f1 <- update.formula(f1, td_form1)
  formulas <- list(f0, f1)

  mstop_aux_y <- NA_integer_
  mstop_aux_wy <- NA_integer_
  cv_rmse_aux_y <- NA_real_
  cv_rmse_aux_wy <- NA_real_

  fit_aux_sem_cv <- function(ff, seed_shift = 0L) {
    mstop_max <- suppressWarnings(as.integer(control$mstop[[1]]))
    if (!is.finite(mstop_max) || mstop_max < 1L) mstop_max <- 150L
    control_max <- control
    control_max$mstop <- as.integer(mstop_max)
    fit_max <- gamboost(ff, data = data, control = control_max)
    if (mstop_max <= 1L || cfe_cv_nfold < 2L) {
      return(list(model = fit_max, best_mstop = as.integer(mboost::mstop(fit_max)), cv_rmse = NA_real_))
    }
    if (is.finite(cfe_cv_seed)) set.seed(as.integer(cfe_cv_seed + seed_shift))
    folds <- mboost::cv(model.weights(fit_max), type = "kfold", B = cfe_cv_nfold)
    if (.Platform$OS.type != "windows" && cfe_cv_ncore > 1L) {
      cv_obj <- mboost::cvrisk(
        fit_max, folds = folds, grid = seq_len(mstop_max),
        papply = parallel::mclapply, mc.cores = cfe_cv_ncore, mc.preschedule = FALSE
      )
    } else {
      cv_obj <- mboost::cvrisk(
        fit_max, folds = folds, grid = seq_len(mstop_max),
        papply = lapply
      )
    }
    best_mstop <- suppressWarnings(as.integer(mboost::mstop(cv_obj)))
    if (!is.finite(best_mstop) || best_mstop < 1L) best_mstop <- as.integer(mstop_max)
    fit_use <- fit_max
    suppressWarnings(try(mboost::mstop(fit_use) <- best_mstop, silent = TRUE))
    cv_rmse <- NA_real_
    cv_mat <- tryCatch(unclass(cv_obj), error = function(e) NULL)
    if (is.matrix(cv_mat) && ncol(cv_mat) >= best_mstop) {
      cv_mse <- mean(cv_mat[, best_mstop], na.rm = TRUE)
      if (is.finite(cv_mse) && cv_mse >= 0) cv_rmse <- sqrt(cv_mse)
    }
    list(model = fit_use, best_mstop = best_mstop, cv_rmse = cv_rmse)
  }

  if (cfe_aux_cv) {
    if (isTRUE(doMC)) {
      warning("BSPA_SEM_CFE: `doMC=TRUE` ignored when `cfe_aux_cv=TRUE`; running auxiliary CV fits sequentially.")
    }
    fit0 <- fit_aux_sem_cv(f0, seed_shift = 0L)
    fit1 <- fit_aux_sem_cv(f1, seed_shift = 1L)
    m0 <- fit0$model
    m1 <- fit1$model
    mstop_aux_y <- fit0$best_mstop
    mstop_aux_wy <- fit1$best_mstop
    cv_rmse_aux_y <- fit0$cv_rmse
    cv_rmse_aux_wy <- fit1$cv_rmse
  } else if (doMC) {
    registerDoParallel(cores = 2)
    MM <- foreach(myrep = 1:2, .combine = "cbind") %dopar% {
      ff <- formulas[[myrep]]
      M <- gamboost(ff, data = data)
      return(list(M))
    }
    m0 <- MM[[1]]
    m1 <- MM[[2]]
  } else {
    m0 <- gamboost(f0, data = data, control = control)
    m1 <- gamboost(f1, data = data, control = control)
  }

  e0 <- residuals(m0)
  e1 <- residuals(m1)
  a <- as.numeric(t(e1) %*% W %*% e1)
  b <- as.numeric(t(e0) %*% W %*% e1 + t(e1) %*% W %*% e0)
  cc <- as.numeric(t(e0) %*% W %*% e0)
  D <- b^2 - 4 * a * cc
  n <- nrow(data)
  rho <- NA_real_
  rho_method <- NA_character_
  rho_exact_root <- NA_integer_

  if (D < 0 && abs(D) <= tol) D <- 0
  if (abs(a) > tol && D >= 0) {
    sqrtD <- sqrt(D)
    rho_candidates <- c(
      as.numeric((b - sqrtD) / (2 * a)),
      as.numeric((b + sqrtD) / (2 * a))
    )
    ok <- is.finite(rho_candidates)
    if (any(ok)) {
      rho_candidates <- rho_candidates[ok]
      root_idx <- which(ok)
      in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
      if (any(in_bounds)) {
        rho_eval <- rho_candidates[in_bounds]
        root_eval <- root_idx[in_bounds]
      } else {
        rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
        root_eval <- root_idx
      }
      score <- vapply(
        rho_eval,
        function(rh) sum((e0 - rh * e1)^2),
        numeric(1)
      )
      best <- which.min(score)
      rho <- as.numeric(rho_eval[best])
      rho_exact_root <- as.integer(root_eval[best])
      rho_method <- "cfe_exact"
    }
  } else if (fallback == "auto") {
    den_w <- as.numeric(t(e1) %*% W %*% e1)
    num_w <- as.numeric(t(e1) %*% W %*% e0)
    if (abs(den_w) > tol) {
      rho <- num_w / den_w
      rho_method <- "cfe_weighted_projection"
    }
  }

  if (is.na(rho) || !is.finite(rho)) {
    model <- paste0("CFE failed: no admissible SEM lambda (D=", signif(D, 6), ", a=", signif(a, 6), ").")
    class(model) <- "error"
    return(model)
  }

  rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
  cust_loss_sem <- function(I_rhoW){
    Family(
      ngradient = function(y, f, w = 1) as.numeric(I_rhoW %*% (y - f)),
      loss = function(y, f) as.numeric((I_rhoW %*% (y - f))^2),
      name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W"
    )
  }
  I_rhoW <- Diagonal(nrow(W)) - rho * W
  model <- gamboost(formula, data = data, control = control, family = cust_loss_sem(I_rhoW))
  Y_pred <- fitted(model)
  e <- (Y - Y_pred)
  den_var <- (b - 2 * rho * a)
  if (abs(den_var) > tol) {
    model$var_rho <- (t(e0 - rho * e1) %*% (e0 - rho * e1) / n) / den_var
  } else {
    model$var_rho <- NA_real_
  }
  duree <- (proc.time() - ptm1)[3]
  model$residuals <- e
  model$fittedYS <- fitted(model)
  model$fitted <- Y - model$residuals
  model$rmse <- sqrt(mean(model$residuals^2))
  model$rho <- rho
  model$rho_method <- rho_method
  model$rho_exact_root <- rho_exact_root
  model$cfe_aux <- list(
    aux_cv_enabled = cfe_aux_cv,
    aux_cv_nfold = as.integer(cfe_cv_nfold),
    aux_cv_ncore = as.integer(cfe_cv_ncore),
    aux_cv_seed = if (is.finite(cfe_cv_seed)) as.integer(cfe_cv_seed) else NA_integer_,
    mstop_y = mstop_aux_y,
    mstop_wy = mstop_aux_wy,
    cv_rmse_y = cv_rmse_aux_y,
    cv_rmse_wy = cv_rmse_aux_wy
  )
  model$D <- D
  model$elapsed <- duree
  model$Y <- Y
  class(model) <- c("spboost", "BSPA_SEM_CFE", class(model))
  model
}

#' BSPA_SEM_CFE
#' BSPA_SEM_CFE keeps the historical SEM CFE interface while using the same
#' one-shot BRUT/filtered workflow as GAM_SEM_CFE: a non-spatial BRUT CFE
#' estimate is computed first, then the filtered CFE backend is used when the
#' BRUT rho estimate is high.
#' @usage BSPA_SEM_CFE(formula,data,W,control=boost_control(),doMC=TRUE,
#' fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10,
#' cfe_aux_cv=FALSE,cfe_cv_nfold=5L,cfe_cv_ncore=1L,cfe_cv_seed=NULL)
#' @param formula a gamboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param control boost_control() see mboost help.
#' @param doMC boolean for parallelization in the filtered fallback stage.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses projection fallback, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @param cfe_aux_cv logical; if TRUE, tune the two auxiliary CFE regressions by internal CV.
#' @param cfe_cv_nfold number of folds for auxiliary CFE CV.
#' @param cfe_cv_ncore number of workers for auxiliary CFE CV.
#' @param cfe_cv_seed optional seed for auxiliary CFE CV.
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = TRUE, myseed = 13
#' )
#' fit <- BSPA_SEM_CFE(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2)
#' )
#' fit$rho
#' summary(fit)
BSPA_SEM_CFE <- function(formula,data,W,control=boost_control(),doMC=TRUE,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10,
                         cfe_aux_cv=FALSE,cfe_cv_nfold=5L,cfe_cv_ncore=1L,cfe_cv_seed=NULL){
  fallback <- match.arg(fallback)
  lambda_switch <- suppressWarnings(as.numeric(getOption("spboost.sem_cfe.lambda_switch", 0.9))[1])
  if (!is.finite(lambda_switch)) lambda_switch <- 0.9
  lambda_switch <- max(rho_bounds[1], min(rho_bounds[2], lambda_switch))

  cfe_aux_cv <- isTRUE(cfe_aux_cv)
  cfe_cv_nfold <- suppressWarnings(tryCatch(as.integer(cfe_cv_nfold[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_nfold) == 0L || !is.finite(cfe_cv_nfold[1]) || cfe_cv_nfold[1] < 2L) {
    cfe_cv_nfold <- 5L
  } else {
    cfe_cv_nfold <- as.integer(cfe_cv_nfold[1])
  }
  cfe_cv_ncore <- suppressWarnings(tryCatch(as.integer(cfe_cv_ncore[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_ncore) == 0L || !is.finite(cfe_cv_ncore[1]) || cfe_cv_ncore[1] < 1L) {
    cfe_cv_ncore <- 1L
  } else {
    cfe_cv_ncore <- as.integer(cfe_cv_ncore[1])
  }
  cfe_cv_seed <- suppressWarnings(tryCatch(as.integer(cfe_cv_seed[[1]]), error = function(e) NA_integer_))
  if (length(cfe_cv_seed) == 0L || !is.finite(cfe_cv_seed[1])) {
    cfe_cv_seed <- NA_integer_
  } else {
    cfe_cv_seed <- as.integer(cfe_cv_seed[1])
  }

  fit_brut <- function() {
    ptm <- proc.time()
    YX <- get_all_vars(formula, data)
    Y <- as.numeric(YX[, 1])
    n <- length(Y)

    model_ols <- gamboost(formula, data = data, control = control)
    e_brut <- as.numeric(Y - fitted(model_ols))
    We <- as.numeric(W %*% e_brut)
    WWe <- as.numeric(W %*% We)

    a <- sum(We * WWe)
    b <- sum(e_brut * WWe) + sum(We * We)
    cc <- sum(e_brut * We)
    D <- b^2 - 4 * a * cc
    if (D < 0 && abs(D) <= tol) D <- 0

    rho <- NA_real_
    rho_exact_root <- NA_integer_
    rho_method_raw <- NA_character_
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      rho_candidates <- c(
        as.numeric((b - sqrtD) / (2 * a)),
        as.numeric((b + sqrtD) / (2 * a))
      )
      ok <- is.finite(rho_candidates)
      if (any(ok)) {
        rho_candidates <- rho_candidates[ok]
        root_idx <- which(ok)
        in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
        if (any(in_bounds)) {
          rho_eval <- rho_candidates[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(
          rho_eval,
          function(rh) sum((e_brut - rh * We)^2),
          numeric(1)
        )
        best <- which.min(score)
        rho <- as.numeric(rho_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method_raw <- "cfe_brut_residuals"
      }
    }
    if (!is.finite(rho)) {
      den1 <- sum(We^2)
      if (is.finite(den1) && abs(den1) > tol) {
        rho <- cc / den1
        rho_method_raw <- "cfe_brut_projection"
      } else {
        rho <- 0
        rho_method_raw <- "cfe_brut_init_fallback"
      }
    }

    if (identical(fallback, "none") &&
        !(is.character(rho_method_raw) && length(rho_method_raw) == 1L &&
          !is.na(rho_method_raw) &&
          rho_method_raw %in% c("cfe_brut_residuals", "cfe_brut_iter_exact"))) {
      if (is.na(rho_method_raw) || !nzchar(rho_method_raw)) rho_method_raw <- "unknown"
      model <- paste0(
        "CFE failed: no admissible exact SEM lambda in BRUT backend (rho_method=",
        rho_method_raw, ")."
      )
      class(model) <- "error"
      return(model)
    }

    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    cust_loss_sem <- function(I_rhoW) {
      mboost::Family(
        ngradient = function(y, f, w = 1) as.numeric(I_rhoW %*% (y - f)),
        loss = function(y, f) as.numeric((I_rhoW %*% (y - f))^2),
        name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W"
      )
    }
    I_rhoW <- Matrix::Diagonal(nrow(W)) - rho * W
    model <- gamboost(formula, data = data, control = control, family = cust_loss_sem(I_rhoW))
    Y_pred <- fitted(model)
    e <- Y - Y_pred
    den_var <- b - 2 * rho * a
    if (abs(den_var) > tol) {
      model$var_rho <- (sum((e_brut - rho * We)^2) / n) / den_var
    } else {
      model$var_rho <- NA_real_
    }

    rho_method <- if (is.character(rho_method_raw) && length(rho_method_raw) == 1L && !is.na(rho_method_raw)) {
      switch(
        rho_method_raw,
        cfe_brut_residuals = "cfe_exact",
        cfe_brut_iter_exact = "cfe_exact",
        cfe_brut_projection = "cfe_weighted_projection",
        cfe_brut_init_fallback = "cfe_weighted_projection",
        rho_method_raw
      )
    } else {
      rho_method_raw
    }

    model$residuals <- e
    model$fittedYS <- fitted(model)
    model$fitted <- Y - model$residuals
    model$rmse <- sqrt(mean(model$residuals^2))
    model$rho <- rho
    model$rho_method_raw <- rho_method_raw
    model$rho_method <- rho_method
    model$rho_exact_root <- rho_exact_root
    model$D <- D
    model$elapsed <- as.numeric((proc.time() - ptm)[3])
    model$Y <- Y
    class(model) <- c("spboost", "BSPA_SEM_CFE", class(model))
    model
  }

  model_brut <- fit_brut()
  if (inherits(model_brut, "error")) return(model_brut)

  rho_brut <- suppressWarnings(as.numeric(model_brut$rho)[1])
  switched_to_filtered <- is.finite(rho_brut) && (rho_brut > lambda_switch)

  model <- model_brut
  backend_used <- "brut"
  if (switched_to_filtered) {
    model_filtered <- spb_sem_cfe_filtered_legacy(
      formula = formula,
      data = data,
      W = W,
      control = control,
      doMC = doMC,
      fallback = fallback,
      rho_bounds = rho_bounds,
      tol = tol,
      cfe_aux_cv = cfe_aux_cv,
      cfe_cv_nfold = cfe_cv_nfold,
      cfe_cv_ncore = cfe_cv_ncore,
      cfe_cv_seed = cfe_cv_seed
    )
    if (inherits(model_filtered, "error")) {
      if (identical(fallback, "none")) {
        return(model_filtered)
      }
      warning("BSPA_SEM_CFE: filtered switch failed after high BRUT rho; keeping BRUT estimate.")
      backend_used <- "brut_after_filtered_error"
    } else {
      model <- model_filtered
      backend_used <- "filtered"
    }
  }

  if (identical(backend_used, "filtered")) {
    rho_method_raw <- if (!is.null(model$rho_method)) as.character(model$rho_method[[1]]) else NA_character_
    model$rho_method_raw <- rho_method_raw
  } else {
    rho_method_raw <- if (!is.null(model$rho_method_raw)) {
      as.character(model$rho_method_raw[[1]])
    } else if (!is.null(model$rho_method)) {
      as.character(model$rho_method[[1]])
    } else {
      NA_character_
    }
    if (is.character(rho_method_raw) && length(rho_method_raw) == 1L && !is.na(rho_method_raw)) {
      rho_method_compat <- switch(
        rho_method_raw,
        cfe_brut_residuals = "cfe_exact",
        cfe_brut_exact = "cfe_exact",
        cfe_brut_iter_exact = "cfe_exact",
        cfe_filtered_exact = "cfe_exact",
        cfe_brut_projection = "cfe_weighted_projection",
        cfe_brut_init_fallback = "cfe_weighted_projection",
        cfe_filtered_projection = "cfe_weighted_projection",
        rho_method_raw
      )
    } else {
      rho_method_compat <- rho_method_raw
    }
    if (identical(fallback, "none") &&
        !(is.character(rho_method_raw) && length(rho_method_raw) == 1L &&
          !is.na(rho_method_raw) &&
          rho_method_raw %in% c("cfe_brut_residuals", "cfe_brut_iter_exact", "cfe_brut_exact", "cfe_filtered_exact"))) {
      if (is.na(rho_method_raw) || !nzchar(rho_method_raw)) rho_method_raw <- "unknown"
      err <- paste0(
        "CFE failed: no admissible exact SEM lambda in BRUT backend (rho_method=",
        rho_method_raw, ")."
      )
      class(err) <- "error"
      return(err)
    }
    model$rho_method_raw <- rho_method_raw
    model$rho_method <- rho_method_compat
  }

  if (is.null(model$D)) model$D <- NA_real_
  if (is.null(model$cfe_aux)) {
    model$cfe_aux <- list(
      aux_cv_enabled = cfe_aux_cv,
      aux_cv_nfold = as.integer(cfe_cv_nfold),
      aux_cv_ncore = as.integer(cfe_cv_ncore),
      aux_cv_seed = if (is.finite(cfe_cv_seed)) as.integer(cfe_cv_seed) else NA_integer_,
      mstop_y = NA_integer_,
      mstop_wy = NA_integer_,
      cv_rmse_y = NA_real_,
      cv_rmse_wy = NA_real_
    )
  }
  model$cfe_switch <- list(
    threshold = lambda_switch,
    rho_brut = if (is.finite(rho_brut)) rho_brut else NA_real_,
    switched_to_filtered = identical(backend_used, "filtered"),
    backend_used = backend_used
  )
  model$cfe_backend <- if (identical(backend_used, "filtered")) {
    "BSPA_SEM_CFE_filtered"
  } else {
    "BSPA_SEM_CFE_BRUT_oneshot"
  }

  class(model) <- unique(c(setdiff(class(model), "BSPA_SEM_CFE_BRUT"), "spboost", "BSPA_SEM_CFE"))
  model
}
