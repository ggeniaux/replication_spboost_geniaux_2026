#' @keywords internal
#' @noRd
LM_SARW_ML<-function(formula,data,coord,method='gamboost_ML',WW=NULL,control=boost_control(mstop=1000,nu=0.3),verbose=0){
  if(is.null(WW)) WW=build_Wk(coord)
  model<-list()
  ## all SAR
  for(m in 1:length(WW)){
    model[[m]]<-LM_SAR_ML(formula,data,WW[m])
  }
  myorder=order(sapply(1:m,function(x) -model[[x]]$logl))
  ## iterate over W candidate
  wl<-WW[myorder[1]]
  modelp<-model[[myorder[1]]]
  rho_init=model[[myorder[1]]]$rho
  if(verbose>0) cat('\n Starting with:',names(wl), 'logl =',model[[myorder[1]]]$logl,' AIC=',model[[myorder[1]]]$AIC,' rho = ',rho_init,'\n')
  z=1
  while(z<=length( myorder[-1])){
    #for(m in myorder[-1]){
    m=myorder[-1][z]
    z=z+1
    wl<-c(wl,WW[m])
    previous_model<-modelp
    if(verbose>0) cat('\n Introducing :',names(WW[m]), '... ')
    modelp<-LM_SAR_ML(formula,data,W=wl,RHO=rho_init)
    np=length(wl)
    myseq=1:np
    if(modelp$logl>previous_model$logl) continue=TRUE else continue=FALSE
    perf<-modelp$AIC
    ## sequential optim
    tolerance=0.001
    while(continue){
      for(j in 1:np){
        myseq=c(myseq[-1],myseq[1])
        wls=wl[myseq]
        modelp<-LM_SAR_ML(formula,data, W=wls,RHO=modelp$rho[-1])
      }
      if(modelp$AIC<perf-tolerance) continue=TRUE else {
        continue=FALSE
      }
      perf<-modelp$AIC
      if(verbose>0) cat('logl=',modelp$logl,' AIC=',modelp$AIC,' ... ')
    }

    if(modelp$AIC<previous_model$AIC) continue=TRUE else {
      wl<-wl[-length(wl)]
      modelp=previous_model
    }
    rho_init=modelp$rho
    if(verbose>0) cat('\n RHO =',names(rho_init),'\n.      ' ,rho_init)
  }
  class(modelp)<-c('spboost','LM_SARW_ML',class(modelp))
  return(modelp)
}
