#' @keywords internal
#' @noRd
GAM_SAR_FIVA=function(formula,data,W,nlz=FALSE,ncores=3,engine=c('auto','gam','bam'),bam_threshold=12000L,bam_discrete=TRUE,bam_nthreads=NULL){
  engine <- match.arg(engine)
  n=nrow(data)
  bam_threshold <- as.integer(bam_threshold[[1]])
  if (!is.finite(bam_threshold) || bam_threshold < 1L) bam_threshold <- 12000L
  use_bam <- switch(engine, auto = n >= bam_threshold, gam = FALSE, bam = TRUE)
  bam_threads <- spb_bam_threads(bam_nthreads = bam_nthreads, ncores = ncores, max_threads = 3L)
  fit_backend <- function(ff, data, nthreads) {
    if (use_bam) {
      mgcv::bam(ff, data = data, discrete = isTRUE(bam_discrete), nthreads = nthreads)
    } else {
      mgcv::gam(ff, data = data)
    }
  }

  gp <- mgcv::interpret.gam(formula)
  namesX<-gp$pred.names
  Y=data[,gp$response]
  X=as.matrix(cbind(rep(1,n),data[,namesX]))
  Wy=as.numeric(W%*%Y)
  if(nlz) WX<-W%*%X[,-1] else WX<-W%*%cbind(X[,-1],X[,-1]^2,X[,-1]^3)
  WWX<-W%*%WX
  WWWX<-W%*%WWX
  Z<-as.matrix(cbind(X,WX,WWX,WWWX))
  colnames(Z)=paste0('Z',1:ncol(Z))
  mydata=data.frame(cbind(Y,Z,Wy))
  if(nlz){
  myformulaZ=as.formula(paste0('Wy~s(',paste0(colnames(Z)[-c(1,ncol(Z))],collapse=')+s('),')+s(',colnames(Z)[ncol(Z)],')'))
  mm<-fit_backend(myformulaZ, data=mydata, nthreads=bam_threads)
  } else {
    myformulaZ=as.formula(paste0('Wy~',paste0(colnames(Z)[-1],collapse='+')))
  mm<-glm(myformulaZ,data=mydata)
  }
  data$resU=mm$residuals
  data$Wy=Wy
  #data$PzWy=fitted(mm)
  myformulaWy<-update(formula,'.~.+Wy+resU')
  gamC=fit_backend(myformulaWy, data=data, nthreads=bam_threads)
  gamC$resU=data$resU
  XB_fitted<-predict(gamC, type = "terms")
  gamC$rho<-coefficients(gamC)['Wy']
  gamC$fitted <- as.numeric(fitted(gamC))
  gamC$fittedYS <- as.numeric(gamC$fitted - gamC$rho * Wy)
  gamC$rmse=sqrt(mean((gamC$residuals+XB_fitted[,'resU'])^2))
  gamC$Y<-Y
  gamC$formula<-formula
  gamC$engine=if (use_bam) "bam" else "gam"
  gamC$bam_nthreads=if (use_bam) bam_threads else NA_integer_
  class(gamC)<-c('spboost','GAM_SAR_FIVA',class(gamC)[-3])
  gamC
}
#f1=as.formula('Y~s(X1,bs="cr")+s(X2,bs="cr")+s(X3,bs="cr")')
#model2=gam_sarIV (formula=f1,data=mydata_simu$data,W=mydata_simu$W)
#sum((model2$residuals+model2$coefficients['resU']*model2$resU)^2)
#summary(model2)
#plot(model2)
