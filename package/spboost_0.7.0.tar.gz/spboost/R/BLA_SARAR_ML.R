
#' BLA_SARAR_ML
#' BLA_SARAR_ML allows the estimation of SARAR models using the gradient boosting
#' method with linear base learner for estimating the coefficients Beta while
#' the estimation of the spatial parameter is based on a concentrated likelihood
#' function. This function makes it possible to estimate a SARAR model while
#' automatically selecting the explanatory variables.
#' @usage BLA_SARAR_ML(formula,data,W,W2,center=TRUE,mstop0=NULL,mstop_init=500,nu=0.3,ncores=2,
#' rho0=c(0,0.6),lambda0=c(0,0.6),verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation of endogenous.
#' @param W2 a row-standardized spatial weight matrix for Spatial Aurocorrelation of errors.
#' @param mstop0 an integer giving the number of boosting iterations
#' @param mstop_init an integer giving the number of initial boosting iterations. If mstop = 0, the offset model is returned. Used only if mstop0 is NULL.
#' @param nu a double (between 0 and 1) defining the step size or shrinkage parameter.
#' @param rho0 a set of rho values (between -1 and 1) for estimating initial mstop0. Used only if mstop0 is NULL. Default c(0,0.6).
#' @param lambda0 a set of lambda values (between -1 and 1) for estimating initial mstop0. Used only if mstop0 is NULL. Default c(0,0.6).
#' @param ncores number of cores for parallel computing of cross validation of mstop, default ncores=7
#' @param center logical indicating of the predictor variables are centered before fitting, Default TRUE.
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.2, lambda = 0.2, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SARAR", nonlin = FALSE, myseed = 10
#' )
#' fit <- BLA_SARAR_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W, W2 = sim$W2,
#'   mstop0 = 5, nu = 0.2
#' )
#' c(rho = fit$rho, lambda = fit$lambda)
#' summary(fit)
BLA_SARAR_ML=function(formula,data,W,W2,center=TRUE,mstop0=NULL,mstop_init=500,nu=0.3,ncores=2,rho0=c(0,0.6),lambda0=c(0,0.6),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  ## LU_ldet adapated from spatialreg package
  LU_ldet<-function (coef, W)
  {
    I=Diagonal(nrow(W))
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## sacsar.f adapated from spatialreg package
  sacsar.f<-function (rho,lambda,W,W2,SSE)
  {
    s2 <- SSE/n
    ldet1 <- LU_ldet(rho,W)
    ldet2 <- LU_ldet(lambda,W2)
    ret <- (ldet1 + ldet2 - ((n/2) * log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    -ret
  }
  ## custom family (loss & gradient) adapted for SAR model
  cust_loss_sarar = function(I_rhoW,I_lambdaW){
    Family(ngradient = function(y, f,w=1) as.numeric(I_lambdaW%*%(I_rhoW%*%y - f)),
           loss = function(y, f) as.numeric((I_lambdaW%*%(I_rhoW%*%y - f))^2),
           name = "SARA with I_rhoW=Diagonal(nrow(W))-rho*W & I_lambdaW=Diagonal(nrow(W2))-lambda*W2")
  }
  ## custom loglig using glmboost instead of lm for finding Beta coefficients
loglig.glmboost_SARAR<-function(coef,formula,data,mstop=150,nu=0.3,W,W2,center=TRUE){
    rho=coef[1]
    lambda=coef[2]
    n=nrow(data)
    I=Diagonal(n)
    Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
    sum_lw=0
    verbose=0
    I_rhoW=Diagonal(nrow(W))-rho*W
    I_lambdaW=Diagonal(nrow(W2))-lambda*W2
    glmboostC=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop, nu=nu),family =cust_loss_sarar(I_rhoW,I_lambdaW))
    fit_YS=as.numeric(fitted(glmboostC))
    e=Y-rho*W%*%Y-fit_YS
    SSE=sum(((I-lambda*W2)%*%(e))^2)
    sacsar.f(rho,lambda,W,W2,SSE)
  }

  ## step 1: if mstop0 is not provided by the user, finding an appropriate mstop0 for a given set of rho using cross-validation
min_cv= NULL
search_mstop=is.null(mstop0)
  if(search_mstop){
    if(verbose>0) cat('Approximation mstop0 using cvrisk (25 kfolds) with rho=',rho0,' and lamda=',lambda0,' \n')
    mstop0=c()
    #### utiliser les 4 configs mpars=matrix(c(-0.6,0,  0.6,0.6, 0.6,0,0.6,-0.6),ncol=2)

    for(lambda_temp in lambda0){
      for(rho_temp in rho0){
        I_rhoW=Diagonal(nrow(W))-rho_temp*W
        I_lambdaW=Diagonal(nrow(W2))-lambda_temp*W2
        glmboost_sarar=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sarar(I_rhoW,I_lambdaW))
      cv5f <- cv(model.weights(glmboost_sarar), type = "kfold",B=5)
      cvm <- cvrisk(glmboost_sarar, folds = cv5f, mc.cores = ncores)
      mstop0=c(mstop0,mstop(cvm))
      }
    }
    if(verbose>0) cat('mstop0 quantile(.,0.8) of ', mstop0,'\n')
    mstop0=ceiling(quantile(mstop0,0.8))
    if(verbose>0) cat('mstop0=', mstop0,'\n')
  }

  ## step 2: optiming loglig.glmboost_SARAE for finding optimal rho & lambda.
  if(verbose>0) cat('Start optimization of rho and lambda\n')
res=nlminb(c(0,0), loglig.glmboost_SARAR,formula=formula,data=data,mstop=mstop0,nu=0.3,W=W,W2=W2,center=center, control = list(), lower = c(-0.99,-0.99),upper = c(0.99,0.99))
  rho=res$par[1]
  lambda=res$par[2]
  I_rhoW=Diagonal(nrow(W))-rho*W
  I_lambdaW=Diagonal(nrow(W2))-lambda*W2
  if(verbose>0) cat('rho=', rho, ' and lambda=',lambda,' with mstop=', mstop0,' \n')

  ## step 3: if mstop0 is not provided by the user, finding  mstop0 for rho using cross-validation
  if(search_mstop){
    glmboost_sarar=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sarar(I_rhoW,I_lambdaW))
    if(verbose>0) cat('Start final optimization of mstop \n')
    cv5f <- cv(model.weights(glmboost_sarar), type = "kfold",B=5)
    cvm <- cvrisk(glmboost_sarar, folds = cv5f, mc.cores = ncores)
    min_cv<-sqrt(mean(cvm[,which.min(colMeans(cvm))]))
    mstop0=mstop(cvm)
    if(verbose>0) cat('mstop=', mstop0,'\n')
    if(verbose>0) cat('min(cv) =',min_cv,'\n')
  }

  ## step 4:  estimation of final model using glmboost with optimal rho & mstop.
  glmboost_sarar=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop0, nu=nu),family =cust_loss_sarar(I_rhoW,I_lambdaW))
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  fittedYS<-fitted(glmboost_sarar)
  Y_pred = as.numeric(
    spb_solve_nested_spatial_rhs(
      W, rho, W2, lambda, fittedYS,
      direct_max_n = 25000L,
      tol = 1e-6,
      max_order = 50L
    )
  )
  glmboost_sarar$residuals=as.numeric(Y-Y_pred)
  glmboost_sarar$residuals_filtered <- as.numeric((Diagonal(n) - lambda * W2) %*% ((Diagonal(n) - rho * W) %*% Y - fittedYS))
  glmboost_sarar$residuals_pred <- as.numeric(Y - Y_pred)
  glmboost_sarar$rho=rho
  glmboost_sarar$lambda=lambda
  glmboost_sarar$Y=Y
  glmboost_sarar$fitted=Y_pred
  glmboost_sarar$fittedYS=fittedYS
  glmboost_sarar$cv<-min_cv
  glmboost_sarar$rmse=sqrt(mean(glmboost_sarar$residuals^2))
  glmboost_sarar$formula=formula
  class(glmboost_sarar)<-c('spboost','BLA_SARAR_ML',class(glmboost_sarar))
  return(glmboost_sarar)
}


# a intégrer ?
#AIC_lm.model <- AIC(lm.model)
#
