#' Spectrally penalized smoother (basis "spx") for mgcv formulas
#'
#' Smooth constructor implementing the spectral penalization remedy for
#' spatial confounding between a flexible (typically geographic) smooth
#' and the spatial autoregressive component. The smooth is built on an
#' ordinary mgcv basis (thin plate by default) and carries a
#' \emph{second} penalty
#' \eqn{\mu_s\,\theta^\top X^\top \Phi_k \Phi_k^\top X\,\theta}, where
#' \eqn{\Phi_k} collects the \code{kspec} dominant eigenvectors of the
#' symmetrised spatial weight matrix \code{W} and \eqn{X} is the basis
#' evaluated at the data. The penalty shrinks the component of the
#' fitted smooth lying in the span of the dominant spatial modes, so
#' that the spectral projection diagnostic \code{\link{pi_k_diagnostic}}
#' decreases continuously with \eqn{\mu_s}: at \eqn{\mu_s=0} the smooth
#' is unrestricted, as \eqn{\mu_s\to\infty} it is constrained to the
#' orthogonal complement of the dominant modes (hard restriction).
#'
#' The extra smoothing parameter \eqn{\mu_s} is estimated by
#' REML/GCV like any other mgcv smoothing parameter, or can be fixed by
#' passing \code{sp} to the term or to the fitting function (the
#' spectral penalty is the \emph{last} smoothing parameter of the
#' term). Because \eqn{\Phi_k} depends only on \code{W} (not on the
#' response), the smoother remains a fixed-dictionary estimator and the
#' asymptotic theory of the CFE framework applies unchanged.
#'
#' @section Usage in formulas:
#' \preformatted{
#' gam(Y ~ s(X1) + s(x, y, k = 60, bs = "spx",
#'            xt = list(W = W, kspec = 25)), data = d)
#' }
#'
#' @param object a smooth specification object produced by
#'   \code{mgcv::s(..., bs = "spx", xt = list(...))}. The \code{xt}
#'   list must contain \code{W} (the n x n spatial weight matrix, rows
#'   aligned with the fitting data, dense or sparse \code{Matrix});
#'   optional elements: \code{kspec} (number of dominant eigenvectors,
#'   default 25), \code{bs} (base basis, default \code{"tp"}),
#'   \code{eigs} (precomputed list with \code{vectors}/\code{values} of
#'   the symmetrised \code{W}, to skip the eigendecomposition), and
#'   \code{xt} (an \code{xt} list passed through to the base basis).
#' @param data,knots as in \code{mgcv::smooth.construct}.
#' @return A smooth object of the base class with one additional
#'   penalty matrix; prediction and plotting are inherited from the
#'   base basis.
#' @details For \code{n > 3000} the \code{RSpectra} package is
#'   required unless \code{eigs} is supplied. The fitting data must
#'   contain no missing values on the model variables, so that rows
#'   stay aligned with \code{W}.
#' @references Appendix C.6 of the spboost article (spectral
#'   separation diagnostic and remedy); Hughes and Haran (2013) for
#'   the related Moran-basis construction.
#' @export
smooth.construct.spx.smooth.spec <- function(object, data, knots) {
  xt <- object$xt
  if (is.null(xt) || is.null(xt$W)) {
    stop("bs = \"spx\" requires xt = list(W = <spatial weight matrix>, ...)")
  }
  W <- xt$W
  kspec <- xt$kspec
  if (is.null(kspec)) kspec <- 25L
  kspec <- max(1L, as.integer(kspec[[1]]))
  base_bs <- xt$bs
  if (is.null(base_bs)) base_bs <- "tp"

  n <- length(data[[object$term[1]]])
  if (is.null(dim(W)) || nrow(W) != n || ncol(W) != n) {
    stop("xt$W must be an n x n matrix aligned with the fitting data (n = ",
         n, ")")
  }

  ## construct the base smooth
  base_spec <- object
  base_spec$xt <- xt$xt
  class(base_spec) <- paste0(base_bs, ".smooth.spec")
  sm <- mgcv::smooth.construct(base_spec, data, knots)

  ## dominant eigenvectors of the symmetrised W
  if (!is.null(xt$eigs)) {
    phi <- as.matrix(xt$eigs$vectors)
    if (nrow(phi) != n) stop("xt$eigs$vectors must have n rows")
    kspec <- min(kspec, ncol(phi))
    phi <- phi[, seq_len(kspec), drop = FALSE]
  } else {
    S <- if (inherits(W, "Matrix")) (W + Matrix::t(W)) / 2 else {
      Wm <- as.matrix(W)
      (Wm + t(Wm)) / 2
    }
    kspec <- min(kspec, n - 1L)
    has_rspectra <- requireNamespace("RSpectra", quietly = TRUE)
    if (has_rspectra && kspec < (n - 1L)) {
      eg <- RSpectra::eigs_sym(S, k = kspec, which = "LA")
      ord <- order(eg$values, decreasing = TRUE)
      phi <- eg$vectors[, ord, drop = FALSE]
    } else {
      if (n > 3000L) {
        stop("n > 3000 requires the 'RSpectra' package (or supply xt$eigs)")
      }
      eg <- eigen(as.matrix(S), symmetric = TRUE)
      phi <- eg$vectors[, seq_len(kspec), drop = FALSE]
    }
  }

  ## spectral penalty in coefficient space: S2 = X' Phi Phi' X
  A <- crossprod(phi, sm$X)              # kspec x q
  S2 <- crossprod(A)                     # q x q, PSD
  ## scale to a magnitude comparable with the base penalty, so that
  ## REML initialisation is well conditioned
  nrm <- norm(S2, type = "F")
  if (is.finite(nrm) && nrm > 0) S2 <- S2 / nrm
  r2 <- qr(A)$rank

  sm$S[[length(sm$S) + 1L]] <- S2
  sm$rank <- c(sm$rank, r2)
  ## the spectral penalty also penalises part of the base null space
  ## (e.g. the linear trend of a thin-plate smooth): the joint null
  ## space is the intersection of the individual null spaces, computed
  ## numerically as the null space of the summed penalties
  St <- Reduce(`+`, sm$S)
  sm$null.space.dim <- ncol(sm$X) - qr(St)$rank
  sm$spx <- list(kspec = kspec)
  sm
}
