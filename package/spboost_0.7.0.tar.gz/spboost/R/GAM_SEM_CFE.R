#' GAM_SEM_CFE
#' GAM_SEM_CFE allows the estimation of additive non linear SEM models using generalized additive models for the non linear part while the spatial parameter is estimated with the determinant-free Closed-Form Estimator of Smirnov (2020, doi:10.1111/gean.12268). This function makes it possible to estimate an additive non linear SEM model while automatically selecting the explanatory variables.
#' @usage GAM_SEM_CFE(formula,data,W,doMC=FALSE,ncores=3,
#' engine=c('auto','gam','bam'),bam_threshold=12000L,bam_discrete=TRUE,bam_nthreads=NULL,
#' fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10)
#' @param formula a gambboost formula (see mboost help)
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param doMC deprecated, ignored. CFE pre-fits are now sequential.
#' @param ncores maximum number of threads used by \code{bam} defaults; capped at 3.
#' @param engine fitting backend for the non-spatial regressions:
#' \code{"gam"}, \code{"bam"} or \code{"auto"}.
#' @param bam_threshold threshold on sample size used when \code{engine="auto"}.
#' @param bam_discrete logical passed to \code{mgcv::bam(discrete=...)}.
#' @param bam_nthreads number of threads used by \code{bam}; platform-aware defaults apply.
#' @param fallback fallback strategy when exact CFE root is not real or unstable.
#' \code{"auto"} uses the weighted projection approximation, \code{"none"} returns an error object.
#' @param rho_bounds lower and upper bounds used to clip the estimated spatial parameter.
#' @param tol numerical tolerance used for near-singular denominators/discriminant.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function erroesarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
GAM_SEM_CFE<-function(formula,data,W,doMC=FALSE,ncores=3,engine=c('auto','gam','bam'),bam_threshold=12000L,bam_discrete=TRUE,bam_nthreads=NULL,fallback=c('auto','none'),rho_bounds=c(-0.99,0.99),tol=1e-10){
  fallback <- match.arg(fallback)
  engine <- match.arg(engine)
  if (isTRUE(doMC)) {
    warning("doMC is deprecated and ignored in GAM_SEM_CFE(); CFE pre-fits are sequential.")
  }
  ptm_global <- proc.time()
  lambda_switch <- suppressWarnings(as.numeric(getOption("spboost.sem_cfe.lambda_switch", 0.9))[1])
  if (!is.finite(lambda_switch)) lambda_switch <- 0.9
  lambda_switch <- max(rho_bounds[1], min(rho_bounds[2], lambda_switch))

  n <- nrow(data)
  bam_threshold <- as.integer(bam_threshold[[1]])
  if (!is.finite(bam_threshold) || bam_threshold < 1L) bam_threshold <- 12000L
  use_bam <- switch(engine, auto = n >= bam_threshold, gam = FALSE, bam = TRUE)
  bam_threads <- spb_bam_threads(bam_nthreads = bam_nthreads, ncores = ncores, max_threads = 3L)
  fit_backend <- function(ff, data, nthreads) {
    if (use_bam) {
      mgcv::bam(ff, data = data, discrete = isTRUE(bam_discrete), nthreads = nthreads)
    } else {
      mgcv::gam(ff, data = data)
    }
  }

  YX=get_all_vars(formula, data)
  Y=as.numeric(YX[,1])
  X=as.matrix(YX[,-1])
  namesX<-colnames(X)
  data$Y=Y
  data$WY=as.numeric(W%*%Y)
  WX=data.frame(as.matrix(W%*%X))
  colnames(WX)=paste0('WX.',namesX)
  data=cbind(data,WX)
  f0<- f1<-formula
  td_form<-td_form2<-formula[3]
  for(i in namesX){
    td_form2<-gsub(i,paste0('WX.',i),td_form2)
  }
  td_form0<-paste0('Y~.+',as.name(td_form2))
  td_form1<-paste0('WY~.+',as.name(td_form2))
  f0<-update.formula(f0,td_form0)
  f1<-update.formula(f1,td_form1)

  fit_filtered <- function() {
    ptm <- proc.time()
    m0 <- fit_backend(f0, data = data, nthreads = bam_threads)
    m1 <- fit_backend(f1, data = data, nthreads = bam_threads)
    e0 <- residuals(m0)
    e1 <- residuals(m1)
    a <- as.numeric(t(e1) %*% W %*% e1)
    b <- as.numeric(t(e0) %*% W %*% e1 + t(e1) %*% W %*% e0)
    cc <- as.numeric(t(e0) %*% W %*% e0)
    D <- b^2 - 4 * a * cc

    rho <- NA_real_
    rho_method <- NA_character_
    rho_exact_root <- NA_integer_
    if (D < 0 && abs(D) <= tol) D <- 0
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      rho_candidates <- c(
        as.numeric((b - sqrtD) / (2 * a)),
        as.numeric((b + sqrtD) / (2 * a))
      )
      ok <- is.finite(rho_candidates)
      if (any(ok)) {
        rho_candidates <- rho_candidates[ok]
        root_idx <- which(ok)
        in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
        if (any(in_bounds)) {
          rho_eval <- rho_candidates[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(
          rho_eval,
          function(rh) sum((e0 - rh * e1)^2),
          numeric(1)
        )
        best <- which.min(score)
        rho <- as.numeric(rho_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method <- "cfe_exact"
      }
    } else if (fallback == "auto") {
      den_w <- as.numeric(t(e1) %*% W %*% e1)
      num_w <- as.numeric(t(e1) %*% W %*% e0)
      if (abs(den_w) > tol) {
        rho <- num_w / den_w
        rho_method <- "cfe_weighted_projection"
      }
    }

    if (is.na(rho) || !is.finite(rho)) {
      model <- paste0("CFE failed: no admissible SEM lambda (D=", signif(D, 6), ", a=", signif(a, 6), ").")
      class(model) <- "error"
      return(model)
    }

    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    XS <- data.frame(cbind(as.numeric(Y - rho * W %*% Y), as.matrix(X - rho * WX)))
    colnames(XS) <- c('Y', namesX)
    model <- fit_backend(formula, data = XS, nthreads = bam_threads)
    Y_pred <- fitted(model)
    e <- (Y - Y_pred)
    den_var <- (b - 2 * rho * a)
    if (abs(den_var) > tol) {
      model$var_rho <- (t(e0 - rho * e1) %*% (e0 - rho * e1) / n) / den_var
    } else {
      model$var_rho <- NA_real_
    }
    model$residuals <- e
    model$rmse <- sqrt(mean(model$residuals^2))
    model$fittedYS <- fitted(model)
    model$fitted <- Y - model$residuals
    model$rho <- rho
    model$rho_method <- rho_method
    model$rho_exact_root <- rho_exact_root
    model$engine <- if (use_bam) "bam" else "gam"
    model$bam_nthreads <- if (use_bam) bam_threads else NA_integer_
    model$ncores_cfe <- 1L
    model$D <- D
    model$elapsed <- as.numeric((proc.time() - ptm)[3])
    class(model) <- c('spboost','GAM_SEM_CFE', class(model))
    model
  }

  fit_brut <- function() {
    ptm <- proc.time()
    model_ols <- fit_backend(formula, data = data, nthreads = bam_threads)
    e_brut <- as.numeric(Y - fitted(model_ols))
    We <- as.numeric(W %*% e_brut)
    WWe <- as.numeric(W %*% We)

    a <- sum(We * WWe)
    b <- sum(e_brut * WWe) + sum(We * We)
    cc <- sum(e_brut * We)
    D <- b^2 - 4 * a * cc
    if (D < 0 && abs(D) <= tol) D <- 0

    rho <- NA_real_
    rho_exact_root <- NA_integer_
    rho_method_raw <- NA_character_
    if (abs(a) > tol && D >= 0) {
      sqrtD <- sqrt(D)
      rho_candidates <- c(
        as.numeric((b - sqrtD) / (2 * a)),
        as.numeric((b + sqrtD) / (2 * a))
      )
      ok <- is.finite(rho_candidates)
      if (any(ok)) {
        rho_candidates <- rho_candidates[ok]
        root_idx <- which(ok)
        in_bounds <- rho_candidates >= rho_bounds[1] & rho_candidates <= rho_bounds[2]
        if (any(in_bounds)) {
          rho_eval <- rho_candidates[in_bounds]
          root_eval <- root_idx[in_bounds]
        } else {
          rho_eval <- pmin(pmax(rho_candidates, rho_bounds[1]), rho_bounds[2])
          root_eval <- root_idx
        }
        score <- vapply(
          rho_eval,
          function(rh) sum((e_brut - rh * We)^2),
          numeric(1)
        )
        best <- which.min(score)
        rho <- as.numeric(rho_eval[best])
        rho_exact_root <- as.integer(root_eval[best])
        rho_method_raw <- "cfe_brut_residuals"
      }
    }
    if (!is.finite(rho)) {
      den1 <- sum(We^2)
      if (is.finite(den1) && abs(den1) > tol) {
        rho <- cc / den1
        rho_method_raw <- "cfe_brut_projection"
      } else {
        rho <- 0
        rho_method_raw <- "cfe_brut_init_fallback"
      }
    }

    if (identical(fallback, "none") &&
        !(is.character(rho_method_raw) && length(rho_method_raw) == 1L &&
          !is.na(rho_method_raw) &&
          rho_method_raw %in% c("cfe_brut_residuals", "cfe_brut_iter_exact"))) {
      if (is.na(rho_method_raw) || !nzchar(rho_method_raw)) rho_method_raw <- "unknown"
      model <- paste0(
        "CFE failed: no admissible exact SEM lambda in BRUT backend (rho_method=",
        rho_method_raw, ")."
      )
      class(model) <- "error"
      return(model)
    }

    rho <- max(min(rho, rho_bounds[2]), rho_bounds[1])
    XS <- data.frame(cbind(as.numeric(Y - rho * W %*% Y), as.matrix(X - rho * WX)))
    colnames(XS) <- c('Y', namesX)
    model <- fit_backend(formula, data = XS, nthreads = bam_threads)
    Y_pred <- fitted(model)
    e <- (Y - Y_pred)
    den_var <- (b - 2 * rho * a)
    if (abs(den_var) > tol) {
      model$var_rho <- (sum((e_brut - rho * We)^2) / n) / den_var
    } else {
      model$var_rho <- NA_real_
    }

    rho_method <- if (is.character(rho_method_raw) && length(rho_method_raw) == 1L && !is.na(rho_method_raw)) {
      switch(
        rho_method_raw,
        cfe_brut_residuals = "cfe_exact",
        cfe_brut_iter_exact = "cfe_exact",
        cfe_brut_projection = "cfe_weighted_projection",
        cfe_brut_init_fallback = "cfe_weighted_projection",
        rho_method_raw
      )
    } else {
      rho_method_raw
    }

    model$residuals <- e
    model$rmse <- sqrt(mean(model$residuals^2))
    model$fittedYS <- fitted(model)
    model$fitted <- Y - model$residuals
    model$rho <- rho
    model$rho_method_raw <- rho_method_raw
    model$rho_method <- rho_method
    model$rho_exact_root <- rho_exact_root
    model$engine <- if (use_bam) "bam" else "gam"
    model$bam_nthreads <- if (use_bam) bam_threads else NA_integer_
    model$ncores_cfe <- 1L
    model$D <- D
    model$elapsed <- as.numeric((proc.time() - ptm)[3])
    class(model) <- c('spboost','GAM_SEM_CFE', class(model))
    model
  }

  model_brut <- fit_brut()
  if (inherits(model_brut, "error")) return(model_brut)

  rho_brut <- suppressWarnings(as.numeric(model_brut$rho)[1])
  switched_to_filtered <- is.finite(rho_brut) && (rho_brut > lambda_switch)

  model <- model_brut
  backend_used <- "brut"
  if (switched_to_filtered) {
    model_filtered <- fit_filtered()
    if (inherits(model_filtered, "error")) {
      if (identical(fallback, "none")) {
        return(model_filtered)
      }
      warning("GAM_SEM_CFE: filtered switch failed after high BRUT rho; keeping BRUT estimate.")
      backend_used <- "brut_after_filtered_error"
    } else {
      model <- model_filtered
      backend_used <- "filtered"
    }
  }

  if (identical(backend_used, "filtered")) {
    rho_method_raw <- if (!is.null(model$rho_method)) as.character(model$rho_method[[1]]) else NA_character_
    model$rho_method_raw <- rho_method_raw
  }

  model$cfe_switch <- list(
    threshold = lambda_switch,
    rho_brut = if (is.finite(rho_brut)) rho_brut else NA_real_,
    switched_to_filtered = identical(backend_used, "filtered"),
    backend_used = backend_used
  )
  model$cfe_backend <- if (identical(backend_used, "filtered")) {
    "GAM_SEM_CFE_filtered"
  } else {
    "GAM_SEM_CFE_BRUT"
  }
  model$elapsed <- as.numeric((proc.time() - ptm_global)[3])
  class(model) <- unique(c("spboost", "GAM_SEM_CFE", setdiff(class(model), c("spboost", "GAM_SEM_CFE"))))
  return(model)
}
