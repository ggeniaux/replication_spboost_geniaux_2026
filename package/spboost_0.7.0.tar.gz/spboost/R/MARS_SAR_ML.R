#' MARS_SAR_ML
#' MARS_SAR_ML estimates additive nonlinear SAR models using a MARS backend
#' (`earth::earth`) for the nonlinear component and concentrated likelihood
#' for the spatial autoregressive parameter.
#' @usage MARS_SAR_ML(formula,data,W,RHO=NULL,WW=NULL,control=boost_control(),
#' control_earth=list(),verbose=0,fallback=c("auto","none"))
#' @param formula a model formula. mboost-style terms are converted to an earth-compatible formula.
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for spatial autocorrelation.
#' @param RHO a vector of fixed rho values (used when \code{WW} is provided).
#' @param WW a list of row-standardized spatial weight matrices, default NULL.
#' @param control \code{boost_control()} object (used for compatibility and optional defaults for \code{control_earth}).
#' @param control_earth list of control parameters passed to \code{earth::earth}
#' (e.g. \code{degree}, \code{nprune}, \code{nk}, \code{penalty}, \code{thresh}, \code{trace}).
#' Optional CV tuning of \code{nprune} is available with
#' \code{use_cv_nprune=TRUE} and controls
#' \code{cv_nfold}, \code{cv_ncore}, \code{cv_mode},
#' \code{cv_nprune_grid} (or \code{cv_nprune_min/max/length}).
#' @param verbose verbose mode, default \code{0}.
#' @param fallback fallback strategy when exact ML optimization is unstable.
#' @return An object of class \code{earth}, augmented with \code{spboost} fields
#' including \code{rho}, \code{rmse}, fitted values and residuals.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0.3, betas = c(0, 0.5, 1, -1), sigma2 = 1,
#'   model = "SAR", nonlin = TRUE, myseed = 23
#' )
#' fit <- MARS_SAR_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   control_earth = list(degree = 1, nk = 10, nprune = 5)
#' )
#' fit$rho
#' summary(fit)
#' @export
MARS_SAR_ML <- function(formula, data, W, RHO = NULL, WW = NULL,
                        control = boost_control(), control_earth = list(), verbose = 0,
                        fallback = c("auto", "none")) {
  fallback <- match.arg(fallback)
  n <- nrow(data)
  I <- Diagonal(n)
  stage_cfg <- spb_make_stage1_boost_control(control)
  control_stage1 <- stage_cfg$control_stage1
  control_final <- stage_cfg$control_final
  if (is.null(WW) || is.null(RHO)) {
    if (!is.list(W)) W <- list(W)
  } else if (!is.null(WW)) {
    W <- WW
  }
  env <- environment()
  data$Endogenous_spboost <- Y <- data[, as.character(attr(terms(formula), "variables")[[2]])]
  control_earth_use <- control_earth
  data$Endogenous_spboost_spfiltered <- as.numeric(data$Endogenous_spboost)
  formula_cv <- update.formula(formula, "Endogenous_spboost_spfiltered~.")
  earth_nprune_selection <- tryCatch(
    spb_tune_earth_nprune(
      formula = formula_cv,
      data = data,
      control_earth = control_earth_use,
      control_gamboost = control_final
    ),
    error = function(e) list(status = "error", message = conditionMessage(e))
  )
  if (!is.null(earth_nprune_selection$best_nprune) &&
      is.finite(as.numeric(earth_nprune_selection$best_nprune[[1]]))) {
    control_earth_use$nprune <- as.integer(earth_nprune_selection$best_nprune[[1]])
  }

  # LU_ldet adapted from spatialreg package
  LU_ldet <- function(coef, W, env, which = 1) {
    I <- get("I", envir = env)
    n <- get("n", envir = env)
    if (length(coef) > 1) {
      iW <- (I - coef[2] * W[[2]]) %*% (I - coef[1] * W[[1]])
    } else {
      iW <- (I - coef * W[[1]])
    }
    LU <- lu(iW)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }

  # lagsar.error.f adapted from spatialreg package
  lagsar.error.f <- function(Y, e, W, RHO, env) {
    SSE <- sum(e^2)
    s2 <- SSE / n
    ldet <- LU_ldet(RHO, W, env, which = 1)
    (ldet - ((n / 2) * log(2 * pi)) - (n / 2) * log(s2) - (1 / (2 * s2)) * SSE)
  }

  loglig.earth_SAR <- function(rho, RHO = NULL, formula, data, control_fit, control_earth_use, W) {
    n <- nrow(data)
    I <- Diagonal(n)
    if (is.null(WW)) {
      RHO <- rho
      iW <- (I - rho * W[[1]])
    } else {
      RHO <- c(rho, RHO)
      iW <- (I - RHO[2] * W[[2]] - RHO[1] * W[[1]])
    }
    data$Endogenous_spboost_spfiltered <- as.numeric(iW %*% data$Endogenous_spboost)
    formula2 <- update.formula(formula, "Endogenous_spboost_spfiltered~.")
    earthC <- tryCatch(
      spb_fit_earth_model(
        formula = formula2,
        data = data,
        control_earth = control_earth_use,
        control_gamboost = control_fit
      ),
      error = function(e) e
    )
    if (inherits(earthC, "error")) return(-1e30)
    ll <- lagsar.error.f(
      Y = data[, as.character(attr(terms(formula), "variables")[[2]])],
      e = residuals(earthC), W = W, RHO = RHO, env
    )
    if (!is.finite(ll)) return(-1e30)
    ll
  }

  if (verbose > 0) cat("Start optimization of rho\n")
  if (verbose > 0 && isTRUE(stage_cfg$two_stage)) cat("Two-stage ML objective with stage1 mstop=", stage_cfg$stage1_mstop, " / final mstop=", stage_cfg$final_mstop, "\n")
  res <- optimize(
    loglig.earth_SAR,
    lower = -0.99, upper = 0.99,
    control_fit = control_stage1,
    control_earth_use = control_earth_use,
    formula = formula,
    data = data,
    W = W,
    RHO = RHO,
    maximum = TRUE
  )
  rho <- res$maximum
  if (!is.finite(rho)) rho <- 0
  if (verbose > 0) cat("rho=", rho, "\n")

  if (!is.null(WW)) iW <- (I - rho * W[[2]] - RHO * W[[1]]) else iW <- (I - rho * W[[1]])
  data$Endogenous_spboost_spfiltered <- as.numeric(iW %*% data$Endogenous_spboost)
  formula2 <- update.formula(formula, "Endogenous_spboost_spfiltered~.")
  mars_sar <- tryCatch(
    spb_fit_earth_model(
      formula = formula2,
      data = data,
      control_earth = control_earth_use,
      control_gamboost = control_final
    ),
    error = function(e) e
  )
  if (inherits(mars_sar, "error") && fallback == "auto") {
    rho <- 0
    if (!is.null(WW)) iW <- (I - RHO * W[[1]]) else iW <- I
    data$Endogenous_spboost_spfiltered <- as.numeric(iW %*% data$Endogenous_spboost)
    mars_sar <- tryCatch(
      spb_fit_earth_model(
        formula = formula2,
        data = data,
        control_earth = control_earth_use,
        control_gamboost = control_final
      ),
      error = function(e) e
    )
  }
  if (inherits(mars_sar, "error")) {
    err <- paste0("MARS_SAR_ML failed at final earth fit: ", conditionMessage(mars_sar))
    class(err) <- "error"
    return(err)
  }

  Y <- data[, as.character(attr(terms(formula), "variables")[[2]])]
  fittedYS <- fitted(mars_sar)
  Y_pred <- as.numeric(rho * W[[1]] %*% Y) + fittedYS

  if (is.null(WW)) mars_sar$rho <- rho else mars_sar$rho <- c(RHO, rho)
  mars_sar$residuals <- Y - Y_pred
  mars_sar$Y <- Y
  mars_sar$fitted <- Y_pred
  mars_sar$fittedYS <- fittedYS
  mars_sar$logl <- res$objective
  mars_sar$rmse <- sqrt(mean((mars_sar$residuals)^2))
  mars_sar$formula <- formula
  mars_sar$control_earth <- spb_make_earth_control(control_earth = control_earth_use, control_gamboost = control_final)
  mars_sar$earth_nprune_selection <- earth_nprune_selection
  mars_sar$ml_two_stage <- isTRUE(stage_cfg$two_stage)
  mars_sar$ml_stage1_mstop <- stage_cfg$stage1_mstop
  mars_sar$ml_final_mstop <- stage_cfg$final_mstop
  class(mars_sar) <- c("spboost", "MARS_SAR_ML", class(mars_sar))

  if (verbose > 0) cat("RMSE =", mars_sar$rmse, "\n")
  mars_sar
}
