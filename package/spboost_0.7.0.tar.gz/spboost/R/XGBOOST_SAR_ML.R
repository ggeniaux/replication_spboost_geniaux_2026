#' XGBOOST_SAR_ML
#' XGBOOST_SAR_ML allows the estimation of SAR models using
#' the gradient boosting method with linear base learner or btree while
#' the estimation of the spatial parameter is based on a concentrated
#'  likelihood function. This function makes it possible to estimate
#'  a SAR linear or non linear model while automatically selecting
#'  the explanatory variables.
#' @usage XGBOOST_SAR_ML(formula,data,W,mstop0=NULL,mstop_init=500,
#' myparams=list(booster="gblinear", eta=0.3,gamma = 1, max_depth = 4,
#' min_child_weight = 5,subsample = 0.9,colsample_bytree = 0.9,
#' nthread=7,nfold=5,folds = NULL,early_stopping_rounds=3,verbose = 0),
#' rho0=c(0,0.2,0.8,0.8),verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param mstop_init max number of iterations for cross validation of
#' mstop0. mstop_init is used only if mstop0 is NULL, default 500.
#' @param mstop0 an integer giving the number of iterations
#' @param myparams 	the list of parameters:
#' * booster which booster to use, can be gbtree or gblinear. Default: gbtree.
#' * eta control the learning rate: scale the contribution of each tree by
#'  a factor of 0 < eta < 1 when it is added to the current approximation.
#'   Used to prevent overfitting by making the boosting process more
#'    conservative. Lower value for eta implies larger value for nrounds:
#'    low eta value means model more robust to overfitting but slower to
#'     compute. Default: 0.3
#' * gamma minimum loss reduction required to make a further partition on a
#'  leaf node of the tree. the larger, the more conservative the algorithm
#'  will be.
#' * max_depth maximum depth of a tree. Default: 6
#' * min_child_weight minimum sum of instance weight (hessian) needed in a
#'  child. If the tree partition step results in a leaf node with the sum
#'  of instance weight less than min_child_weight, then the building process
#'   will give up further partitioning. In linear regression mode, this simply
#'   corresponds to minimum number of instances needed to be in each node.
#'   The larger, the more conservative the algorithm will be. Default: 1
#' * subsample subsample ratio of the training instance. Setting it to 0.5
#'  means that xgboost randomly collected half of the data instances to grow
#'   trees and this will prevent overfitting. It makes computation shorter
#'    (because less data to analyse). It is advised to use this parameter
#'    with eta and increase nrounds. Default: 1
#' * colsample_bytree colsample_bytree subsample ratio of columns when
#'  constructing each tree. Default: 1
#' * nthread number of parallel threads
#' * nfold	during cross-validation the original dataset is randomly
#'  partitioned into nfold equal size subsamples. Default: 5
#' * folds list provides a possibility to use a list of pre-defined CV folds
#'  (each element must be a vector of test fold's indices). When folds are
#'   supplied, the nfold and stratified parameters are ignored.
#' * early_stopping_rounds if NULL, the early stopping function is not
#'  triggered. If set to an integer k, training with a validation set will
#'   stop if the performance doesn't improve for k rounds.
#' * verbose if verbose>0 Give verbose output for xgboost and xgb.cv function.
#' @param rho0 a set of rho values (between -1 and 1) for estimating initial
#'  mstop0. Used only if mstop0 is NULL. Default c(0,0.8).
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#'
#'
XGBOOST_SAR_ML=function(formula,data,W,mstop0=NULL,mstop_init=500,myparams=list(booster="gblinear",eta=0.3,gamma = 1, max_depth = 4,min_child_weight = 5,subsample = 0.9,colsample_bytree = 0.9,nthread=7,nfold=5,folds = NULL,early_stopping_rounds=3,verbose = 0),rho0=c(0,0.2,0.8,0.8),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  two_stage <- FALSE
  stage1_nrounds <- NA_integer_
  final_nrounds_target <- suppressWarnings(as.integer(mstop_init[[1]]))
  if (!is.finite(final_nrounds_target) || final_nrounds_target < 1L) final_nrounds_target <- 500L
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef, env, which = 1)
  {
    I <- get("I", envir = env)
    if (which == 1) {
      W <- get("W", envir = env)
    }
    else {
      W <- get("W2", envir = env)
    }
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## lagsar.error.f from spatialreg package
  lagsar.error.f<-function (Y,e,W,rho, env)
  {
    SSE=sum(e^2)
    s2 <- SSE/n
    ldet <- LU_ldet(rho, env, which = 1)
    ret <- (ldet-((n/2) *log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
   ## custom loglig using glmboost instead of lm for finding Beta coefficients
  loglig.glmboost_SAR<-function(rho,formula,data,W,myparams,nrounds){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    y_name <- as.character(attr(terms(formula),'variables')[[2]])
    Y <- data[[y_name]]
    if (is.data.frame(Y)) Y <- Y[[1]]
    Y <- suppressWarnings(as.numeric(Y))
    if (length(Y) != n) Y <- suppressWarnings(as.numeric(get_all_vars(formula, data)[, 1]))
    if (length(Y) != n || any(!is.finite(Y))) return(-Inf)
    YS<-as.numeric(Y- rho* W %*% Y)
    xtrain=model.matrix(formula,data)
    xtrain_dm <- xgboost::xgb.DMatrix(data = xtrain, info = list(label = YS))
    reg= xgboost::xgb.train(data = xtrain_dm, params=myparams,nrounds=nrounds,verbose =FALSE)
    e=YS-predict(object=reg, newdata=xgboost::xgb.DMatrix(data = xtrain))
    lagsar.error.f(Y=Y,e=e,W=W,rho=rho, env)
  }
  xtrain=model.matrix(formula,data)
  y_name <- as.character(attr(terms(formula),'variables')[[2]])
  Y <- data[[y_name]]
  if (is.data.frame(Y)) Y <- Y[[1]]
  Y <- suppressWarnings(as.numeric(Y))
  if (length(Y) != n) Y <- suppressWarnings(as.numeric(get_all_vars(formula, data)[, 1]))
  if (length(Y) != n || any(!is.finite(Y))) {
    stop("Invalid response vector `Y` extracted from `data`.")
  }
  n=length(Y)
  make_xgb_data <- function(label = NULL) {
    info <- if (is.null(label)) list() else list(label = label)
    xgboost::xgb.DMatrix(data = xtrain, info = info)
  }
  get_cv_nrounds <- function(cv, fallback) {
    fallback <- suppressWarnings(as.integer(fallback[1]))
    if (length(fallback) == 0L || is.na(fallback) || !is.finite(fallback) || fallback < 1L) fallback <- 1L

    best <- suppressWarnings(as.integer(cv$best_iteration[1]))
    if (length(best) > 0L && !is.na(best) && is.finite(best) && best >= 1L) return(best)

    best <- suppressWarnings(as.integer(cv$early_stop$best_iteration[1]))
    if (length(best) > 0L && !is.na(best) && is.finite(best) && best >= 1L) return(best)

    elog <- cv$evaluation_log
    if (!is.null(elog) && NROW(elog) > 0L) {
      metric_names <- names(elog)
      metric_names <- metric_names[grepl("^(test|validation|eval)_.*_mean$", metric_names)]
      if (length(metric_names) == 0L) {
        is_num <- vapply(elog, is.numeric, logical(1))
        metric_names <- setdiff(names(elog)[is_num], c("iter", "iteration"))
        metric_names <- metric_names[!grepl("_std$", metric_names)]
      }
      for (nm in metric_names) {
        vals <- suppressWarnings(as.numeric(elog[[nm]]))
        if (any(is.finite(vals))) return(as.integer(which.min(vals)))
      }
      return(as.integer(NROW(elog)))
    }
    fallback
  }
  get_cv_min <- function(cv) {
    elog <- cv$evaluation_log
    if (is.null(elog) || NROW(elog) == 0L) return(NA_real_)
    metric_names <- names(elog)
    metric_names <- metric_names[grepl("^(test|validation|eval)_.*_mean$", metric_names)]
    if (length(metric_names) == 0L) return(NA_real_)
    vals <- suppressWarnings(as.numeric(elog[[metric_names[1]]]))
    if (!any(is.finite(vals))) return(NA_real_)
    min(vals, na.rm = TRUE)
  }
  make_spboost_xgb_model <- function(booster) {
    estimator_class <- ifelse(myparams$booster == "gblinear", "XGBOOST_LINEAR_SAR_ML", "XGBOOST_SAR_ML")
    model <- list(booster = booster)
    class(model) <- c("spboost", estimator_class, "spboost_xgb_model")
    model
  }

  ### step 1 findind mstop0

  myparams$objective = 'reg:squarederror'
  myparams$eval_metric = 'rmse'
  nrounds=mstop0
  search_mstop=is.null(mstop0)
  if (search_mstop) {
    stage1_nrounds <- ceiling(final_nrounds_target * 0.25)
    stage1_nrounds <- max(50L, stage1_nrounds)
    stage1_nrounds <- min(300L, stage1_nrounds, final_nrounds_target)
    if (is.finite(stage1_nrounds) && stage1_nrounds < final_nrounds_target) {
      two_stage <- TRUE
    } else {
      stage1_nrounds <- final_nrounds_target
    }
  }

  if(search_mstop & myparams$booster!='gblinear'){
    if(verbose>0) cat('Approximation mstop0 using cvxgboosts (5 kfolds) with rho=',rho0,' \n')
    if(verbose>0 && isTRUE(two_stage)) cat('Two-stage ML objective with stage1 nrounds=', stage1_nrounds, ' / final nrounds=', final_nrounds_target, '\n')
    mstop1=c()
    myfoldGG<-0
    if(is.null(myparams$folds)) cvFoldsList<-createFolds(Y, k=myparams$nfold, list=TRUE, returnTrain=FALSE) else cvFoldsList<-myparams$folds
    for(rho in rho0){
      YS<-as.numeric((Diagonal(nrow(W)) - rho * W)%*%Y)
      cv <- xgb.cv(params=myparams,data = make_xgb_data(YS), nrounds = stage1_nrounds, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
      mstop1<-c(mstop1,get_cv_nrounds(cv, stage1_nrounds))
    }
    if(verbose>0) cat('mstop0 mean of ', mstop1,'\n')
    mstop0=ceiling(mean(mstop1))
    if(verbose>0) cat('mstop0=', mstop0,'\n')
  }

  if(myparams$booster=="gblinear") mstop0=500
  ## step 2: optiming loglig.glmboost_SAR for finding optimal rho.
  nrounds = mstop0


  if(verbose>0) cat('Start optimization of rho\n')
   myparams_train<-myparams
   j<-c('early_stopping_rounds', 'folds', 'nfold', 'nrounds', 'verbose')
   for(i in j) myparams_train[[i]]<-NULL
  res=optimize(loglig.glmboost_SAR,lower=-0.99,upper=0.99,formula=formula,data=data,W=W,myparams=myparams_train,nrounds=nrounds,maximum =TRUE)
  rho=res$maximum
  if(verbose>0) cat('rho=', rho, 'with mstop=', mstop0,' \n')
  YS<-as.numeric((Diagonal(nrow(W)) - rho * W)%*%Y)
  if(is.null(myparams$folds)) cvFoldsList<-createFolds(Y, k=myparams$nfold, list=TRUE, returnTrain=FALSE) else cvFoldsList<-myparams$folds
  cv <- xgb.cv(params=myparams,data = make_xgb_data(YS), nrounds = mstop_init, folds=cvFoldsList,early_stopping_rounds =myparams$early_stopping_rounds,maximize=FALSE,verbose =FALSE)
  nrounds=get_cv_nrounds(cv, mstop_init)
  cv_min=get_cv_min(cv)
  booster= xgboost::xgb.train(params=myparams_train,data = make_xgb_data(YS),nrounds=nrounds,verbose =FALSE)
  fittedYS=predict(object=booster, newdata=make_xgb_data())
  fitted=as.numeric(rho*W %*%Y+fittedYS)
  model=make_spboost_xgb_model(booster)
  model$residuals=Y-fitted
  model$rho=rho
  model$Y=Y
  model$fitted=fitted
  model$fittedYS=fittedYS
  model$cv<-cv_min
  model$rmse=sqrt(mean(model$residuals^2))
  model$formula=formula
  model$ml_two_stage <- isTRUE(two_stage)
  model$ml_stage1_mstop <- if (is.finite(stage1_nrounds)) as.integer(stage1_nrounds) else NA_integer_
  model$ml_final_mstop <- if (is.finite(nrounds)) as.integer(nrounds) else NA_integer_
  return(model)
}
