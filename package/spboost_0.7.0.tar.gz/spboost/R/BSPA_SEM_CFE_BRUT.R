#' BSPA_SEM_CFE_BRUT
#' Experimental SEM CFE variant using raw residuals for the CFE update.
#' @usage BSPA_SEM_CFE_BRUT(formula,data,W,control=boost_control(),
#'                          rho_bounds=c(-0.99,0.99),lambda_switch=0.80,
#'                          tol=1e-10,max_iter=3L,tol_lambda=1e-4,verbose=0)
#' @param formula a gamboost formula.
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix.
#' @param control boost_control() object (mboost).
#' @param rho_bounds admissible bounds for lambda.
#' @param lambda_switch threshold above which the filtered CFE update is used.
#' @param tol numerical tolerance.
#' @param max_iter maximum number of adaptive CFE iterations.
#' @param tol_lambda convergence tolerance on \eqn{\lambda}.
#' @param verbose verbosity level (0/1).
#' @return An object of class mboost augmented with SEM spatial outputs.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = TRUE, myseed = 14
#' )
#' fit <- BSPA_SEM_CFE_BRUT(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   control = mboost::boost_control(mstop = 5, nu = 0.2),
#'   max_iter = 1
#' )
#' fit$rho
#' summary(fit)
BSPA_SEM_CFE_BRUT <- function(formula, data, W,
                              control      = boost_control(),
                              rho_bounds   = c(-0.99, 0.99),
                              lambda_switch = 0.80,
                              tol          = 1e-10,
                              max_iter     = 3L,
                              tol_lambda   = 1e-4,
                              verbose      = 0) {
  ptm1 <- proc.time()
  max_iter <- suppressWarnings(as.integer(max_iter[[1]]))
  if (!is.finite(max_iter) || max_iter < 1L) max_iter <- 3L
  tol_lambda <- suppressWarnings(as.numeric(tol_lambda[[1]]))
  if (!is.finite(tol_lambda) || tol_lambda <= 0) tol_lambda <- 1e-4
  lambda_switch <- suppressWarnings(as.numeric(lambda_switch[[1]]))
  if (!is.finite(lambda_switch)) lambda_switch <- 0.80
  lambda_switch <- max(rho_bounds[1], min(rho_bounds[2], lambda_switch))
  YX   <- get_all_vars(formula, data)
  Y    <- as.numeric(YX[, 1])
  n    <- length(Y)

  # ------------------------------------------------------------------
  # Fonction interne : CFE sur résidus BRUTS y - fhat
  # Retourne lambda_hat
  # ------------------------------------------------------------------
  cfe_brut <- function(e_brut) {
    We  <- as.numeric(W %*% e_brut)
    WWe <- as.numeric(W %*% We)
    a   <- sum(We * WWe)
    b   <- sum(e_brut * WWe) + sum(We * We)
    cc  <- sum(e_brut * We)
    D   <- b^2 - 4 * a * cc
    if (D < 0 && abs(D) <= tol) D <- 0

    lambda_hat <- NA_real_
    rho_method <- NA_character_
    rho_exact_root <- NA_integer_
    if (abs(a) > tol && D >= 0) {
      sqrtD    <- sqrt(D)
      cands    <- c((b - sqrtD) / (2*a), (b + sqrtD) / (2*a))
      ok       <- is.finite(cands) &
        cands >= rho_bounds[1] & cands <= rho_bounds[2]
      if (any(ok)) {
        cands_ok   <- cands[ok]
        scores     <- sapply(cands_ok, function(l) sum((e_brut - l * We)^2))
        best <- which.min(scores)
        lambda_hat <- cands_ok[best]
        rho_exact_root <- as.integer(which(ok)[best])
        # Keep historical method label for downstream compatibility.
        rho_method <- "cfe_brut_residuals"
      }
    }
    if (!is.finite(lambda_hat)) {
      den        <- sum(We^2)
      lambda_hat <- if (abs(den) > tol) cc / den else 0
      rho_method <- "cfe_brut_projection"
    }
    lambda_hat <- max(rho_bounds[1], min(rho_bounds[2], lambda_hat))
    list(lambda = lambda_hat, method = rho_method, We = We, D = D, rho_exact_root = rho_exact_root)
  }

  # ------------------------------------------------------------------
  # Fonction interne : CFE sur résidus FILTRES (I-lambda*W)(y-fhat)
  # Utilisé quand lambda_hat > lambda_switch
  # ------------------------------------------------------------------
  cfe_filtered <- function(e_brut, lambda_prev) {
    I_lW   <- Matrix::Diagonal(n) - lambda_prev * W
    e_filt <- as.numeric(I_lW %*% e_brut)
    We_f   <- as.numeric(W %*% e_brut)
    e1f    <- as.numeric(I_lW %*% We_f)

    a   <- sum(e1f  * as.numeric(W %*% e1f))
    b   <- sum(e_filt * as.numeric(W %*% e1f)) +
      sum(e1f   * as.numeric(W %*% e_filt))
    cc  <- sum(e_filt * as.numeric(W %*% e_filt))
    D   <- b^2 - 4 * a * cc
    if (D < 0 && abs(D) <= tol) D <- 0

    lambda_hat <- NA_real_
    rho_method <- NA_character_
    rho_exact_root <- NA_integer_
    if (abs(a) > tol && D >= 0) {
      sqrtD    <- sqrt(D)
      cands    <- c((b - sqrtD) / (2*a), (b + sqrtD) / (2*a))
      ok       <- is.finite(cands) &
        cands >= rho_bounds[1] & cands <= rho_bounds[2]
      if (any(ok)) {
        cands_ok   <- cands[ok]
        scores     <- sapply(cands_ok,
                             function(l) sum((e_filt - l * e1f)^2))
        best <- which.min(scores)
        lambda_hat <- cands_ok[best]
        rho_exact_root <- as.integer(which(ok)[best])
        # Keep historical method label for downstream compatibility.
        rho_method <- "cfe_brut_iter_exact"
      }
    }
    if (!is.finite(lambda_hat)) {
      den        <- sum(e1f^2)
      lambda_hat <- if (abs(den) > tol) sum(e_filt * e1f) / den else lambda_prev
      rho_method <- "cfe_filtered_projection"
    }
    lambda_hat <- max(rho_bounds[1], min(rho_bounds[2], lambda_hat))
    list(lambda = lambda_hat, method = rho_method, D = D, rho_exact_root = rho_exact_root)
  }

  # ------------------------------------------------------------------
  # Étape 1 : initialisation lambda via OLS boosting
  # ------------------------------------------------------------------
  model_ols  <- gamboost(formula, data = data, control = control)
  e_ols      <- as.numeric(Y - fitted(model_ols))
  res_init   <- cfe_brut(e_ols)
  lambda_old <- res_init$lambda
  lambda_init <- res_init$lambda

  # ------------------------------------------------------------------
  # Étapes 2..max_iter : alternance fit SEM + CFE adaptatif
  # ------------------------------------------------------------------
  rho_method <- NA_character_
  model_final <- NULL
  last_D <- if (!is.null(res_init$D)) as.numeric(res_init$D) else NA_real_
  rho_exact_root <- if (!is.null(res_init$rho_exact_root)) as.integer(res_init$rho_exact_root) else NA_integer_

  for (iter in seq_len(max_iter)) {

    # Fit gamboost avec family SEM(lambda_old)
    # Correction closure : forcer l'evaluation de I_lW dans un
    # environnement local fige pour eviter la capture par reference.
    cust_fam <- local({
      I_lW_local <- Matrix::Diagonal(n) - lambda_old * W
      mboost::Family(
        ngradient = function(y, f, w = 1) as.numeric(I_lW_local %*% (y - f)),
        loss      = function(y, f) as.numeric((I_lW_local %*% (y - f))^2),
        name      = paste0("SEM_iter", iter)
      )
    })
    model_iter <- gamboost(formula, data = data,
                           control = control, family = cust_fam)
    fhat       <- as.numeric(fitted(model_iter))
    e_brut     <- Y - fhat

    # CFE adaptatif : brut si lambda modéré, filtré si lambda élevé
    if (abs(lambda_old) < lambda_switch) {
      res        <- cfe_brut(e_brut)
    } else {
      res        <- cfe_filtered(e_brut, lambda_old)
    }

    lambda_new <- res$lambda
    rho_method <- res$method
    if (!is.null(res$D)) last_D <- as.numeric(res$D)
    if (!is.null(res$rho_exact_root)) rho_exact_root <- as.integer(res$rho_exact_root)

    if (isTRUE(verbose > 0))
      cat(sprintf("  iter %d : lambda %.4f -> %.4f [%s]\n",
                  iter, lambda_old, lambda_new, rho_method))

    delta      <- abs(lambda_new - lambda_old)
    lambda_old <- lambda_new
    model_final <- model_iter

    if (delta < tol_lambda && iter > 1L) break
  }

  # ------------------------------------------------------------------
  # Modèle final avec lambda convergé
  # ------------------------------------------------------------------
  I_lW_final <- Matrix::Diagonal(n) - lambda_old * W
  cust_final <- mboost::Family(
    ngradient = function(y, f, w = 1) as.numeric(I_lW_final %*% (y - f)),
    loss      = function(y, f) as.numeric((I_lW_final %*% (y - f))^2),
    name      = "SEM_final"
  )
  model_final <- gamboost(formula, data = data,
                          control = control, family = cust_final)
  fhat_f  <- as.numeric(fitted(model_final))
  e_brut_f <- Y - fhat_f
  We_f    <- as.numeric(W %*% e_brut_f)

  # Variance de lambda (formule CFE)
  WWe_f   <- as.numeric(W %*% We_f)
  a_f     <- sum(We_f * WWe_f)
  b_f     <- sum(e_brut_f * WWe_f) + sum(We_f * We_f)
  den_var <- b_f - 2 * lambda_old * a_f
  var_rho <- if (abs(den_var) > tol)
    as.numeric(crossprod(e_brut_f - lambda_old * We_f) / n) / den_var
  else NA_real_

  model_final$rho          <- lambda_old
  model_final$lambda_init  <- as.numeric(lambda_init)
  model_final$rho_method   <- rho_method
  model_final$rho_method_raw <- rho_method
  model_final$rho_exact_root <- rho_exact_root
  model_final$D            <- last_D
  model_final$var_rho      <- var_rho
  # Bug 2 corrige : residuals = residus filtres (I-lambda*W)(Y-fhat)
  # conformement a la convention des autres estimateurs SEM de spboost.
  # Les residus bruts sont conserves dans residuals_raw.
  e_filtered_f             <- as.numeric(I_lW_final %*% e_brut_f)
  model_final$residuals    <- e_filtered_f
  model_final$residuals_raw <- as.numeric(e_brut_f)
  model_final$Y            <- Y
  model_final$fitted       <- fhat_f
  model_final$fittedYS     <- fhat_f
  model_final$rmse         <- sqrt(mean(e_filtered_f^2))
  model_final$elapsed      <- as.numeric((proc.time() - ptm1)[3])
  model_final$lambda_switch <- lambda_switch
  model_final$cfe_iter <- list(
    max_iter = max_iter,
    tol_lambda = tol_lambda
  )
  class(model_final) <- c(class(model_final),
                          c("spboost", "BSPA_SEM_CFE_BRUT"))
  model_final
}
