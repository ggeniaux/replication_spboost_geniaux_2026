#' BLA_SEM_ML
#' BLA_SEM_ML allows the estimation of SEM models using the gradient boosting
#' method with linear base learner for estimating the coefficients Beta while
#' the estimation of the spatial parameter is based on a concentrated likelihood
#' function. This function makes it possible to estimate a SEM model while
#' automatically selecting the explanatory variables.
#' @usage BLA_SEM_ML(formula,data,W,center=TRUE,mstop0=NULL,mstop_init=500,nu=0.3,ncores=2,
#' rho0=c(0),verbose=0)
#' @param formula a regular lm formula
#' @param data a dataframe.
#' @param W a row-standardized spatial weight matrix for Spatial Aurocorrelation.
#' @param mstop0 an integer giving the number of boosting iterations
#' @param mstop_init an integer giving the number of initial boosting iterations. If mstop = 0, the offset model is returned. Used only if mstop0 is NULL.
#' @param nu a double (between 0 and 1) defining the step size or shrinkage parameter.
#' @param rho0 a set of rho values (between -1 and 1) for estimating initial mstop0. Used only if mstop0 is NULL. Default c(0,0.8).
#' @param center logical indicating of the predictor variables are centered before fitting, Default TRUE.
#' @param ncores number of cores for parallel computing of cross validation of mstop, default ncores=2
#' @param verbose if verbose>0 verbose mode, default verbose=0.
#' @details the determinant of (I -rho W) is computed using code
#' from Matrix packages with a sparse matrix decomposition approach
#' (option 'LU' of function lagsarlm from spatialreg).
#' @return An object of class mboost with print, AIC, plot and predict methods being available,
#'  augmented with rho value and RMSE.
#' @examples
#' sim <- dgp(
#'   n = 500, rho = 0, lambda = 0.3, betas = c(0, 0.5, 1, -1),
#'   sigma2 = 1, model = "SEM", nonlin = FALSE, myseed = 9
#' )
#' fit <- BLA_SEM_ML(
#'   Y ~ X1 + X2 + X3, data = sim$data, W = sim$W,
#'   mstop0 = 5, nu = 0.2
#' )
#' fit$rho
#' summary(fit)
BLA_SEM_ML=function(formula,data,W,center=TRUE,mstop0=NULL,mstop_init=500,nu=0.3,ncores=2,rho0=c(0),verbose=0){
  n=nrow(data)
  I=Diagonal(n)
  sum_lw=0
  env=environment()
  ## LU_ldet from spatialreg package
  LU_ldet<-function (coef, env, which = 1)
  {
    I <- get("I", envir = env)
    if (which == 1) {
      W <- get("W", envir = env)
    }
    else {
      W <- get("W2", envir = env)
    }
    LU <- lu(I - coef * W)
    dU <- abs(Matrix::diag(slot(LU, "U")))
    ldet <- sum(log(dU))
    ldet
  }
  ## sar.error.f from spatialreg package
  sar.error.f<-function (SSE,lambda, env)
  {
    s2 <- SSE/n
    ldet <- LU_ldet(lambda, env, which = 1)
    ret <- (ldet + (1/2) * get("sum_lw", envir = env) - ((n/2) * log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
    ret
  }
  ## custom family (loss & gradient) adapted for SEM model
  cust_loss_sem = function(I_rhoW){
    Family(ngradient = function(y, f,w=1) as.numeric(I_rhoW%*%(y - f)),
           loss = function(y, f) as.numeric((I_rhoW%*%(y - f))^2),
           name = "SEM with I_rhoW=Diagonal(nrow(W))-rho*W")
  }
  ## custom loglig using glmboost instead of lm for finding Beta coefficients
  loglig.glmboost_SEM<-function(rho,formula,data,center,mstop=150,nu=0.3,W){
    n=nrow(data)
    I=Diagonal(n)
    sum_lw=0
    verbose=0
    env=environment()
    I_rhoW=Diagonal(nrow(W))-rho*W
    glmboostC=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop, nu=nu),family =cust_loss_sem(I_rhoW))
    SSE=sum((I_rhoW%*%(data[,as.character(attr(terms(formula),'variables')[[2]])]-as.numeric(fitted(glmboostC))))^2)
    sar.error.f(SSE,rho, env)
  }
  ## step 1: if mstop0 is not provided by the user, finding an appropriate mstop0 for a given set of rho using cross-validation
  min_cv= NULL
  search_mstop=is.null(mstop0)
  if(search_mstop){
    if(verbose>0) cat('Approximation mstop0 using cvrisk (25 kfolds) with rho=',rho0,' \n')
    mstop0=c()
    for(rho_temp in rho0){
      I_rhoW=Diagonal(nrow(W))-rho_temp*W
      glmboost_sem=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sem(I_rhoW))
      cv5f <- cv(model.weights(glmboost_sem), type = "kfold",B=5)
      cvm <- cvrisk(glmboost_sem, folds = cv5f, mc.cores = ncores)
      mstop0=c(mstop0,mstop(cvm))
    }
    if(verbose>0) cat('mstop0 mean of ', mstop0,'\n')
    mstop0=ceiling(mean(mstop0))
    if(verbose>0) cat('mstop0=', mstop0,'\n')
  }

  ## step 2: optiming loglig.glmboost_SEM for finding optimal rho.
  if(verbose>0) cat('Start optimization of rho\n')
  res=optimize(loglig.glmboost_SEM,lower=-0.99,upper=0.99,mstop=mstop0,formula=formula,data=data,center=center, nu=nu,W=W,maximum =TRUE)
  rho=res$maximum
  I_rhoW=Diagonal(nrow(W))-rho*W
  if(verbose>0) cat('rho=', rho, 'with mstop=', mstop0,' \n')

  ## step 3: if mstop0 is not provided by the user, finding  mstop0 for rho using cross-validation
  if(search_mstop){
    glmboost_sem=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop_init, nu=nu),family =cust_loss_sem(I_rhoW))
    if(verbose>0) cat('Start final optimization of mstop \n')
    cv5f <- cv(model.weights(glmboost_sem), type = "kfold",B=5)
    cvm <- cvrisk(glmboost_sem, folds = cv5f, mc.cores = ncores)
    cv_min<-sqrt(mean(cvm[,which.min(colMeans(cvm))]))
    mstop0=mstop(cvm)
    if(verbose>0) cat('mstop=', mstop0,'\n')
    if(verbose>0) cat('min(cv) =',min(apply(cvm,2,sum)),'\n')
  }

  ## step 4:  estimation of final model using glmboost with optimal rho & mstop.
  glmboost_sem=glmboost(formula, data=data,center=center,control=boost_control(mstop=mstop0, nu=nu),family =cust_loss_sem(I_rhoW))
  Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
  Y_pred= as.numeric(fitted(glmboost_sem))
  glmboost_sem$rho=rho
  glmboost_sem$residuals=Y-Y_pred
  glmboost_sem$Y=Y
  glmboost_sem$fitted=Y_pred
  glmboost_sem$fittedYS=Y_pred
  if(search_mstop) glmboost_sem$cv<-cv_min
  glmboost_sem$rmse=sqrt(mean(glmboost_sem$residuals^2))
  glmboost_sem$formula<-formula
  class(glmboost_sem)<-c('spboost','BLA_SEM_ML',class(glmboost_sem))
  return(glmboost_sem)
}

# glmboost_sem_nocustomfamily=function(formula,data,W,mstop0=NULL,mstop_init=500,nu=0.3,ncores=7,rho0=c(0),verbose=0){
#   n=nrow(data)
#   I=Diagonal(n)
#   sum_lw=0
#   env=environment()
#   LU_ldet<-function (coef, env, which = 1)
#   {
#     I <- get("I", envir = env)
#     if (which == 1) {
#       W <- get("W", envir = env)
#     }
#     else {
#       W <- get("W2", envir = env)
#     }
#     LU <- lu(I - coef * W)
#     dU <- abs(Matrix::diag(slot(LU, "U")))
#     ldet <- sum(log(dU))
#     ldet
#   }
#   sar.error.f<-function (SSE,lambda, env)
#   {
#     s2 <- SSE/n
#     ldet <- LU_ldet(lambda, env, which = 1)
#     ret <- (ldet + (1/2) * get("sum_lw", envir = env) - ((n/2) *    #### sum_lw=0 si pas de poids
#                                                            log(2 * pi)) - (n/2) * log(s2) - (1/(2 * (s2))) * SSE)
#     if (get("verbose", envir = env))
#       cat("lambda:", lambda, " function:", ret, " Jacobian:",
#           ldet, " SSE:", SSE, "\n")
#     ret
#   }
#   search_mstop=is.null(mstop0)
#   if(search_mstop){
#     if(verbose>0) cat('Approximation mstop0 using cvrisk (25 kfolds) with rho=',rho0,' \n')
#     mstop0=c()
#     for(rho in rho0){
#       glmboost_sem=glmboost(formula, data=data,center=T,control=boost_control(mstop=mstop_init, nu=nu))
#       cv5f <- cv(model.weights(glmboost_sem), type = "kfold",B=25)
#       cvm <- cvrisk(glmboost_sem, folds = cv5f, mc.cores = ncores)
#       mstop0=c(mstop0,mstop(cvm))
#     }
#     if(verbose>0) cat('mstop0 mean of ', mstop0,'\n')
#     mstop0=ceiling(mean(mstop0))
#     if(verbose>0) cat('mstop0=', mstop0,'\n')
#   }
#
#   loglig.glmboost_SEM<-function(rho,formula,data,mstop=150,nu=0.3,W,order_approw=18){
#     n=nrow(data)
#     I=Diagonal(n)
#     sum_lw=0
#     verbose=0
#     env=environment()
#
#     glmboostC=glmboost(formula, data=data,center=T,control=boost_control(mstop=mstop, nu=nu))
#
#     SSE=sum(((I-rho*W)%*%(data[,as.character(attr(terms(formula),'variables')[[2]])]-as.numeric(fitted(glmboostC))))^2)
#
#     sar.error.f(SSE,rho, env)
#   }
#   if(verbose>0) cat('Start optimization of rho\n')
#   res=optimize(loglig.glmboost_SEM,lower=-0.99,upper=0.99,mstop=mstop0,formula=formula,data=data, nu=nu,W=W,maximum =TRUE)
#   rho=res$maximum
#   if(verbose>0) cat('rho=', rho, 'with mstop=', mstop0,' \n')
#   if(search_mstop){
#     glmboost_sem=glmboost(formula, data=data,center=T,control=boost_control(mstop=mstop_init, nu=nu))
#     if(verbose>0) cat('Start final optimization of mstop \n')
#     cv25f <- cv(model.weights(glmboost_sem), type = "kfold",B=25)
#     cvm <- cvrisk(glmboost_sem, folds = cv25f, mc.cores = ncores)
#     mstop0=mstop(cvm)
#     if(verbose>0) cat('mstop=', mstop0,'\n')
#     if(verbose>0) cat('min(cv) =',min(apply(cvm,2,sum)),'\n')
#   }
#   glmboost_sem=glmboost(formula, data=data,center=T,control=boost_control(mstop=mstop0, nu=nu))
#   glmboost_sem$rho=rho
#   Y=data[,as.character(attr(terms(formula),'variables')[[2]])]
#   Y_pred= as.numeric(fitted(glmboost_sem))
#   glmboost_sem$rmse=sqrt(mean(as.numeric((I-rho*W)%*%(Y-Y_pred))^2))
#   return(glmboost_sem)
# }
