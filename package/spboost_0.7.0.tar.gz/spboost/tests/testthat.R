library(testthat)
library(spboost)

test_check("spboost")
