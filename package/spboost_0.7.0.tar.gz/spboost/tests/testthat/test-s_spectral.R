test_that("spx smoother constructs, fits, predicts, and REML selects mu_s", {
  set.seed(11)
  sim <- dgp(n = 400, rho = 0.5, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 11, SNR = 0.7)
  d <- sim$data
  W <- sim$W

  fit_free <- mgcv::gam(Y ~ s(X1) + s(x, y, k = 40), data = d)
  fit_spx  <- mgcv::gam(Y ~ s(X1) + s(x, y, k = 40, bs = "spx",
                               xt = list(W = W, kspec = 15)),
                        data = d, method = "REML")

  # one extra smoothing parameter (the spectral penalty), REML-selected
  expect_equal(length(fit_spx$sp), length(fit_free$sp) + 1L)
  expect_true(all(is.finite(fit_spx$sp)))

  # prediction on new data goes through the base-class Predict.matrix
  pr <- predict(fit_spx, newdata = d[1:5, ])
  expect_true(all(is.finite(pr)))
})

test_that("a large spectral penalty collapses the pi_k diagnostic", {
  testthat::skip_on_cran()
  set.seed(12)
  sim <- dgp(n = 400, rho = 0.5, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 12, SNR = 0.7)
  d <- sim$data
  W <- sim$W

  Ws <- (as.matrix(W) + t(as.matrix(W))) / 2
  eg <- eigen(Ws, symmetric = TRUE)
  eigs <- list(vectors = eg$vectors[, 1:15, drop = FALSE],
               values = eg$values[1:15])

  fit_free <- mgcv::gam(Y ~ s(X1) + s(x, y, k = 40), data = d)
  pi_free <- pi_k_diagnostic(fit_free, W, k = 15, eigs = eigs)$pi_k

  # fix an extreme spectral smoothing parameter: the fitted smoother
  # must become (nearly) orthogonal to the dominant spatial modes
  sp_hard <- c(fit_free$sp, 1e10)
  fit_hard <- mgcv::gam(Y ~ s(X1) + s(x, y, k = 40, bs = "spx",
                              xt = list(W = W, kspec = 15,
                                        eigs = eigs)),
                        data = d, sp = sp_hard)
  pi_hard <- pi_k_diagnostic(fit_hard, W, k = 15, eigs = eigs)$pi_k

  expect_lt(mean(pi_hard), 0.5 * mean(pi_free))
  expect_lt(mean(pi_hard), 0.10)
})

test_that("spx rejects missing or misaligned W", {
  set.seed(13)
  sim <- dgp(n = 120, rho = 0.3, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 13, SNR = 0.7)
  d <- sim$data

  expect_error(
    mgcv::gam(Y ~ s(x, y, bs = "spx", xt = list(kspec = 5)), data = d),
    "W")
  expect_error(
    mgcv::gam(Y ~ s(x, y, bs = "spx",
                    xt = list(W = sim$W[1:50, 1:50])), data = d),
    "aligned")
})
