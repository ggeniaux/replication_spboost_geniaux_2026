test_that("sandwich variances are computed and sane", {
  set.seed(31)
  sim <- dgp(n = 400, rho = 0.4, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 31, SNR = 0.7)
  fit <- GAM_SAR_CFE(Y ~ s(X1) + s(X2) + s(X3), data = sim$data, W = sim$W)
  expect_true(is.finite(fit$var_rho_hc0) && fit$var_rho_hc0 > 0)
  expect_true(is.finite(fit$var_rho_shac) && fit$var_rho_shac > 0)
  ## SHAC adds (possibly negative) cross terms but must stay the same order
  ## of magnitude as HC0, and both comparable to the closed-form variance
  expect_gt(fit$var_rho_shac / fit$var_rho_hc0, 0.2)
  expect_lt(fit$var_rho_shac / fit$var_rho_hc0, 5)
  expect_gt(fit$var_rho_hc0 / as.numeric(fit$var_rho), 0.05)
  expect_lt(fit$var_rho_hc0 / as.numeric(fit$var_rho), 20)

  ## also available under crossfit
  fit_cf <- GAM_SAR_CFE(Y ~ s(X1) + s(X2) + s(X3), data = sim$data,
                        W = sim$W, crossfit = TRUE, cf_nfold = 3L)
  expect_true(is.finite(fit_cf$var_rho_hc0))
  expect_true(is.finite(fit_cf$var_rho_shac))
})
