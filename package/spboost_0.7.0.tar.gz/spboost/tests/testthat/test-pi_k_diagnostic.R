test_that("pi_k_diagnostic matches the hat-matrix projection in the parametric case", {
  set.seed(42)
  sim <- dgp(n = 120, rho = 0.4, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 42, SNR = 0.7)
  d <- sim$data
  W <- sim$W

  fit <- mgcv::gam(Y ~ X1 + X2 + X3, data = d)

  # supply the eigenvectors explicitly so that the comparison is exact
  Ws <- (as.matrix(W) + t(as.matrix(W))) / 2
  eg <- eigen(Ws, symmetric = TRUE)
  eigs <- list(vectors = eg$vectors[, 1:10, drop = FALSE],
               values = eg$values[1:10])

  res <- pi_k_diagnostic(fit, W, k = 10L, eigs = eigs)
  expect_equal(nrow(res), 10L)
  expect_true(all(is.finite(res$pi_k)))

  # direct computation via the hat matrix of the parametric fit
  X <- model.matrix(~ X1 + X2 + X3, data = d)
  H <- X %*% solve(crossprod(X), t(X))
  pi_direct <- colSums(eigs$vectors * (H %*% eigs$vectors))
  expect_equal(res$pi_k, as.numeric(pi_direct), tolerance = 1e-6)
})

test_that("pi_k_diagnostic values lie in [0,1] for a penalized smoother", {
  set.seed(7)
  sim <- dgp(n = 150, rho = 0.4, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 7, SNR = 0.7)
  d <- sim$data
  W <- sim$W

  fit <- mgcv::gam(Y ~ s(X1) + s(X2) + s(X3), data = d)
  res <- pi_k_diagnostic(fit, W, k = 8L)

  expect_equal(nrow(res), 8L)
  expect_true(all(res$pi_k >= -1e-6 & res$pi_k <= 1 + 1e-6))
  # eigenvalues returned in decreasing order
  expect_true(all(diff(res$omega) <= 1e-8))
})

test_that("pi_k_diagnostic rejects invalid inputs", {
  set.seed(3)
  sim <- dgp(n = 80, rho = 0.2, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 3, SNR = 0.7)
  d <- sim$data
  fit <- mgcv::gam(Y ~ s(X1), data = d)

  expect_error(pi_k_diagnostic(lm(Y ~ X1, data = d), sim$W),
               "mgcv::gam")
  expect_error(pi_k_diagnostic(fit, sim$W[1:10, 1:10]),
               "aligned")
})
