test_that("GAM_SAR_CFE crossfit runs, records metadata, accepts user folds", {
  set.seed(21)
  sim <- dgp(n = 400, rho = 0.4, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 21, SNR = 0.7)
  d <- sim$data

  fit <- GAM_SAR_CFE(Y ~ s(X1) + s(X2) + s(X3), data = d, W = sim$W,
                     crossfit = TRUE, cf_nfold = 4L, cf_seed = 2L)
  expect_true(is.finite(fit$rho))
  expect_true(isTRUE(fit$crossfit))
  expect_identical(fit$cf_nfold, 4L)

  folds <- rep_len(1:3, nrow(d))
  fit2 <- GAM_SAR_CFE(Y ~ s(X1) + s(X2) + s(X3), data = d, W = sim$W,
                      crossfit = TRUE, cf_folds = folds)
  expect_true(is.finite(fit2$rho))
  expect_identical(fit2$cf_nfold, 3L)

  expect_error(
    GAM_SAR_CFE(Y ~ s(X1), data = d, W = sim$W,
                crossfit = TRUE, cf_folds = 1:10),
    "cf_folds")
})

test_that("crossfit patches spx smooths per fold (W subset, eigs dropped)", {
  set.seed(22)
  sim <- dgp(n = 400, rho = 0.4, sigma2 = 1, model = "SAR", nonlin = TRUE,
             myseed = 22, SNR = 0.7)
  d <- sim$data
  W <- sim$W

  fit <- GAM_SAR_CFE(
    Y ~ s(X1) + s(x, y, k = 30, bs = "spx",
                  xt = list(W = W, kspec = 10), sp = c(-1, 1e4)),
    data = d, W = W, crossfit = TRUE, cf_nfold = 3L)
  expect_true(is.finite(fit$rho))
  expect_true(isTRUE(fit$crossfit))
})

test_that("crossfit reduces the geoadditive-trap bias at rho = 0", {
  testthat::skip_on_cran()
  rho_pl <- rho_cf <- numeric(2)
  for (r in 1:2) {
    sim <- dgp(n = 1000, rho = 0, sigma2 = 1, model = "SAR", nonlin = TRUE,
               myseed = r, SNR = 0.7, f_sp = TRUE, f_corsp = TRUE)
    d <- sim$data
    fml <- Y ~ s(X1) + s(X2) + s(X3) + s(X4) + s(X5) + s(X6) + s(X7) +
      s(x, y, k = 60)
    rho_pl[r] <- GAM_SAR_CFE(fml, data = d, W = sim$W)$rho
    rho_cf[r] <- GAM_SAR_CFE(fml, data = d, W = sim$W,
                             crossfit = TRUE, cf_seed = r)$rho
  }
  ## plugin: spurious negative rho (about -0.12); cross-fitting removes
  ## most of it (mini-experiment mean -0.001 over 10 replications)
  expect_gt(mean(rho_cf) - mean(rho_pl), 0.03)
  expect_lt(abs(mean(rho_cf)), abs(mean(rho_pl)))
})
