library(mboost)

stability_digits <- 6L

stable_scalar <- function(x) {
  if (is.null(x) || length(x) == 0L) return(NA_real_)
  x <- suppressWarnings(as.numeric(x[1L]))
  if (!is.finite(x)) return(NA_real_)
  round(x, stability_digits)
}

stable_character <- function(x) {
  if (is.null(x) || length(x) == 0L || is.na(x[1L])) return(NA_character_)
  as.character(x[1L])
}

stable_coef <- function(model) {
  coef_obj <- tryCatch(stats::coef(model), error = function(e) numeric())
  if (is.list(coef_obj) && !is.data.frame(coef_obj)) {
    coef_obj <- unlist(coef_obj, use.names = TRUE)
  }
  coef_num <- suppressWarnings(as.numeric(coef_obj))
  names(coef_num) <- names(coef_obj)
  round(coef_num, stability_digits)
}

stable_mstop <- function(model) {
  if (!inherits(model, "mboost")) return(NA_integer_)
  as.integer(mboost::mstop(model))
}

stable_signature <- function(model) {
  list(
    class = class(model)[1L],
    rho = stable_scalar(model$rho),
    lambda = stable_scalar(model$lambda),
    rmse = stable_scalar(model$rmse),
    rho_method = stable_character(model$rho_method),
    mstop = stable_mstop(model),
    coef = stable_coef(model)
  )
}

stable_hash <- function(x) {
  path <- tempfile(fileext = ".txt")
  on.exit(unlink(path), add = TRUE)
  writeLines(capture.output(dput(x)), path, useBytes = TRUE)
  unname(tools::md5sum(path))
}

stable_prediction_signature <- function(pred) {
  pred <- round(as.numeric(pred), stability_digits)
  list(
    length = length(pred),
    mean = stable_scalar(mean(pred)),
    sd = stable_scalar(stats::sd(pred)),
    min = stable_scalar(min(pred)),
    max = stable_scalar(max(pred)),
    values = pred
  )
}

stable_cv_signature <- function(model) {
  meta <- model$spbgam_meta
  if (is.null(meta)) meta <- attr(model, "spbgam_meta")
  sel <- model$mstop_selection

  c(
    stable_signature(model),
    list(
      mstop_source = stable_character(meta$mstop_source),
      mstop_final = stable_scalar(meta$mstop_final),
      criterion = stable_character(sel$criterion),
      best_mstop = stable_scalar(sel$best_mstop),
      nfold = stable_scalar(sel$nfold),
      ncore = stable_scalar(sel$ncore),
      cv_mode_requested = stable_character(sel$cv_mode_requested),
      cv_mode_used = stable_character(sel$cv_mode_used),
      cv_rmse_filtered_at_best = stable_scalar(sel$cv_rmse_filtered_at_best)
    )
  )
}

row_normalize_matrix <- function(W) {
  row_sum <- Matrix::rowSums(W)
  Matrix::Diagonal(x = ifelse(row_sum > 0, 1 / row_sum, 0)) %*% W
}

stable_holdout_ids <- function(data, n_test = 20L) {
  protected <- unique(unlist(lapply(c("X1", "X2", "X3"), function(x) {
    c(which.min(data[[x]]), which.max(data[[x]]))
  })))
  candidates <- setdiff(seq_len(nrow(data)), protected)
  candidates[seq_len(n_test)]
}

fit_configs <- list(
  BSPA_SAR_CFE = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 42
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "BSPA_SAR_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 40, nu = 0.1),
        ncore = 1
      )
    )
  },
  BSPA_SAR_ML = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 42
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "BSPA_SAR_ML",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 35, nu = 0.1),
        ncore = 1
      )
    )
  },
  GAM_SAR_CFE = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 42
    )
    spbgam(
      Y ~ s(X1, k = 5) + s(X2, k = 5) + s(X3, k = 5),
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "GAM_SAR_CFE",
      control = list(ncore = 1)
    )
  },
  BSPA_SEM_CFE = function() {
    sim <- dgp(
      n = 120,
      rho = 0.40,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SEM",
      nonlin = TRUE,
      myseed = 43
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SEM",
      method = "BSPA_SEM_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 40, nu = 0.1),
        ncore = 1
      )
    )
  },
  MARS_SAR_CFE = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 42
    )
    spbgam(
      Y ~ X1 + X2 + X3,
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "MARS_SAR_CFE",
      control = list(
        control_earth = list(degree = 1, nprune = 8, trace = 0),
        ncore = 1
      )
    )
  },
  BSPA_SARAR_CFE = function() {
    sim <- dgp(
      n = 120,
      rho = 0.35,
      lambda = -0.25,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SARAR",
      nonlin = TRUE,
      myseed = 44
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      W2 = sim$W2,
      DGP = "SARAR",
      method = "BSPA_SARAR_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 35, nu = 0.1),
        iter_max = 2,
        tol_lambda = 1e-4,
        ncore = 1
      )
    )
  }
)

expected_hashes <- c(
  BSPA_SAR_CFE = "4ece01e5bcdf8c942d80b0a02f595dd3",
  BSPA_SAR_ML = "44df1bc0b338a68196a45443a48c5c6f",
  GAM_SAR_CFE = "96281980f8e83f4db4d9b37e063a9525",
  BSPA_SEM_CFE = "2e71440894e73278ee85bf17e6e335c8",
  MARS_SAR_CFE = "045d69a0bf5e1b3289faa669727604a1",
  BSPA_SARAR_CFE = "43412f4827421cefc58bfd60a1ac94da"
)

prediction_configs <- list(
  BSPA_SAR_CFE_in_sample = function() {
    predict(fit_configs$BSPA_SAR_CFE())
  },
  GAM_SAR_CFE_in_sample = function() {
    predict(fit_configs$GAM_SAR_CFE())
  },
  BSPA_SAR_CFE_out_sample_BPN = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      K1 = 8,
      myseed = 45
    )
    test_id <- stable_holdout_ids(sim$data)
    train_id <- setdiff(seq_len(nrow(sim$data)), test_id)
    fit <- spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data[train_id, ],
      W = row_normalize_matrix(sim$W[train_id, train_id, drop = FALSE]),
      DGP = "SAR",
      method = "BSPA_SAR_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 35, nu = 0.1),
        ncore = 1
      )
    )
    predict(
      fit,
      newdata = sim$data[test_id, ],
      data = sim$data[train_id, ],
      W = sim$W,
      type = "BPN"
    )
  },
  BSPA_SEM_CFE_newdata = function() {
    sim <- dgp(
      n = 120,
      rho = 0.40,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SEM",
      nonlin = TRUE,
      K1 = 8,
      myseed = 46
    )
    test_id <- stable_holdout_ids(sim$data)
    train_id <- setdiff(seq_len(nrow(sim$data)), test_id)
    fit <- spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data[train_id, ],
      W = row_normalize_matrix(sim$W[train_id, train_id, drop = FALSE]),
      DGP = "SEM",
      method = "BSPA_SEM_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 35, nu = 0.1),
        ncore = 1
      )
    )
    predict(fit, newdata = sim$data[test_id, ])
  },
  BSPA_SARAR_CFE_out_sample_BPN = function() {
    sim <- dgp(
      n = 120,
      rho = 0.35,
      lambda = -0.25,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SARAR",
      nonlin = TRUE,
      K1 = 8,
      K2 = 12,
      myseed = 47
    )
    test_id <- stable_holdout_ids(sim$data)
    train_id <- setdiff(seq_len(nrow(sim$data)), test_id)
    fit <- spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data[train_id, ],
      W = row_normalize_matrix(sim$W[train_id, train_id, drop = FALSE]),
      W2 = row_normalize_matrix(sim$W2[train_id, train_id, drop = FALSE]),
      DGP = "SARAR",
      method = "BSPA_SARAR_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 30, nu = 0.1),
        iter_max = 2,
        tol_lambda = 1e-4,
        ncore = 1
      )
    )
    predict(
      fit,
      newdata = sim$data[test_id, ],
      data = sim$data[train_id, ],
      W = sim$W,
      W2 = sim$W2,
      type = "BPN"
    )
  }
)

expected_prediction_hashes <- c(
  BSPA_SAR_CFE_in_sample = "cb2be603c79121e4d222b97610190d51",
  GAM_SAR_CFE_in_sample = "cb81721c59c67c2889d8d2e03b47185b",
  BSPA_SAR_CFE_out_sample_BPN = "90a3b03c127ce31e78ae30f1090718b0",
  BSPA_SEM_CFE_newdata = "1c5838875b008fe6a9cefc213b3343ce",
  BSPA_SARAR_CFE_out_sample_BPN = "3fc98aadd7b2aa7936f063974ca18abd"
)

cv_fit_configs <- list(
  BSPA_SAR_CFE_CV_RANDOM = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 52
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "BSPA_SAR_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 30, nu = 0.1),
        mstop_init = 12,
        mstop_criterion = "CV",
        nfold = 3,
        ncore = 1,
        cv_mode = "random",
        cv_seed_spatial = 2001,
        cv_eval_y_spatial = FALSE
      )
    )
  },
  BSPA_SAR_ML_CV_RANDOM = function() {
    sim <- dgp(
      n = 120,
      rho = 0.45,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SAR",
      nonlin = TRUE,
      myseed = 53
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SAR",
      method = "BSPA_SAR_ML",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 25, nu = 0.1),
        mstop_init = 10,
        mstop_criterion = "CV",
        nfold = 3,
        ncore = 1,
        cv_mode = "random",
        cv_seed_spatial = 2002,
        cv_eval_y_spatial = FALSE
      )
    )
  },
  BSPA_SEM_CFE_CV_RANDOM = function() {
    sim <- dgp(
      n = 120,
      rho = 0.40,
      betas = c(0, 0.5, 1, -1),
      sigma2 = 1,
      model = "SEM",
      nonlin = TRUE,
      myseed = 54
    )
    spbgam(
      Y ~ bbs(X1) + bbs(X2) + bbs(X3),
      data = sim$data,
      W = sim$W,
      DGP = "SEM",
      method = "BSPA_SEM_CFE",
      control = list(
        control_gamboost = mboost::boost_control(mstop = 25, nu = 0.1),
        mstop_init = 10,
        mstop_criterion = "CV",
        nfold = 3,
        ncore = 1,
        cv_mode = "random",
        cv_seed_spatial = 2003,
        sem_cfe_aux_cv = TRUE,
        sem_cfe_aux_nfold = 3,
        sem_cfe_aux_ncore = 1,
        sem_cfe_aux_seed = 2003
      )
    )
  }
)

expected_cv_hashes <- c(
  BSPA_SAR_CFE_CV_RANDOM = "3f240d00af3d832f3585a41725381851",
  BSPA_SAR_ML_CV_RANDOM = "7ad1a31cbba9ef52bf2ca017864880bd",
  BSPA_SEM_CFE_CV_RANDOM = "2e4aacea8f39ba227cff8da0c7d3f4da"
)

test_that("core estimators keep stable numerical signatures", {
  skip_on_cran()
  old_rng_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(old_rng_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  old_mc_cores <- getOption("mc.cores")
  on.exit(options(mc.cores = old_mc_cores), add = TRUE)
  options(mc.cores = 1L)

  observed_hashes <- vapply(
    names(fit_configs),
    function(config_name) stable_hash(stable_signature(fit_configs[[config_name]]())),
    character(1)
  )

  if (identical(Sys.getenv("SPBOOST_UPDATE_STABILITY_HASHES"), "true")) {
    message("Observed stability hashes:")
    print(observed_hashes)
    skip("SPBOOST_UPDATE_STABILITY_HASHES=true: printed hashes without comparison.")
  }

  expect_equal(observed_hashes, expected_hashes)
})

test_that("core predict methods keep stable numerical signatures", {
  skip_on_cran()
  old_rng_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(old_rng_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  old_mc_cores <- getOption("mc.cores")
  on.exit(options(mc.cores = old_mc_cores), add = TRUE)
  options(mc.cores = 1L)

  observed_hashes <- vapply(
    names(prediction_configs),
    function(config_name) {
      stable_hash(stable_prediction_signature(prediction_configs[[config_name]]()))
    },
    character(1)
  )

  if (identical(Sys.getenv("SPBOOST_UPDATE_STABILITY_HASHES"), "true")) {
    message("Observed prediction stability hashes:")
    print(observed_hashes)
    skip("SPBOOST_UPDATE_STABILITY_HASHES=true: printed hashes without comparison.")
  }

  expect_equal(observed_hashes, expected_prediction_hashes)
})

test_that("internal CV mstop calibration keeps stable numerical signatures", {
  skip_on_cran()
  old_rng_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(old_rng_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  old_mc_cores <- getOption("mc.cores")
  on.exit(options(mc.cores = old_mc_cores), add = TRUE)
  options(mc.cores = 1L)

  observed_hashes <- vapply(
    names(cv_fit_configs),
    function(config_name) stable_hash(stable_cv_signature(cv_fit_configs[[config_name]]())),
    character(1)
  )

  if (identical(Sys.getenv("SPBOOST_UPDATE_STABILITY_HASHES"), "true")) {
    message("Observed CV mstop stability hashes:")
    print(observed_hashes)
    skip("SPBOOST_UPDATE_STABILITY_HASHES=true: printed hashes without comparison.")
  }

  expect_equal(observed_hashes, expected_cv_hashes)
})

test_that("spatial_block CV mode uses blockCV spatial clusters", {
  testthat::skip_if_not_installed("blockCV")
  testthat::skip_if_not_installed("sf")

  old_rng_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(old_rng_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  old_mc_cores <- getOption("mc.cores")
  on.exit(options(mc.cores = old_mc_cores), add = TRUE)
  options(mc.cores = 1L)

  sim <- dgp(
    n = 80,
    rho = 0.35,
    betas = c(0, 0.5, 1, -1),
    sigma2 = 1,
    model = "SAR",
    nonlin = TRUE,
    myseed = 61
  )
  fit <- spbgam(
    Y ~ bbs(X1) + bbs(X2) + bbs(X3),
    data = sim$data,
    W = sim$W,
    DGP = "SAR",
    method = "BSPA_SAR_CFE",
    control = list(
      control_gamboost = mboost::boost_control(mstop = 12, nu = 0.1),
      mstop_init = 6,
      mstop_criterion = "CV",
      nfold = 3,
      ncore = 1,
      cv_mode = "spatial_block",
      cv_seed_spatial = 2004,
      cv_eval_y_spatial = FALSE
    )
  )

  expect_equal(fit$mstop_selection$cv_mode_requested, "spatial_block")
  expect_equal(fit$mstop_selection$cv_mode_used, "spatial_block")
  expect_equal(fit$mstop_selection$nfold, 3L)
})

test_that("cv_plot stores spatial fold coordinates", {
  testthat::skip_if_not_installed("blockCV")
  testthat::skip_if_not_installed("sf")

  old_rng_kind <- RNGkind()
  on.exit(do.call(RNGkind, as.list(old_rng_kind)), add = TRUE)
  RNGkind("Mersenne-Twister", "Inversion", "Rejection")
  old_mc_cores <- getOption("mc.cores")
  on.exit(options(mc.cores = old_mc_cores), add = TRUE)
  options(mc.cores = 1L)

  plot_file <- tempfile(fileext = ".pdf")
  grDevices::pdf(plot_file)
  on.exit(grDevices::dev.off(), add = TRUE)

  sim <- dgp(
    n = 80,
    rho = 0.35,
    betas = c(0, 0.5, 1, -1),
    sigma2 = 1,
    model = "SAR",
    nonlin = TRUE,
    myseed = 62
  )
  fit <- spbgam(
    Y ~ bbs(X1) + bbs(X2) + bbs(X3),
    data = sim$data,
    W = sim$W,
    DGP = "SAR",
    method = "BSPA_SAR_CFE",
    control = list(
      control_gamboost = mboost::boost_control(mstop = 12, nu = 0.1),
      mstop_init = 6,
      mstop_criterion = "CV",
      nfold = 3,
      ncore = 1,
      cv_mode = "spatial_block",
      cv_seed_spatial = 2005,
      cv_plot = TRUE,
      cv_eval_y_spatial = FALSE
    )
  )

  expect_s3_class(fit$mstop_selection$cv_plot_data, "data.frame")
  expect_named(fit$mstop_selection$cv_plot_data, c("x", "y", "fold"))
  expect_equal(nrow(fit$mstop_selection$cv_plot_data), nrow(sim$data))
  expect_equal(length(unique(fit$mstop_selection$cv_plot_data$fold)), 3L)
})

test_that("summary formats very small spatial p-values conventionally", {
  expect_equal(spb_format_p_value(3.49028e-80), "< 2.2e-16")
  expect_equal(spb_format_p_value(0.0349028), "0.0349")
})

test_that("BSPA SEM CFE exposes RMSE on the fitted object", {
  fit <- fit_configs$BSPA_SEM_CFE()
  expect_true(is.finite(fit$rmse))
  expect_equal(fit$rmse, sqrt(mean(as.numeric(fit$residuals)^2)))
})
