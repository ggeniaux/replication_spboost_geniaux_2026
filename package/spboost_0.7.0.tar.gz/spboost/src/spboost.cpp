// includes from the plugin
#include <RcppEigen.h>
#include <Rcpp.h>


#ifndef BEGIN_RCPP
#define BEGIN_RCPP
#endif

#ifndef END_RCPP
#define END_RCPP
#endif

using namespace Rcpp;


// user includes

using Eigen::LLT;
using Eigen::Lower;
using Eigen::Map;
using Eigen::MatrixXd;
using Eigen::MatrixXi;
using Eigen::VectorXd;
typedef Map<MatrixXd> MapMatd;
typedef Map<MatrixXi> MapMati;
typedef Map<VectorXd> MapVecd;
inline MatrixXd AtA(const MatrixXd& A) {
  int n(A.cols());
  return MatrixXd(n,n).setZero().selfadjointView<Lower>()
                      .rankUpdate(A.adjoint());
}

// declarations
extern "C" {
  SEXP ApproxiW( SEXP WW, SEXP la, SEXP order) ;
}

static const R_CallMethodDef CallEntries[] = {
  {"ApproxiW",         (DL_FUNC) &ApproxiW,          3},
  {NULL, NULL, 0}
};

void R_init_spboost(DllInfo *dll)
{
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
// definition

SEXP ApproxiW( SEXP WW, SEXP la, SEXP order ){
  BEGIN_RCPP

  using Eigen::SparseMatrix;
  using namespace Rcpp;
  using Eigen::MatrixXd;
  int ord = Rcpp::as<int>(order) ;
  double lambda = Rcpp::as<double>(la) ;
  const SparseMatrix<double> W(as<SparseMatrix<double> >(WW));
  int n = W.rows();
  SparseMatrix<double> A = W;
  double b = lambda;
  SparseMatrix<double> iW(n,n);
  iW.setIdentity();
  iW = iW+lambda*W;
  for(int j = 2; j < ord; ++j)
  {
    A = A * W;
    b = lambda*b;
    iW = iW + b*A;
  }
  //SparseMatrix<double> iWW = iW.transpose()*iW;
  //return List::create(Named("iW")=iW,Named("iWW")=iWW);
  return wrap(iW);
  END_RCPP
}
